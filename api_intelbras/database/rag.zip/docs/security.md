# Segurança & Operação — Confluence RAG API

Referência: [constituição](../.specify/memory/constitution.md), [spec](../specs/001-confluence-rag-acl/spec.md).

## Enforcement de ACL (faseado)

- **Fase A** (default, `RAG_ACL_PHASE=A`): fronteira = **escopo**. Só espaços sem restrição são
  indexados; o `phase_gate` bloqueia qualquer página restrita (`PhaseGateViolation`). O
  `NoOpAccessVerifier` permanece no fluxo (neutralizado).
- **Fase B** (`RAG_ACL_PHASE=B`): fronteira = **verificação final** com o token do usuário
  (`ConfluenceCqlVerifier`, CQL `id in (...)`), **fail-closed** — timeout/erro ⇒ não autorizado.
- **Gate absoluto**: nenhum espaço restrito é indexado antes da Fase B concluída + teste adversarial
  limpo (`tests/adversarial/`).

## Matriz de credenciais (FR-011)

| Etapa | Credencial |
|---|---|
| Ingestão (content/acl/directory) | Conta de serviço (`RAG_*` service token) — nunca o token do usuário |
| Verificação final (Fase B) | Token do **usuário** — nunca a conta de serviço |
| Pré-filtro na busca | Nenhuma (metadado local) |

Coberto por `tests/adversarial/test_credential_separation.py`.

## Controles do índice (FR-025)

- Segredos (token de serviço, chaves de provedor) em cofre; **fora do código**; rotação definida.
- Índice **criptografado em repouso** com chave da organização (config do backend de produção:
  Postgres/pgvector com TDE/volume cifrado).
- **Sem exposição pública**: apenas rede interna. `operatorAuth` protege `/sync*` (papel dedicado).
- **Trilhas separadas**: `rag_confluence.audit.query` (consulta) vs `rag_confluence.audit.index`
  (ingestão/operação) — rotear a destinos/retensões distintos em produção.
- Dados sensíveis **mascarados** nos logs (`app/logging.mask`).

## Substituibilidade e gate de produção (FR-027/FR-028)

- Adaptador escolhido por config (`RAG_VECTOR_STORE`, etc.), sem tocar o núcleo.
- Núcleo (`domain/`, `ports/`) **não importa infraestrutura** — verificado por `import-linter`
  (`pyproject.toml`).
- Um adaptador de store só é apto a produção após passar a **suíte de conformidade** C1–C8
  (`tests/conformance/`), incluindo os casos negativos de ACL (C2, C4).

## Dependências externas pendentes (Open Questions)

Q1/Q2 (mapeamento SSO↔accountId, OAuth 3LO) bloqueiam a Fase B. Q3/Q9 (conta de serviço, espaços
irrestritos) e Q4 (classificação/retenção do índice) condicionam a Fase A. Ver
[research.md](../specs/001-confluence-rag-acl/research.md).
