"""Montagem de prompt e formatação de resposta (FR-001, FR-002, FR-010).

O núcleo monta o prompt apenas com os chunks *sobreviventes* (já filtrados e verificados)
e formata a lista de fontes. Quando não há chunks, sinaliza "não encontrei" — nunca
revela existência de conteúdo (FR-010).
"""

from __future__ import annotations

from collections.abc import Sequence

from rag_confluence.domain.models import Chunk, Source

NOT_FOUND_MESSAGE = "Não encontrei essa informação na documentação disponível."

_SYSTEM = (
    "Você é um assistente que responde EXCLUSIVAMENTE com base nos trechos fornecidos da "
    "documentação interna. Cite as fontes pelo número [n]. Se os trechos não contiverem a "
    "resposta, diga que não encontrou. NUNCA invente informação nem cite páginas ausentes."
)


def build_prompt(question: str, chunks: Sequence[Chunk]) -> str:
    """Monta o prompt de geração. Assume ``chunks`` já filtrados/verificados."""
    blocks = []
    for i, c in enumerate(chunks, start=1):
        blocks.append(f"[{i}] (page_id={c.page_id})\n{c.text}")
    context = "\n\n".join(blocks)
    return f"{_SYSTEM}\n\n### Trechos\n{context}\n\n### Pergunta\n{question}\n\n### Resposta"


def sources_from_chunks(chunks: Sequence[Chunk]) -> tuple[Source, ...]:
    """Fontes únicas por página, na ordem de aparição."""
    seen: set[str] = set()
    out: list[Source] = []
    for c in chunks:
        if c.page_id in seen:
            continue
        seen.add(c.page_id)
        title = c.title or (c.breadcrumb.split(" > ")[-1] if c.breadcrumb else c.page_id)
        out.append(Source(page_id=c.page_id, title=title, url=c.url))
    return tuple(out)


def is_empty(chunks: Sequence[Chunk]) -> bool:
    return len(chunks) == 0
