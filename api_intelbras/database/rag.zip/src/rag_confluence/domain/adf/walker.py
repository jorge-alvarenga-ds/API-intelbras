"""Conversão ADF (Atlassian Document Format) -> Markdown (FR-022).

Walker próprio para controlar:
  - tabelas serializadas como Markdown com cabeçalho (nunca texto corrido);
  - blocos de código preservados (nunca cortados — o chunking respeita os fences);
  - macros conhecidas (expand, jira, include, excerpt) tratadas explicitamente, sem
    vazar o JSON da macro para o texto.

Produz um Markdown com headings ATX (``#``) que o chunking hierárquico usa como fronteira.
"""

from __future__ import annotations

from collections.abc import Iterable

_KNOWN_MACROS = {"expand", "jira", "include", "excerpt", "info", "note", "warning", "panel"}


def adf_to_markdown(adf: dict | None) -> str:
    if not adf:
        return ""
    parts = _render_nodes(adf.get("content", []))
    text = "\n\n".join(p for p in parts if p.strip())
    return _collapse_blank_lines(text)


def _render_nodes(nodes: Iterable[dict]) -> list[str]:
    return [r for n in nodes if (r := _render_node(n)) is not None]


def _render_node(node: dict) -> str | None:  # noqa: C901 - dispatch por tipo
    ntype = node.get("type")

    if ntype == "paragraph":
        return _inline(node.get("content", []))

    if ntype == "heading":
        level = int(node.get("attrs", {}).get("level", 1))
        return f"{'#' * max(1, min(level, 6))} {_inline(node.get('content', []))}"

    if ntype in ("bulletList", "orderedList"):
        return _render_list(node, ordered=ntype == "orderedList")

    if ntype == "codeBlock":
        lang = node.get("attrs", {}).get("language", "")
        code = _text_only(node.get("content", []))
        return f"```{lang}\n{code}\n```"

    if ntype == "blockquote":
        inner = "\n".join(_render_nodes(node.get("content", [])))
        return "\n".join(f"> {line}" for line in inner.splitlines())

    if ntype == "table":
        return _render_table(node)

    if ntype == "rule":
        return "---"

    if ntype in ("bodiedExtension", "extension", "inlineExtension"):
        return _render_macro(node)

    if ntype == "mediaSingle" or ntype == "mediaGroup":
        return ""  # mídia/anexos fora do escopo v1

    # Fallback: renderiza filhos se houver, senão texto.
    if "content" in node:
        return "\n\n".join(_render_nodes(node["content"]))
    return node.get("text")


def _render_list(node: dict, ordered: bool) -> str:
    lines: list[str] = []
    for i, item in enumerate(node.get("content", []), start=1):
        marker = f"{i}." if ordered else "-"
        inner = " ".join(_render_nodes(item.get("content", []))).strip()
        lines.append(f"{marker} {inner}")
    return "\n".join(lines)


def _render_table(node: dict) -> str:
    rows: list[list[str]] = []
    header_seen = False
    header: list[str] = []
    for row in node.get("content", []):
        if row.get("type") != "tableRow":
            continue
        cells = []
        is_header_row = False
        for cell in row.get("content", []):
            if cell.get("type") == "tableHeader":
                is_header_row = True
            cells.append(" ".join(_render_nodes(cell.get("content", []))).strip().replace("\n", " "))
        if is_header_row and not header_seen:
            header = cells
            header_seen = True
        else:
            rows.append(cells)

    if not header_seen and rows:
        header = rows.pop(0)  # primeira linha vira cabeçalho se não houver header explícito
        header_seen = True
    if not header:
        return ""

    width = len(header)
    out = ["| " + " | ".join(header) + " |", "| " + " | ".join(["---"] * width) + " |"]
    for r in rows:
        r = (r + [""] * width)[:width]
        out.append("| " + " | ".join(r) + " |")
    return "\n".join(out)


def _render_macro(node: dict) -> str:
    attrs = node.get("attrs", {})
    name = (attrs.get("extensionKey") or attrs.get("name") or "macro").lower()
    body = "\n\n".join(_render_nodes(node.get("content", []))) if "content" in node else ""
    if name == "excerpt" or name == "include":
        return body  # inclui o corpo como texto normal
    if name in _KNOWN_MACROS:
        label = name.capitalize()
        return f"**[{label}]** {body}".strip()
    # Macro desconhecida: mantém apenas o corpo textual; nunca serializa o JSON da macro.
    return body


def _inline(nodes: Iterable[dict]) -> str:
    out: list[str] = []
    for n in nodes:
        t = n.get("type")
        if t == "text":
            out.append(_apply_marks(n.get("text", ""), n.get("marks", [])))
        elif t == "hardBreak":
            out.append("\n")
        elif t == "mention":
            out.append("@" + n.get("attrs", {}).get("text", "").lstrip("@"))
        elif t == "emoji":
            out.append(n.get("attrs", {}).get("text", ""))
        elif t == "inlineCard":
            out.append(n.get("attrs", {}).get("url", ""))
        elif "content" in n:
            out.append(_inline(n["content"]))
    return "".join(out).strip()


def _apply_marks(text: str, marks: list[dict]) -> str:
    for mark in marks:
        mt = mark.get("type")
        if mt == "strong":
            text = f"**{text}**"
        elif mt == "em":
            text = f"*{text}*"
        elif mt == "code":
            text = f"`{text}`"
        elif mt == "link":
            href = mark.get("attrs", {}).get("href", "")
            text = f"[{text}]({href})"
    return text


def _text_only(nodes: Iterable[dict]) -> str:
    return "".join(n.get("text", "") for n in nodes if n.get("type") == "text")


def _collapse_blank_lines(text: str) -> str:
    lines = [ln.rstrip() for ln in text.splitlines()]
    out: list[str] = []
    blank = False
    for ln in lines:
        if not ln:
            if blank:
                continue
            blank = True
        else:
            blank = False
        out.append(ln)
    return "\n".join(out).strip()
