"""Fusão híbrida (RRF) e política de over-fetch/retry (FR-003, FR-004).

A busca lexical (BM25) e a densa são feitas separadamente pelos stores (cada uma já
aplica o pré-filtro de principals) e fundidas aqui por Reciprocal Rank Fusion. O núcleo
não conhece o store — recebe listas ordenadas de Scored.
"""

from __future__ import annotations

from collections.abc import Sequence

from rag_confluence.domain.models import Chunk, Scored

RRF_K = 60
OVERFETCH = 50
RETRY_MULTIPLIER = 4


def reciprocal_rank_fusion(
    ranked_lists: Sequence[Sequence[Scored]], k: int = RRF_K
) -> list[Scored]:
    """Funde múltiplas listas ordenadas em uma só por RRF.

    score(d) = sum_l 1 / (k + rank_l(d)). Deduplica por ``chunk_id``.
    """
    fused: dict[str, float] = {}
    best_chunk: dict[str, Chunk] = {}
    for ranked in ranked_lists:
        for rank, scored in enumerate(ranked):
            cid = scored.chunk.chunk_id
            fused[cid] = fused.get(cid, 0.0) + 1.0 / (k + rank + 1)
            best_chunk.setdefault(cid, scored.chunk)
    out = [Scored(chunk=best_chunk[cid], score=s) for cid, s in fused.items()]
    out.sort(key=lambda s: s.score, reverse=True)
    return out


def overfetch_size(top_k: int, attempt: int = 0) -> int:
    """Quantos candidatos buscar por store. Amplia em tentativas de retry quando o
    filtro de ACL colapsa o conjunto (edge case "Top-K colapsado")."""
    base = max(OVERFETCH, top_k * 10)
    return base * (RETRY_MULTIPLIER**attempt)
