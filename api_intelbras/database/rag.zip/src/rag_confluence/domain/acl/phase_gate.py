"""Gate de fase de ACL (FR-008/FR-009).

Na Fase A a fronteira de segurança é o escopo: NENHUM espaço/página com restrição pode
ser indexado. A Fase B é pré-requisito para indexar qualquer conteúdo restrito.
"""

from __future__ import annotations

from rag_confluence.domain.models import AclPhase, EffectiveAcl


class PhaseGateViolation(RuntimeError):
    """Tentativa de indexar conteúdo restrito fora da Fase B."""


def assert_indexable(page_id: str, acl: EffectiveAcl, phase: AclPhase) -> None:
    """Levanta se a página não pode ser indexada na fase atual.

    Fase A: só conteúdo sem restrição efetiva (``public``). Fase B: qualquer conteúdo.
    """
    if phase is AclPhase.A and acl.is_restricted:
        raise PhaseGateViolation(
            f"page {page_id}: conteúdo restrito não pode ser indexado na Fase A "
            f"(origem da restrição: {acl.origin.value}). Requer ACL_PHASE=B."
        )


def is_indexable(acl: EffectiveAcl, phase: AclPhase) -> bool:
    return phase is AclPhase.B or not acl.is_restricted
