"""Resolução de ACL efetiva: restrição própria -> herança -> permissão de espaço (FR-021)."""

from __future__ import annotations

from collections.abc import Sequence

from rag_confluence.domain.acl.principals import group_principal, user_principal
from rag_confluence.domain.models import (
    PUBLIC,
    AclOrigin,
    EffectiveAcl,
    Restrictions,
    SpacePermissions,
)


def _principals_from_restriction(r: Restrictions) -> frozenset[str]:
    principals = {group_principal(g) for g in r.group_ids}
    principals |= {user_principal(a) for a in r.account_ids}
    return frozenset(principals)


def resolve_effective_acl(
    page_restriction: Restrictions,
    ancestor_restrictions: Sequence[Restrictions],
    space_permissions: SpacePermissions,
) -> EffectiveAcl:
    """Resolve os principals permitidos de uma página.

    Ordem de precedência (a primeira restrição encontrada vence):
      1. Restrição própria da página.
      2. Restrição herdada do ancestral mais próximo (``ancestor_restrictions`` ordenado
         do mais próximo para o mais distante).
      3. Permissão do espaço. Espaço aberto => ``public``.
    """
    if page_restriction.restricted:
        return EffectiveAcl(_principals_from_restriction(page_restriction), AclOrigin.PAGE)

    for anc in ancestor_restrictions:
        if anc.restricted:
            return EffectiveAcl(_principals_from_restriction(anc), AclOrigin.INHERITED)

    if space_permissions.is_open:
        return EffectiveAcl(frozenset({PUBLIC}), AclOrigin.SPACE)

    principals = {group_principal(g) for g in space_permissions.group_ids}
    principals |= {user_principal(a) for a in space_permissions.account_ids}
    return EffectiveAcl(frozenset(principals), AclOrigin.SPACE)
