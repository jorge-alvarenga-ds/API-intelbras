"""Principals: serialização canônica, interseção e invariante group-ID-only.

FR-006 (interseção para pré-filtro), FR-012 (group ID imutável, nunca nome),
FR-013 (principals do usuário a partir de cópia local).

Um principal é sempre uma string canônica: ``group:<id>``, ``user:<accountId>`` ou ``public``.
"""

from __future__ import annotations

from collections.abc import Iterable

from rag_confluence.domain.models import PUBLIC


class PrincipalError(ValueError):
    """Violação de invariante de principal (ex.: nome de grupo em vez de ID)."""


def group_principal(group_id: str) -> str:
    if not group_id or not group_id.strip():
        raise PrincipalError("group_id vazio")
    if " " in group_id:
        # Nomes de grupo costumam conter espaços; IDs do Confluence não. Guarda barata
        # contra o erro clássico de persistir nome em vez de ID (FR-012).
        raise PrincipalError(f"group principal deve usar group ID imutável, não nome: {group_id!r}")
    return f"group:{group_id}"


def user_principal(account_id: str) -> str:
    if not account_id or not account_id.strip():
        raise PrincipalError("account_id vazio")
    return f"user:{account_id}"


def build_user_principals(account_id: str, group_ids: Iterable[str]) -> frozenset[str]:
    """Principals efetivos de um usuário: public + user:<id> + group:<id> por grupo.

    Usado no caminho crítico da consulta a partir do cache local de grupos (FR-013).
    """
    principals = {PUBLIC, user_principal(account_id)}
    for gid in group_ids:
        principals.add(group_principal(gid))
    return frozenset(principals)


def intersects(allowed_principals: Iterable[str], user_principals: Iterable[str]) -> bool:
    """True se o chunk é visível ao usuário (interseção não vazia).

    Base do pré-filtro (FR-006). ``allowed`` vem materializado no chunk; ``user`` vem
    de :func:`build_user_principals`.
    """
    allowed = allowed_principals if isinstance(allowed_principals, (set, frozenset)) else set(
        allowed_principals
    )
    return any(p in allowed for p in user_principals)


def validate_group_ids(group_ids: Iterable[str]) -> tuple[str, ...]:
    """Valida e normaliza uma lista de group IDs (rejeita nomes)."""
    out: list[str] = []
    for gid in group_ids:
        group_principal(gid)  # levanta se for nome
        out.append(gid)
    return tuple(out)
