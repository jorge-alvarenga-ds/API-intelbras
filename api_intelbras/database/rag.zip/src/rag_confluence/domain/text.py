"""Tokenização de conteúdo (remove stopwords pt/en e tokens curtos).

Usada pelos adaptadores de referência (embedding/reranker/lexical) para que relevância
reflita palavras de conteúdo, não palavras funcionais. Recurso de linguagem puro.
"""

from __future__ import annotations

import re

_WORD = re.compile(r"\w+", re.UNICODE)

STOPWORDS: frozenset[str] = frozenset(
    {
        # pt
        "que", "com", "para", "por", "uma", "uns", "umas", "dos", "das", "nos", "nas",
        "como", "qual", "quais", "mais", "mas", "foi", "ser", "sao", "são", "está",
        "estao", "estão", "seu", "sua", "seus", "suas", "ele", "ela", "isso", "esse",
        "essa", "este", "esta", "não", "nao", "sim", "ao", "aos", "the", "and", "for",
        "com", "sobre", "num", "numa", "pelo", "pela", "meu", "minha", "hoje",
        # en
        "of", "to", "in", "is", "on", "at", "an", "be", "or", "it", "as", "by", "we",
    }
)


def tokenize(text: str) -> list[str]:
    return [t for t in _WORD.findall(text.lower()) if len(t) >= 3 and t not in STOPWORDS]
