"""Chunking hierárquico por heading, com prefixo de breadcrumb + heading path (FR-023).

- Segmenta o Markdown por headings ATX, mantendo o caminho de headings (H1 > H2 > ...).
- Nunca corta um bloco de código (fences ```): o fence inteiro fica no mesmo chunk.
- Descarta páginas com conteúdo útil trivial (~< 200 caracteres).
- Cada chunk é prefixado com breadcrumb (ancestrais) + heading path.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass

MIN_USEFUL_CHARS = 200
_HEADING_RE = re.compile(r"^(#{1,6})\s+(.*)$")


@dataclass(frozen=True)
class ChunkText:
    text: str
    heading_path: str
    index: int


def content_hash(markdown: str) -> str:
    return hashlib.sha256(markdown.strip().encode("utf-8")).hexdigest()


def useful_length(markdown: str) -> int:
    """Comprimento de conteúdo útil (ignora fences, headings e marcação leve)."""
    stripped = re.sub(r"```.*?```", " ", markdown, flags=re.DOTALL)
    stripped = re.sub(r"[#>*`|\-]", " ", stripped)
    return len(stripped.strip())


def is_trivial(markdown: str, min_chars: int = MIN_USEFUL_CHARS) -> bool:
    return useful_length(markdown) < min_chars


def _split_sections(markdown: str) -> list[tuple[str, str]]:
    """Divide em (heading_path, corpo). Preserva blocos de código intactos."""
    lines = markdown.splitlines()
    sections: list[tuple[str, str]] = []
    stack: list[tuple[int, str]] = []  # (nível, título)
    buf: list[str] = []
    heading_path = ""
    in_code = False

    def flush(hp: str) -> None:
        body = "\n".join(buf).strip()
        if body:
            sections.append((hp, body))
        buf.clear()

    for line in lines:
        if line.lstrip().startswith("```"):
            in_code = not in_code
            buf.append(line)
            continue
        m = _HEADING_RE.match(line) if not in_code else None
        if m:
            flush(heading_path)
            level = len(m.group(1))
            title = m.group(2).strip()
            while stack and stack[-1][0] >= level:
                stack.pop()
            stack.append((level, title))
            heading_path = " > ".join(t for _, t in stack)
        else:
            buf.append(line)
    flush(heading_path)
    return sections


def chunk_markdown(
    markdown: str, breadcrumb: str, min_chars: int = MIN_USEFUL_CHARS
) -> list[ChunkText]:
    """Gera chunks prefixados com breadcrumb + heading path."""
    if is_trivial(markdown, min_chars):
        return []

    chunks: list[ChunkText] = []
    for hp, body in _split_sections(markdown):
        prefix_bits = [b for b in (breadcrumb, hp) if b]
        prefix = " | ".join(prefix_bits)
        text = f"{prefix}\n\n{body}" if prefix else body
        chunks.append(ChunkText(text=text, heading_path=hp, index=len(chunks)))

    # Página sem headings mas com corpo útil: um único chunk.
    if not chunks and not is_trivial(markdown, min_chars):
        text = f"{breadcrumb}\n\n{markdown.strip()}" if breadcrumb else markdown.strip()
        chunks.append(ChunkText(text=text, heading_path="", index=0))
    return chunks


def breadcrumb_from_ancestors(ancestor_titles: list[str]) -> str:
    return " > ".join(t for t in ancestor_titles if t)
