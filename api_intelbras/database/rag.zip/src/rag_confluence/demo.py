"""Entrypoint de DEMONSTRAÇÃO: sobe a API já com um índice populado (fake do Confluence).

    uvicorn rag_confluence.demo:app --reload

Diferente de ``main:app`` (produção, sem origem configurada => índice vazio), este módulo
semeia uma base de exemplo na inicialização para você exercitar /query imediatamente.

Tokens de exemplo:
  - usuário (consulta):  Authorization: Bearer demo-user
  - operador (/sync*):   Authorization: Bearer operator-secret
"""

from __future__ import annotations

from contextlib import asynccontextmanager

from rag_confluence.adapters.fakes.confluence import FakeConfluence
from rag_confluence.app.composition import build_container
from rag_confluence.app.config import Settings
from rag_confluence.app.http.app import create_app
from rag_confluence.app.logging import configure_logging
from rag_confluence.domain.models import AclPhase, SyncMode

_LONG = " Documentação interna com detalhes suficientes e vocabulário do domínio bancário. " * 3


def _para(text: str) -> dict:
    return {"type": "paragraph", "content": [{"type": "text", "text": text}]}


def _seed(fake: FakeConfluence) -> None:
    fake.add_space("ARQ", is_open=True)
    fake.add_page("P1", "ARQ", "Rotação de Refresh Token OAuth",
                  {"content": [_para("Para fazer a rotação do refresh token no OAuth interno." + _LONG)]})
    fake.add_page("P2", "ARQ", "Pipeline de Deploy",
                  {"content": [_para("O pipeline de deploy executa build e testes automatizados." + _LONG)]})


configure_logging()
_settings = Settings(acl_phase=AclPhase.A, allowlist=["ARQ"], embedding_dim=128)
_fake = FakeConfluence()
_seed(_fake)
_container = build_container(_settings, confluence=_fake, identity_map={"demo-user": "acc1"})


@asynccontextmanager
async def _lifespan(app):
    # Indexa a base de exemplo no startup (dentro do event loop do servidor).
    await _container.sync_service.run_sync(["ARQ"], SyncMode.FULL)
    yield


app = create_app(_container, lifespan=_lifespan)
