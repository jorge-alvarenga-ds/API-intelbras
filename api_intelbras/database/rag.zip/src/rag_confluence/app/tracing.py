"""Propagação de trace_id via contextvars (default runnable; OTel é swap de produção)."""

from __future__ import annotations

import contextvars
import uuid

_trace_id: contextvars.ContextVar[str | None] = contextvars.ContextVar("trace_id", default=None)


def new_trace_id() -> str:
    tid = uuid.uuid4().hex
    _trace_id.set(tid)
    return tid


def set_trace_id(tid: str) -> None:
    _trace_id.set(tid)


def get_trace_id() -> str:
    return _trace_id.get() or "-"
