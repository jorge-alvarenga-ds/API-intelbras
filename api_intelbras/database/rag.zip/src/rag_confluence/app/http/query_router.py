"""Router de consulta (POST /query)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from rag_confluence.app.http.auth import user_bearer
from rag_confluence.app.http.dto import QueryRequest, QueryResponse
from rag_confluence.app.services.query_service import VerificationUnavailable
from rag_confluence.domain.acl.principals import build_user_principals
from rag_confluence.ports.identity import IdentityError


def build_query_router(container) -> APIRouter:
    router = APIRouter(tags=["query"])

    @router.get("/whoami")
    async def whoami(token: str = Depends(user_bearer)) -> dict:
        """Mostra a identidade e os principals (acesso) do usuário do token."""
        try:
            account_id = await container.identity.resolve_account_id(token)
        except IdentityError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        groups = container.metadata_store.get_user_groups(account_id) or []
        principals = sorted(build_user_principals(account_id, groups))
        return {
            "account_id": account_id,
            "groups": groups,
            "principals": principals,
            "acl_phase": container.settings.acl_phase.value,
            "note": (
                "grupos vazios: rode o sync de grupos (CLI 'group-sync') para popular o cache; "
                "na Fase A o conteúdo indexado é público, então isto não restringe ainda."
                if not groups else
                "acesso = conteúdo cujo allowed_principals intersecta estes principals."
            ),
        }

    @router.post("/query", response_model=QueryResponse)
    async def query(body: QueryRequest, token: str = Depends(user_bearer)) -> QueryResponse:
        try:
            result = await container.query_service.answer(body.question, token, body.top_k)
        except IdentityError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        except VerificationUnavailable as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        return QueryResponse.from_result(result)

    return router
