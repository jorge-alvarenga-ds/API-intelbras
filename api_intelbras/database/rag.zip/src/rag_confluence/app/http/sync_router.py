"""Router de sincronização/operação (papel de operador — FR-019a)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from rag_confluence.app.http.auth import make_operator_auth
from rag_confluence.app.http.dto import SyncAccepted, SyncRequest, SyncStatus
from rag_confluence.app.services.sync_service import ActiveJobExists, ScopeNotAllowed
from rag_confluence.domain.models import SyncMode


def build_sync_router(container) -> APIRouter:
    router = APIRouter(prefix="/sync", tags=["sync"])
    operator_auth = make_operator_auth(container.settings)

    def _svc():
        if container.sync_service is None:
            raise HTTPException(status_code=503, detail="sincronização não configurada (sem origem)")
        return container.sync_service

    @router.post("", status_code=202, response_model=SyncAccepted)
    async def start(body: SyncRequest | None = None, _op: str = Depends(operator_auth)):
        svc = _svc()
        body = body or SyncRequest()
        try:
            mode = SyncMode(body.mode)
            job_id = await svc.start(body.spaces, mode)
        except ScopeNotAllowed as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        except ActiveJobExists as exc:
            raise HTTPException(status_code=409, detail=str(exc)) from exc
        return SyncAccepted(job_id=job_id, status="queued")

    @router.get("/current")
    async def current(_op: str = Depends(operator_auth)):
        job = _svc().current()
        return SyncStatus.from_job(job) if job else None

    @router.get("/{job_id}", response_model=SyncStatus)
    async def status(job_id: str, _op: str = Depends(operator_auth)):
        job = _svc().status(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="job não encontrado")
        return SyncStatus.from_job(job)

    @router.post("/{job_id}/cancel", status_code=202, response_model=SyncStatus)
    async def cancel(job_id: str, _op: str = Depends(operator_auth)):
        job = _svc().cancel(job_id)
        if not job:
            raise HTTPException(status_code=404, detail="job não encontrado")
        return SyncStatus.from_job(job)

    return router
