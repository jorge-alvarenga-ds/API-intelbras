"""Fábrica da aplicação FastAPI."""

from __future__ import annotations

from fastapi import FastAPI

from rag_confluence.app.http.query_router import build_query_router
from rag_confluence.app.http.sync_router import build_sync_router


def create_app(container, lifespan=None) -> FastAPI:
    app = FastAPI(title="Confluence RAG API", version="1.0.0", lifespan=lifespan)
    app.state.container = container

    @app.get("/health", tags=["health"])
    async def health() -> dict:
        return {
            "status": "ok",
            "acl_phase": container.settings.acl_phase.value,
            "verifier_adapter": container.access_verifier.name,
        }

    app.include_router(build_query_router(container))
    app.include_router(build_sync_router(container))
    return app
