"""Autenticação HTTP: userBearer (consulta) e operatorAuth (operação) — FR-019a.

Usa o esquema HTTPBearer: no Swagger aparece o botão "Authorize" e o cliente envia
``Authorization: Bearer <token>`` automaticamente (você cola só o token).
O acesso de operação é um papel dedicado, separado do de consulta (menor privilégio).
"""

from __future__ import annotations

from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from rag_confluence.app.config import Settings

_user_scheme = HTTPBearer(scheme_name="userBearer", auto_error=False)
_operator_scheme = HTTPBearer(scheme_name="operatorAuth", auto_error=False)


def user_bearer(creds: HTTPAuthorizationCredentials | None = Depends(_user_scheme)) -> str:
    if creds is None or not creds.credentials:
        raise HTTPException(status_code=401, detail="token de usuário ausente")
    return creds.credentials


def make_operator_auth(settings: Settings):
    def operator_auth(
        creds: HTTPAuthorizationCredentials | None = Depends(_operator_scheme),
    ) -> str:
        if creds is None or not creds.credentials:
            raise HTTPException(status_code=401, detail="credencial de operador ausente")
        if creds.credentials != settings.operator_token:
            raise HTTPException(status_code=403, detail="requer papel de operador dedicado")
        return creds.credentials

    return operator_auth
