"""DTOs da API (Pydantic). Contrato-first: espelham contracts/openapi.yaml."""

from __future__ import annotations

from pydantic import BaseModel, Field

from rag_confluence.domain.models import QueryResult, SyncJob


class QueryRequest(BaseModel):
    question: str = Field(min_length=1, max_length=4000)
    top_k: int | None = Field(default=None, ge=1, le=20)


class SourceDTO(BaseModel):
    page_id: str
    title: str
    url: str


class ChunkDTO(BaseModel):
    """Trecho recuperado que fundamentou a resposta."""

    page_id: str
    title: str
    url: str
    text: str
    score: float


class QueryResponse(BaseModel):
    answer: str
    found: bool
    sources: list[SourceDTO]
    chunks: list[ChunkDTO]
    trace_id: str

    @classmethod
    def from_result(cls, r: QueryResult) -> "QueryResponse":
        return cls(
            answer=r.answer, found=r.found, trace_id=r.trace_id,
            sources=[SourceDTO(page_id=s.page_id, title=s.title, url=s.url) for s in r.sources],
            chunks=[
                ChunkDTO(page_id=p.page_id, title=p.title, url=p.url, text=p.text, score=p.score)
                for p in r.passages
            ],
        )


class SyncRequest(BaseModel):
    spaces: list[str] | None = None
    mode: str = "incremental"


class SyncAccepted(BaseModel):
    job_id: str
    status: str = "queued"


class SyncStatus(BaseModel):
    job_id: str
    status: str
    processed: int
    total: int
    scope: list[str]
    errors: list[dict]

    @classmethod
    def from_job(cls, j: SyncJob) -> "SyncStatus":
        return cls(
            job_id=j.job_id, status=j.status.value, processed=j.processed, total=j.total,
            scope=list(j.scope), errors=j.errors,
        )
