"""Backoff exponencial com honra a Retry-After (FR-018). tenacity é swap de produção."""

from __future__ import annotations

import asyncio
from collections.abc import Awaitable, Callable
from typing import TypeVar

T = TypeVar("T")


class RateLimited(Exception):
    def __init__(self, retry_after: float | None = None) -> None:
        self.retry_after = retry_after
        super().__init__("rate limited")


async def with_backoff(
    fn: Callable[[], Awaitable[T]],
    *,
    retries: int = 5,
    base: float = 0.5,
    factor: float = 2.0,
    sleep: Callable[[float], Awaitable[None]] = asyncio.sleep,
) -> T:
    """Executa ``fn`` com recuo exponencial em :class:`RateLimited` (429)."""
    attempt = 0
    while True:
        try:
            return await fn()
        except RateLimited as exc:
            if attempt >= retries:
                raise
            delay = exc.retry_after if exc.retry_after is not None else base * (factor**attempt)
            await sleep(delay)
            attempt += 1
