"""Composição / injeção de dependência (FR-027, FR-029).

Escolha de adaptador por configuração, não código. Registra o adaptador de verificação
ativo na inicialização (Fase A neutralizada vs. Fase B real). Adaptadores de produção
(Chroma/Vertex/bge/Confluence) são carregados sob demanda; os defaults runnable
(in-memory/hashing/lexical/extractive) mantêm o sistema operável sem dependências pesadas.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from rag_confluence.adapters.access_verifier.confluence_cql import ConfluenceCqlVerifier
from rag_confluence.adapters.access_verifier.noop import NoOpAccessVerifier
from rag_confluence.adapters.embedding.hashing import HashingEmbedding
from rag_confluence.adapters.generator.extractive import ExtractiveGenerator
from rag_confluence.adapters.identity.static import StaticIdentity
from rag_confluence.adapters.lexical_store.sqlite_fts5 import SqliteFts5LexicalStore
from rag_confluence.adapters.lock.file_lock import FileLock
from rag_confluence.adapters.metadata_store.sqlite import SqliteMetadataStore
from rag_confluence.adapters.reranker.lexical import LexicalReranker
from rag_confluence.adapters.vector_store.inmemory import InMemoryVectorStore
from rag_confluence.app.config import Settings
from rag_confluence.app.services.group_sync import GroupSync
from rag_confluence.app.services.query_service import QueryService
from rag_confluence.app.services.sync_service import SyncService
from rag_confluence.domain.models import AclPhase

log = logging.getLogger("rag_confluence.composition")


@dataclass
class Container:
    settings: Settings
    metadata_store: object
    vector_store: object
    lexical_store: object
    embedding: object
    reranker: object
    generator: object
    identity: object
    access_verifier: object
    lock: object
    content_source: object | None
    acl_source: object | None
    directory_source: object | None
    query_service: QueryService
    sync_service: SyncService | None
    group_sync: GroupSync | None


def build_vector_store(settings: Settings):
    if settings.vector_store == "inmemory":
        return InMemoryVectorStore()
    if settings.vector_store == "chroma":
        from rag_confluence.adapters.vector_store.chroma import ChromaVectorStore

        return ChromaVectorStore(settings.chroma_path or None)
    raise ValueError(f"vector_store desconhecido: {settings.vector_store}")


def build_embedding(settings: Settings):
    if settings.embedding_provider == "hashing":
        return HashingEmbedding(settings.embedding_dim)
    if settings.embedding_provider == "gemini":
        from rag_confluence.adapters.embedding.gemini import GeminiEmbedding

        return GeminiEmbedding(
            backend=settings.gemini_backend, api_key=settings.gemini_api_key,
            project=settings.gemini_project, location=settings.gemini_location,
            model=settings.gemini_embedding_model, dim=settings.embedding_dim,
        )
    raise ValueError(f"embedding_provider desconhecido: {settings.embedding_provider}")


def build_reranker(settings: Settings):
    if settings.reranker in ("none", "passthrough"):
        from rag_confluence.adapters.reranker.passthrough import PassthroughReranker

        return PassthroughReranker()
    if settings.reranker == "bge":
        from rag_confluence.adapters.reranker.bge import BgeReranker

        return BgeReranker()
    return LexicalReranker()  # default de referência (para stack local sem semântica)


def build_generator(settings: Settings):
    if settings.generator == "extractive":
        return ExtractiveGenerator()
    if settings.generator == "gemini":
        from rag_confluence.adapters.generator.gemini import GeminiGenerator

        return GeminiGenerator(
            backend=settings.gemini_backend, api_key=settings.gemini_api_key,
            project=settings.gemini_project, location=settings.gemini_location,
            model=settings.gemini_model,
        )
    raise ValueError(f"generator desconhecido: {settings.generator}")


def build_access_verifier(settings: Settings, http_client=None):
    if settings.acl_phase is AclPhase.A:
        return NoOpAccessVerifier()
    return ConfluenceCqlVerifier(settings.confluence_base_url, http_client=http_client)


def build_content_sources(settings: Settings):
    """Constrói (content, acl, directory). 'real' liga os adaptadores httpx do Confluence."""
    if settings.confluence_source != "real":
        return None, None, None
    if not settings.confluence_token:
        raise ValueError(
            "confluence_source='real' exige RAG_CONFLUENCE_TOKEN (token da conta de serviço)"
        )
    from rag_confluence.adapters.confluence._auth import service_auth_header
    from rag_confluence.adapters.confluence.acl_source import ConfluenceAclSource
    from rag_confluence.adapters.confluence.content_source import ConfluenceContentSource
    from rag_confluence.adapters.confluence.directory_source import ConfluenceDirectorySource

    base = settings.confluence_base_url
    auth = service_auth_header(settings.confluence_token, settings.confluence_email)
    return (
        ConfluenceContentSource(base, auth),
        ConfluenceAclSource(base, auth),
        ConfluenceDirectorySource(base, auth),
    )


def build_container(
    settings: Settings, *, confluence=None, identity_map: dict[str, str] | None = None,
) -> Container:
    metadata = SqliteMetadataStore(settings.metadata_db_path)
    vector = build_vector_store(settings)
    lexical = SqliteFts5LexicalStore(settings.lexical_db_path)
    embedding = build_embedding(settings)
    reranker = build_reranker(settings)
    generator = build_generator(settings)
    identity = StaticIdentity(identity_map)
    if settings.dev_user_token:  # atalho de teste local (Fase A, sem BFF)
        identity.register(settings.dev_user_token, settings.dev_account_id)
    verifier = build_access_verifier(settings)
    lock = FileLock()

    if confluence is not None:
        content = acl = directory = confluence  # o fake satisfaz as três portas (testes/demo)
    else:
        content, acl, directory = build_content_sources(settings)  # 'real' => adaptadores httpx

    query_service = QueryService(
        identity=identity, metadata_store=metadata, embedding=embedding, vector_store=vector,
        lexical_store=lexical, reranker=reranker, generator=generator,
        access_verifier=verifier, settings=settings,
    )
    sync_service = None
    group_sync = None
    if content is not None:
        sync_service = SyncService(
            content=content, acl=acl, metadata_store=metadata, vector_store=vector,
            lexical_store=lexical, embedding=embedding, lock=lock, settings=settings,
        )
        group_sync = GroupSync(directory, metadata)

    # FR-029 / T044: registra o adaptador de verificação ativo e a fase na inicialização.
    log.info(
        "composition_ready",
        extra={"context": {
            "acl_phase": settings.acl_phase.value,
            "verifier_adapter": verifier.name,
            "vector_store": settings.vector_store,
            "lexical_store": settings.lexical_store,
            "allowlist": settings.allowlist,
        }},
    )

    return Container(
        settings=settings, metadata_store=metadata, vector_store=vector, lexical_store=lexical,
        embedding=embedding, reranker=reranker, generator=generator, identity=identity,
        access_verifier=verifier, lock=lock, content_source=content, acl_source=acl,
        directory_source=directory, query_service=query_service, sync_service=sync_service,
        group_sync=group_sync,
    )
