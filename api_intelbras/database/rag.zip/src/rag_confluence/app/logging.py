"""Logging estruturado (JSON) com mascaramento e TRILHAS SEPARADAS (FR-024/FR-025/FR-068).

- Logger de consulta:   ``rag_confluence.audit.query``
- Trilha de operação/índice: ``rag_confluence.audit.index`` (separada da consulta)
Em produção, roteie cada logger para um destino/retensão distinto. structlog/OTel são
swaps de produção; aqui usamos a stdlib para manter runnable.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime

from rag_confluence.domain.models import AuditRecord

_SENSITIVE = ("token", "authorization", "password", "secret", "api_key", "apikey")

QUERY_AUDIT = "rag_confluence.audit.query"
INDEX_AUDIT = "rag_confluence.audit.index"


def mask(value: object) -> object:
    """Mascara valores de chaves sensíveis (recursivo em dicts)."""
    if isinstance(value, dict):
        return {
            k: ("***" if any(s in k.lower() for s in _SENSITIVE) else mask(v))
            for k, v in value.items()
        }
    if isinstance(value, (list, tuple)):
        return [mask(v) for v in value]
    return value


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": datetime.utcnow().isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "msg": record.getMessage(),
        }
        if isinstance(getattr(record, "context", None), dict):
            payload.update(mask(record.context))
        return json.dumps(payload, ensure_ascii=False)


def configure_logging(level: int = logging.INFO) -> None:
    handler = logging.StreamHandler()
    handler.setFormatter(JsonFormatter())
    root = logging.getLogger("rag_confluence")
    root.handlers.clear()
    root.addHandler(handler)
    root.setLevel(level)
    root.propagate = False


def emit_query_audit(record: AuditRecord) -> None:
    """Registra o log de auditoria de uma consulta (FR-024)."""
    logging.getLogger(QUERY_AUDIT).info(
        "query_audit",
        extra={"context": {
            "trace_id": record.trace_id,
            "account_id": record.account_id,
            "retrieved_page_ids": list(record.retrieved_page_ids),
            "approved_page_ids": list(record.approved_page_ids),
            "phase": record.phase.value,
            "verifier_adapter": record.verifier_adapter,
        }},
    )


def log_page_ingestion(page_id: str, version: int, result: str, space_key: str) -> None:
    """Registra o resultado da ingestão de uma página (FR-024, trilha de índice)."""
    logging.getLogger(INDEX_AUDIT).info(
        "page_ingestion",
        extra={"context": {
            "page_id": page_id, "version": version, "result": result, "space_key": space_key,
        }},
    )
