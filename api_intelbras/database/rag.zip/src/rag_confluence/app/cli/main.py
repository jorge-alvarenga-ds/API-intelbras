"""CLI operacional (Typer): sync, reconcile, group-sync, query — para teste e operação."""

from __future__ import annotations

import asyncio

import typer

from rag_confluence.app.composition import build_container
from rag_confluence.app.config import Settings
from rag_confluence.domain.models import SyncMode

app = typer.Typer(help="Confluence RAG API — CLI operacional")


def _container():
    # Em produção, injetar os adaptadores reais do Confluence aqui.
    return build_container(Settings(), confluence=None)


@app.command()
def sync(mode: str = "incremental") -> None:
    """Dispara uma sincronização (requer origem configurada)."""
    c = _container()
    if c.sync_service is None:
        typer.echo("origem Confluence não configurada")
        raise typer.Exit(code=1)
    job = asyncio.run(c.sync_service.run_sync(None, SyncMode(mode)))
    typer.echo(f"job {job.job_id}: {job.status.value} ({job.processed}/{job.total})")


@app.command("group-sync")
def group_sync() -> None:
    """Reconstrói o cache local de grupos (accountId -> [group_ids])."""
    c = _container()
    if c.group_sync is None:
        typer.echo("diretório não configurado")
        raise typer.Exit(code=1)
    n = asyncio.run(c.group_sync.run())
    typer.echo(f"{n} usuários mapeados")


def _mask(value: str) -> str:
    if not value:
        return "(vazio)"
    return value[:2] + "***" if len(value) > 4 else "***"


@app.command()
def doctor() -> None:
    """Diagnóstico READ-ONLY da conexão com o Confluence (não altera nada)."""
    settings = Settings()
    if settings.confluence_source != "real":
        typer.echo("RAG_CONFLUENCE_SOURCE != 'real' — configure o .env para testar a conexão real.")
        raise typer.Exit(code=1)
    try:
        container = build_container(settings)
    except ValueError as exc:
        typer.echo(f"config inválida: {exc}")
        raise typer.Exit(code=1) from exc

    auth_mode = "Basic (email:token)" if settings.confluence_email else "Bearer (OAuth/PAT)"
    typer.echo("== Config ==")
    typer.echo(f"  base_url : {settings.confluence_base_url}")
    typer.echo(f"  auth     : {auth_mode}")
    typer.echo(f"  email    : {_mask(settings.confluence_email)}")
    typer.echo(f"  token    : {_mask(settings.confluence_token)}")
    typer.echo(f"  allowlist: {settings.allowlist}  | ACL_PHASE={settings.acl_phase.value}")

    code = asyncio.run(_run_doctor(container, settings))
    raise typer.Exit(code=code)


async def _run_doctor(container, settings) -> int:
    from rag_confluence.domain.acl.effective import resolve_effective_acl
    from rag_confluence.domain.acl.phase_gate import is_indexable
    from rag_confluence.domain.adf.walker import adf_to_markdown

    # Lista espaços acessíveis para o usuário escolher a space key correta (RAG_ALLOWLIST).
    accessible: set[str] = set()
    try:
        spaces = await container.content_source.list_spaces()
        accessible = {k for k, _ in spaces}
        typer.echo("\n== Espaços acessíveis (use a KEY em RAG_ALLOWLIST) ==")
        for key, name in spaces[:30]:
            typer.echo(f"  - {key}  ({name})")
        if not spaces:
            typer.echo("  (nenhum espaço global visível para esta conta de serviço)")
    except Exception as exc:  # noqa: BLE001
        return _explain(exc)

    space = settings.allowlist[0] if settings.allowlist else None
    if not space:
        typer.echo("allowlist vazia — defina RAG_ALLOWLIST.")
        return 1
    if accessible and space not in accessible:
        typer.echo(f"\n⚠️  '{space}' (RAG_ALLOWLIST) não está entre os espaços acessíveis acima. "
                   "Ajuste RAG_ALLOWLIST para uma das keys listadas.")
        return 1

    typer.echo(f"\n== Teste no espaço '{space}' ==")
    try:
        listing = await container.content_source.list_pages(space, None, None)
        typer.echo(f"  list_pages: OK — {len(listing.refs)} página(s) na primeira página de resultados")

        perms = await container.acl_source.get_space_permissions(space)
        typer.echo(f"  space_permissions: is_open={perms.is_open} groups={len(perms.group_ids)}")

        if listing.refs:
            ref = listing.refs[0]
            page = await container.content_source.get_page(ref.page_id)
            md = adf_to_markdown(page.body_adf)
            typer.echo(f"  get_page({ref.page_id}): '{page.title}' — {len(md)} chars de markdown")
            restr = await container.acl_source.get_page_restrictions(ref.page_id)
            acl = resolve_effective_acl(restr, [], perms)
            allowed = is_indexable(acl, settings.acl_phase)
            typer.echo(f"  ACL efetiva: restrita={acl.is_restricted} — indexável na fase "
                       f"{settings.acl_phase.value}? {allowed}")
        typer.echo("\nOK: conexão validada.")
        return 0
    except Exception as exc:  # noqa: BLE001 - diagnóstico amigável
        return _explain(exc)


def _explain(exc: Exception) -> int:
    status = getattr(getattr(exc, "response", None), "status_code", None)
    hints = {
        401: "401 — autenticação falhou. Confluence Cloud + API token exige RAG_CONFLUENCE_EMAIL "
             "(Basic auth). Confira e-mail/token.",
        403: "403 — autenticado, mas sem permissão. A conta de serviço tem leitura neste espaço?",
        404: "404 — recurso não encontrado. Confira a space key (RAG_ALLOWLIST) e a base_url.",
    }
    typer.echo(f"\nFALHOU: {type(exc).__name__}: {exc}")
    if status in hints:
        typer.echo("  → " + hints[status])
    return 1


@app.command()
def query(question: str, token: str = typer.Option(..., help="token do usuário")) -> None:
    """Consulta a base (para teste manual)."""
    c = _container()
    res = asyncio.run(c.query_service.answer(question, token))
    typer.echo(res.answer)
    for s in res.sources:
        typer.echo(f"  - {s.title}: {s.url}")


if __name__ == "__main__":
    app()
