"""Sync de grupos (consulta invertida): grupos -> membros -> accountId -> [group_ids].

Evita a chamada ``memberof`` em runtime (403 não-admin) e tira o Confluence do caminho
crítico da consulta (FR-013, R5). Grupos aninhados são expandidos pelo adaptador.
"""

from __future__ import annotations

from rag_confluence.ports.directory_source import DirectorySourcePort
from rag_confluence.ports.metadata_store import MetadataStorePort


class GroupSync:
    def __init__(self, directory: DirectorySourcePort, metadata_store: MetadataStorePort) -> None:
        self._directory = directory
        self._meta = metadata_store

    async def run(self) -> int:
        account_groups: dict[str, set[str]] = {}
        for group in await self._directory.list_groups():
            members = await self._directory.list_group_members(group.id)
            for account_id in members:
                account_groups.setdefault(account_id, set()).add(group.id)
        for account_id, group_ids in account_groups.items():
            self._meta.upsert_user_groups(account_id, sorted(group_ids))
        return len(account_groups)
