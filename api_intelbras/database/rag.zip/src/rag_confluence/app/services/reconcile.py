"""Reconciliação de exclusões (FR-020): remove do índice o que sumiu na origem.

Servir conteúdo apagado é risco equivalente a vazamento — a reconciliação roda antes do
rollout amplo e periodicamente.
"""

from __future__ import annotations

from rag_confluence.app.logging import log_page_ingestion


class Reconciler:
    def __init__(self, *, content, metadata_store, vector_store, lexical_store) -> None:
        self._content = content
        self._meta = metadata_store
        self._vector = vector_store
        self._lexical = lexical_store

    async def run(self, scope: list[str]) -> int:
        removed = 0
        for space in scope:
            indexed = self._meta.all_indexed_page_ids(space)
            listing = await self._content.list_pages(space, None, None)
            current = {ref.page_id for ref in listing.refs}
            for page_id in indexed - current:
                self._vector.delete_by_page(page_id)
                self._lexical.delete_by_page(page_id)
                self._meta.delete_page(page_id)
                log_page_ingestion(page_id, -1, "removed_reconcile", space)
                removed += 1
        return removed
