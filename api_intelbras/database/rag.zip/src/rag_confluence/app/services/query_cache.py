"""Cache de resposta. A chave INCLUI os principals do usuário (FR-013).

Cache sem principals na chave vaza conteúdo entre usuários — por isso a chave é
(pergunta normalizada, principals ordenados, top_k).
"""

from __future__ import annotations

from collections.abc import Iterable

from rag_confluence.domain.models import QueryResult

CacheKey = tuple[str, tuple[str, ...], int]


class QueryCache:
    def __init__(self) -> None:
        self._store: dict[CacheKey, QueryResult] = {}

    @staticmethod
    def make_key(question: str, principals: Iterable[str], top_k: int) -> CacheKey:
        return (question.strip().lower(), tuple(sorted(principals)), top_k)

    def get(self, key: CacheKey) -> QueryResult | None:
        return self._store.get(key)

    def set(self, key: CacheKey, result: QueryResult) -> None:
        self._store[key] = result
