"""ASGI entrypoint: ``uvicorn rag_confluence.main:app``.

Constrói o container a partir da configuração (env ``RAG_*``). Sem origem Confluence
configurada, os endpoints de sincronização respondem 503; a consulta opera sobre o índice
existente. Para produção, injete os adaptadores reais do Confluence na composição.
"""

from __future__ import annotations

from rag_confluence.app.composition import build_container
from rag_confluence.app.config import Settings
from rag_confluence.app.http.app import create_app
from rag_confluence.app.logging import configure_logging

configure_logging()
settings = Settings()
container = build_container(settings, confluence=None)
app = create_app(container)
