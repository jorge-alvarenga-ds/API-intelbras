"""Cliente google-genai unificado. A flag ``backend`` seleciona o provedor.

- ``api``    -> Gemini API (Google AI) com chave de API.
- ``vertex`` -> Vertex AI (GCP) com projeto + região (usa ADC/conta de serviço).

Import de google.genai é tardio: o SDK só é exigido quando o Gemini é de fato usado.
"""

from __future__ import annotations


def build_client(backend: str, *, api_key: str, project: str, location: str):
    from google import genai

    if backend == "vertex":
        return genai.Client(vertexai=True, project=project or None, location=location or None)
    if backend == "api":
        if not api_key:
            raise ValueError("gemini_backend='api' exige RAG_GEMINI_API_KEY")
        return genai.Client(api_key=api_key)
    raise ValueError(f"gemini_backend inválido: {backend!r} (use 'api' ou 'vertex')")
