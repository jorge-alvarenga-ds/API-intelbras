"""LockPort via arquivo/processo (v1) — implica worker em réplica única.

Cria um arquivo de lock exclusivo por escopo. Em produção, trocar por advisory lock do
Postgres (semântica multi-réplica). A porta esconde a API, não a semântica.
"""

from __future__ import annotations

import os
import tempfile
from contextlib import contextmanager
from collections.abc import Iterator

from rag_confluence.ports.lock import LockHeld


class FileLock:
    def __init__(self, directory: str | None = None) -> None:
        self._dir = directory or os.path.join(tempfile.gettempdir(), "rag_confluence_locks")
        os.makedirs(self._dir, exist_ok=True)

    @contextmanager
    def acquire(self, scope: str) -> Iterator[None]:
        path = os.path.join(self._dir, f"{_safe(scope)}.lock")
        try:
            fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError as exc:
            raise LockHeld(f"lock '{scope}' já está tomado") from exc
        try:
            os.write(fd, str(os.getpid()).encode())
            os.close(fd)
            yield
        finally:
            try:
                os.remove(path)
            except FileNotFoundError:
                pass


def _safe(scope: str) -> str:
    return "".join(ch if ch.isalnum() else "_" for ch in scope) or "default"
