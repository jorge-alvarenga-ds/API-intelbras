"""LexicalStore (BM25) sobre SQLite FTS5, com PRÉ-FILTRO de principals.

O pré-filtro é aplicado na própria consulta SQL (JOIN com ``chunk_principals``), antes do
ranking BM25 — nunca pós-filtro. Fallback portátil (scoring por TF em Python) quando FTS5
não está disponível no ambiente.
"""

from __future__ import annotations

import os
import sqlite3
from collections.abc import Sequence

from rag_confluence.domain.models import Chunk, Scored
from rag_confluence.domain.text import tokenize


def _fts5_available(con: sqlite3.Connection) -> bool:
    try:
        con.execute("CREATE VIRTUAL TABLE _fts_probe USING fts5(x)")
        con.execute("DROP TABLE _fts_probe")
        return True
    except sqlite3.OperationalError:
        return False


class SqliteFts5LexicalStore:
    def __init__(self, path: str = ":memory:") -> None:
        if path and path != ":memory:":
            parent = os.path.dirname(path)
            if parent:
                os.makedirs(parent, exist_ok=True)
        self._con = sqlite3.connect(path, check_same_thread=False)
        self._con.row_factory = sqlite3.Row
        self._fts = _fts5_available(self._con)
        self._init_schema()

    def _init_schema(self) -> None:
        c = self._con
        c.execute(
            """CREATE TABLE IF NOT EXISTS chunks(
                chunk_id TEXT PRIMARY KEY, page_id TEXT, space_key TEXT, text TEXT,
                breadcrumb TEXT, heading_path TEXT, url TEXT, version INTEGER)"""
        )
        c.execute(
            """CREATE TABLE IF NOT EXISTS chunk_principals(
                chunk_id TEXT, principal TEXT)"""
        )
        c.execute("CREATE INDEX IF NOT EXISTS idx_cp_principal ON chunk_principals(principal)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_cp_chunk ON chunk_principals(chunk_id)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_chunks_page ON chunks(page_id)")
        if self._fts:
            c.execute(
                "CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING fts5("
                "text, chunk_id UNINDEXED, tokenize='unicode61')"
            )
        self._con.commit()

    # ------------------------------------------------------------------ writes
    def index(self, chunks: list[Chunk]) -> None:
        for pid in {c.page_id for c in chunks}:
            self.delete_by_page(pid)
        cur = self._con
        for ch in chunks:
            cur.execute(
                "INSERT INTO chunks VALUES(?,?,?,?,?,?,?,?)",
                (ch.chunk_id, ch.page_id, ch.space_key, ch.text, ch.breadcrumb,
                 ch.heading_path, ch.url, ch.version),
            )
            cur.executemany(
                "INSERT INTO chunk_principals VALUES(?,?)",
                [(ch.chunk_id, p) for p in ch.allowed_principals],
            )
            if self._fts:
                cur.execute(
                    "INSERT INTO chunks_fts(text, chunk_id) VALUES(?,?)", (ch.text, ch.chunk_id)
                )
        self._con.commit()

    def delete_by_page(self, page_id: str) -> None:
        rows = self._con.execute(
            "SELECT chunk_id FROM chunks WHERE page_id=?", (page_id,)
        ).fetchall()
        ids = [r["chunk_id"] for r in rows]
        for cid in ids:
            self._con.execute("DELETE FROM chunks WHERE chunk_id=?", (cid,))
            self._con.execute("DELETE FROM chunk_principals WHERE chunk_id=?", (cid,))
            if self._fts:
                self._con.execute("DELETE FROM chunks_fts WHERE chunk_id=?", (cid,))
        self._con.commit()

    # ------------------------------------------------------------------ reads
    def search_bm25(self, query: str, principals: Sequence[str], k: int) -> list[Scored]:
        principal_list = list(dict.fromkeys(principals))
        if not principal_list:
            return []  # C4
        allowed_ids = self._allowed_chunk_ids(principal_list)
        if not allowed_ids:
            return []
        if self._fts:
            return self._search_fts(query, allowed_ids, k)
        return self._search_fallback(query, allowed_ids, k)

    def _allowed_chunk_ids(self, principals: list[str]) -> set[str]:
        ph = ",".join("?" * len(principals))
        rows = self._con.execute(
            f"SELECT DISTINCT chunk_id FROM chunk_principals WHERE principal IN ({ph})",
            principals,
        ).fetchall()
        return {r["chunk_id"] for r in rows}

    def _search_fts(self, query: str, allowed_ids: set[str], k: int) -> list[Scored]:
        match = _to_fts_query(query)
        if not match:
            return []
        rows = self._con.execute(
            "SELECT chunk_id, bm25(chunks_fts) AS rank FROM chunks_fts "
            "WHERE chunks_fts MATCH ? ORDER BY rank",
            (match,),
        ).fetchall()
        out: list[Scored] = []
        for r in rows:
            if r["chunk_id"] not in allowed_ids:
                continue
            out.append(self._to_scored(r["chunk_id"], -float(r["rank"])))
            if len(out) >= k:
                break
        return out

    def _search_fallback(self, query: str, allowed_ids: set[str], k: int) -> list[Scored]:
        terms = set(tokenize(query))
        scored: list[Scored] = []
        ph = ",".join("?" * len(allowed_ids))
        rows = self._con.execute(
            f"SELECT chunk_id, text FROM chunks WHERE chunk_id IN ({ph})", list(allowed_ids)
        ).fetchall()
        for r in rows:
            toks = tokenize(r["text"])
            if not toks:
                continue
            score = sum(toks.count(t) for t in terms) / len(toks)
            if score > 0:
                scored.append(self._to_scored(r["chunk_id"], score))
        scored.sort(key=lambda s: s.score, reverse=True)
        return scored[:k]

    def _to_scored(self, chunk_id: str, score: float) -> Scored:
        r = self._con.execute("SELECT * FROM chunks WHERE chunk_id=?", (chunk_id,)).fetchone()
        chunk = Chunk(
            chunk_id=r["chunk_id"], page_id=r["page_id"], chunk_index=0, space_key=r["space_key"],
            text=r["text"], allowed_principals=(), breadcrumb=r["breadcrumb"],
            heading_path=r["heading_path"], url=r["url"], version=r["version"],
        )
        return Scored(chunk=chunk, score=score)


def _to_fts_query(query: str) -> str:
    terms = tokenize(query)
    return " OR ".join(f'"{t}"' for t in terms)
