"""GeneratorPort via Gemini (google-genai). Backend api/vertex por flag."""

from __future__ import annotations


class GeminiGenerator:
    def __init__(self, *, backend, api_key, project, location, model, temperature=0.2):
        self._backend = backend
        self._api_key = api_key
        self._project = project
        self._location = location
        self._model = model
        self._temperature = temperature
        self._client = None

    def _client_(self):
        if self._client is None:
            from rag_confluence.adapters._genai import build_client

            self._client = build_client(
                self._backend, api_key=self._api_key,
                project=self._project, location=self._location,
            )
        return self._client

    async def generate(self, prompt: str) -> str:
        from google.genai import types

        client = self._client_()
        resp = await client.aio.models.generate_content(
            model=self._model,
            contents=prompt,
            config=types.GenerateContentConfig(temperature=self._temperature),
        )
        return resp.text or ""
