"""GeneratorPort de referência: extrativo/determinístico (sem LLM externo).

Adaptador v1 runnable. Compõe uma resposta a partir dos trechos do prompt e cita as
fontes por número. Em produção, trocar por Vertex/Gemini via configuração. Respeita o
contrato: se o prompt não tiver trechos, sinaliza que não encontrou.
"""

from __future__ import annotations

from rag_confluence.domain.prompt.assemble import NOT_FOUND_MESSAGE


class ExtractiveGenerator:
    async def generate(self, prompt: str) -> str:
        context = _extract_section(prompt, "### Trechos", "### Pergunta")
        question = _extract_section(prompt, "### Pergunta", "### Resposta").strip()
        if not context.strip():
            return NOT_FOUND_MESSAGE

        # Seleciona as primeiras sentenças relevantes de cada trecho citado.
        snippets = []
        for block in context.split("\n\n"):
            line = block.strip()
            if line.startswith("[") and "]" in line:
                marker = line[: line.index("]") + 1]
                body = block.split("\n", 1)[1].strip() if "\n" in block else ""
                first = _first_sentence(body)
                if first:
                    snippets.append(f"{first} {marker}")
        if not snippets:
            return NOT_FOUND_MESSAGE
        header = f"Com base na documentação sobre «{question}»:" if question else "Com base na documentação:"
        return header + "\n" + "\n".join(f"- {s}" for s in snippets[:5])


def _extract_section(text: str, start: str, end: str) -> str:
    if start not in text:
        return ""
    tail = text.split(start, 1)[1]
    return tail.split(end, 1)[0] if end in tail else tail


def _first_sentence(text: str) -> str:
    text = text.replace("\n", " ").strip()
    for sep in (". ", "! ", "? "):
        if sep in text:
            return text.split(sep, 1)[0].strip() + sep.strip()
    return text[:280].strip()
