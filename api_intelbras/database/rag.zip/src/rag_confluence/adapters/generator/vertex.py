"""GeneratorPort de produção: Vertex AI / Gemini (lazy import)."""

from __future__ import annotations


class VertexGenerator:
    def __init__(self, model: str = "gemini-2.5-flash", temperature: float = 0.2):
        self._model_name = model
        self._temperature = temperature

    async def generate(self, prompt: str) -> str:
        from vertexai.generative_models import GenerationConfig, GenerativeModel

        model = GenerativeModel(self._model_name)
        resp = await model.generate_content_async(
            prompt, generation_config=GenerationConfig(temperature=self._temperature)
        )
        return resp.text
