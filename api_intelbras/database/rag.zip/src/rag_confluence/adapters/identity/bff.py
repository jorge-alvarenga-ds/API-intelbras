"""IdentityPort de produção: resolvedor do BFF (SSO -> accountId), com cache de sessão."""

from __future__ import annotations

from rag_confluence.ports.identity import IdentityError


class BffIdentity:
    def __init__(self, resolver_url: str, http_client=None, timeout: float = 5.0):
        self._url = resolver_url.rstrip("/")
        self._client = http_client
        self._timeout = timeout
        self._cache: dict[str, str] = {}

    async def resolve_account_id(self, user_token: str) -> str:
        if user_token in self._cache:
            return self._cache[user_token]
        import httpx

        client = self._client or httpx.AsyncClient(timeout=self._timeout)
        owns = self._client is None
        try:
            resp = await client.get(
                f"{self._url}/whoami", headers={"Authorization": f"Bearer {user_token}"}
            )
            if resp.status_code != 200:
                raise IdentityError("token inválido no BFF")
            account_id = resp.json().get("accountId")
            if not account_id:
                raise IdentityError("BFF não retornou accountId")
            self._cache[user_token] = account_id
            return account_id
        finally:
            if owns:
                await client.aclose()
