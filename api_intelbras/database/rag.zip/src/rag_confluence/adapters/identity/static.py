"""IdentityPort de referência: mapa estático token -> accountId (testes/local).

Em produção, trocar pelo resolvedor do BFF (SSO -> accountId) via configuração.
"""

from __future__ import annotations

from rag_confluence.ports.identity import IdentityError


class StaticIdentity:
    def __init__(self, token_to_account: dict[str, str] | None = None) -> None:
        self._map = dict(token_to_account or {})

    def register(self, token: str, account_id: str) -> None:
        self._map[token] = account_id

    async def resolve_account_id(self, user_token: str) -> str:
        account_id = self._map.get(user_token)
        if not account_id:
            raise IdentityError("token sem mapeamento para accountId")
        return account_id
