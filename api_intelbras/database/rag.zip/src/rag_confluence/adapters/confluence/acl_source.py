"""AclSource real (Confluence Cloud v1). NOTA: restrições vivem SEMPRE na API v1.

Adaptador de produção (não exercitado nos testes). ``get_page_restrictions`` lê a
operação ``read``; ``get_space_permissions`` determina se o espaço é aberto (visível a
todos) — a heurística de "aberto" DEVE ser validada contra a instância real (Q4/Q9).
"""

from __future__ import annotations

from rag_confluence.domain.models import Restrictions, SpacePermissions


class ConfluenceAclSource:
    def __init__(self, base_url: str, auth_header: str, http_client=None, timeout: float = 30.0):
        self._base = base_url.rstrip("/")
        self._auth = auth_header
        self._client = http_client
        self._timeout = timeout

    def _headers(self) -> dict:
        return {"Authorization": self._auth, "Accept": "application/json"}

    async def _get(self, path: str, params: dict | None = None) -> dict:
        import httpx

        client = self._client or httpx.AsyncClient(timeout=self._timeout)
        owns = self._client is None
        try:
            resp = await client.get(f"{self._base}{path}", headers=self._headers(), params=params or {})
            resp.raise_for_status()
            return resp.json()
        finally:
            if owns:
                await client.aclose()

    async def get_page_restrictions(self, page_id) -> Restrictions:
        # v1: restrições de leitura por operação.
        data = await self._get(f"/wiki/rest/api/content/{page_id}/restriction/byOperation/read")
        restr = data.get("restrictions", {})
        groups = [g["id"] for g in restr.get("group", {}).get("results", []) if g.get("id")]
        users = [
            u["accountId"] for u in restr.get("user", {}).get("results", []) if u.get("accountId")
        ]
        restricted = bool(groups or users)
        return Restrictions(restricted=restricted, group_ids=tuple(groups), account_ids=tuple(users))

    async def get_space_permissions(self, space_key) -> SpacePermissions:
        data = await self._get(f"/wiki/rest/api/space/{space_key}", {"expand": "permissions"})
        perms = data.get("permissions", [])
        group_ids: list[str] = []
        account_ids: list[str] = []
        is_open = False
        for p in perms:
            if p.get("operation", {}).get("operation") != "read":
                continue
            subj = p.get("subjects", {})
            if not subj:  # permissão de leitura sem sujeito específico => anônimo/todos
                is_open = True
            for g in subj.get("group", {}).get("results", []):
                if g.get("id"):
                    group_ids.append(g["id"])
            for u in subj.get("user", {}).get("results", []):
                if u.get("accountId"):
                    account_ids.append(u["accountId"])
        return SpacePermissions(is_open=is_open, group_ids=tuple(group_ids), account_ids=tuple(account_ids))
