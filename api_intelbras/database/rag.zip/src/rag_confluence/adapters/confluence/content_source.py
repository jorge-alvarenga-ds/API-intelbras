"""ContentSource real (Confluence Cloud v1) via httpx + conta de serviço.

Adaptador de produção. Não exercitado nos testes (requer credencial). Usa a API v1 com
``atlas_doc_format`` para obter o ADF. Delta sync por CQL ``lastModified``.
"""

from __future__ import annotations

import json
from datetime import datetime

from rag_confluence.app.retry import RateLimited, with_backoff
from rag_confluence.domain.models import Ancestor, Page
from rag_confluence.ports.content_source import PageListing, PageRef


class ConfluenceContentSource:
    def __init__(self, base_url: str, auth_header: str, http_client=None, timeout: float = 30.0):
        self._base = base_url.rstrip("/")
        self._auth = auth_header  # conta de serviço (Basic/Bearer) — NUNCA o token do usuário (FR-011)
        self._client = http_client
        self._timeout = timeout

    def _headers(self) -> dict:
        return {"Authorization": self._auth, "Accept": "application/json"}

    async def _get(self, path: str, params: dict) -> dict:
        import httpx

        client = self._client or httpx.AsyncClient(timeout=self._timeout)
        owns = self._client is None

        async def call():
            resp = await client.get(f"{self._base}{path}", headers=self._headers(), params=params)
            if resp.status_code == 429:
                retry_after = float(resp.headers.get("Retry-After", 1))
                raise RateLimited(retry_after)
            resp.raise_for_status()
            return resp.json()

        try:
            return await with_backoff(call)
        finally:
            if owns:
                await client.aclose()

    async def list_spaces(self, limit: int = 50) -> list[tuple[str, str]]:
        """(diagnóstico) Espaços acessíveis: [(key, name), ...]. Tenta v2, fallback v1."""
        try:
            data = await self._get("/wiki/api/v2/spaces", {"limit": limit})
            results = data.get("results", [])
            if results:
                return [(s.get("key", ""), s.get("name", "")) for s in results]
        except Exception:  # noqa: BLE001 - fallback para v1
            pass
        data = await self._get("/wiki/rest/api/space", {"limit": limit})
        return [(s.get("key", ""), s.get("name", "")) for s in data.get("results", [])]

    async def list_pages(self, space_key, since, cursor) -> PageListing:
        cql = f'space = "{space_key}" and type = page'
        if since is not None:
            cql += f' and lastModified >= "{since:%Y-%m-%d %H:%M}"'
        params = {"cql": cql, "limit": 50, "expand": "version"}
        if cursor:
            params["cursor"] = cursor
        data = await self._get("/wiki/rest/api/content/search", params)
        refs = tuple(
            PageRef(
                page_id=str(r["id"]),
                version=int(r.get("version", {}).get("number", 1)),
                last_modified=_parse_dt(r.get("version", {}).get("when")),
            )
            for r in data.get("results", [])
        )
        next_cursor = _extract_cursor(data.get("_links", {}).get("next"))
        return PageListing(refs=refs, next_cursor=next_cursor)

    async def get_page(self, page_id) -> Page:
        params = {"expand": "body.atlas_doc_format,version,ancestors,space"}
        r = await self._get(f"/wiki/rest/api/content/{page_id}", params)
        adf_raw = r.get("body", {}).get("atlas_doc_format", {}).get("value", "{}")
        adf = json.loads(adf_raw) if isinstance(adf_raw, str) else adf_raw
        ancestors = tuple(Ancestor(str(a["id"]), a.get("title", "")) for a in r.get("ancestors", []))
        webui = r.get("_links", {}).get("webui", "")
        base = r.get("_links", {}).get("base", self._base + "/wiki")
        return Page(
            page_id=str(r["id"]), space_key=r.get("space", {}).get("key", ""),
            title=r.get("title", ""), version=int(r.get("version", {}).get("number", 1)),
            url=f"{base}{webui}", ancestors=ancestors, body_adf=adf,
            last_modified=_parse_dt(r.get("version", {}).get("when")),
        )


def _parse_dt(value: str | None) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None


def _extract_cursor(next_link: str | None) -> str | None:
    if not next_link or "cursor=" not in next_link:
        return None
    return next_link.split("cursor=", 1)[1].split("&", 1)[0]
