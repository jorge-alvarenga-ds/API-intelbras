"""Construção do header de autenticação da conta de serviço.

Confluence Cloud com **API token** => Basic ``base64(email:token)``.
OAuth 2.0 / PAT (Data Center) => ``Bearer <token>``.
Regra: se houver e-mail, usa Basic; senão, Bearer.
"""

from __future__ import annotations

import base64


def service_auth_header(token: str, email: str = "") -> str:
    if email:
        raw = base64.b64encode(f"{email}:{token}".encode()).decode()
        return f"Basic {raw}"
    return f"Bearer {token}"
