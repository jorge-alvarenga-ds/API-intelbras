"""DirectorySource real (Confluence Cloud). Consulta invertida grupo -> membros.

Adaptador de produção (não exercitado nos testes). Grupos aninhados dependem do IdP; a
expansão recursiva é aplicada quando o diretório os expõe.
"""

from __future__ import annotations

from rag_confluence.ports.directory_source import Group


class ConfluenceDirectorySource:
    def __init__(self, base_url: str, auth_header: str, http_client=None, timeout: float = 30.0):
        self._base = base_url.rstrip("/")
        self._auth = auth_header
        self._client = http_client
        self._timeout = timeout

    def _headers(self) -> dict:
        return {"Authorization": self._auth, "Accept": "application/json"}

    async def _get_all(self, path: str, results_key: str = "results") -> list[dict]:
        import httpx

        client = self._client or httpx.AsyncClient(timeout=self._timeout)
        owns = self._client is None
        out: list[dict] = []
        start = 0
        try:
            while True:
                resp = await client.get(
                    f"{self._base}{path}", headers=self._headers(),
                    params={"limit": 200, "start": start},
                )
                resp.raise_for_status()
                data = resp.json()
                batch = data.get(results_key, [])
                out.extend(batch)
                if len(batch) < 200:
                    break
                start += 200
            return out
        finally:
            if owns:
                await client.aclose()

    async def list_groups(self) -> list[Group]:
        rows = await self._get_all("/wiki/rest/api/group")
        return [Group(id=str(g["id"]), name=g.get("name", "")) for g in rows if g.get("id")]

    async def list_group_members(self, group_id) -> list[str]:
        rows = await self._get_all(f"/wiki/rest/api/group/{group_id}/membersByGroupId")
        return [str(u["accountId"]) for u in rows if u.get("accountId")]
