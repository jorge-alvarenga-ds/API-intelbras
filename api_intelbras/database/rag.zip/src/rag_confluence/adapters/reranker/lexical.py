"""RerankerPort de referência: sobreposição lexical query↔chunk (sem modelo pesado).

Adaptador v1 runnable. Em produção, trocar por ``bge-reranker-v2-m3`` local via config.
Score 0 = nenhuma sobreposição de conteúdo (aciona "não encontrei" a jusante).
"""

from __future__ import annotations

from rag_confluence.domain.models import Scored
from rag_confluence.domain.text import tokenize


class LexicalReranker:
    def rerank(self, query: str, candidates: list[Scored], top_k: int) -> list[Scored]:
        q_terms = set(tokenize(query))
        if not q_terms:
            return [Scored(chunk=c.chunk, score=0.0) for c in candidates[:top_k]]

        def rerank_score(s: Scored) -> float:
            toks = tokenize(s.chunk.text)
            if not toks:
                return 0.0
            overlap = sum(1 for t in toks if t in q_terms)
            coverage = len(q_terms & set(toks)) / len(q_terms)
            return overlap + coverage

        ranked = sorted(candidates, key=lambda s: (rerank_score(s), s.score), reverse=True)
        return [Scored(chunk=s.chunk, score=rerank_score(s)) for s in ranked[:top_k]]
