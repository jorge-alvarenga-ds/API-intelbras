"""Reranker passthrough: mantém a ordem/score da fusão (recuperação semântica).

Use quando o embedding já é semântico (Gemini) — aí o ranking denso é bom e um reranker
lexical de referência só atrapalharia. Em produção, o ideal é um reranker dedicado
(bge-reranker-v2-m3) com score calibrado.
"""

from __future__ import annotations

from rag_confluence.domain.models import Scored


class PassthroughReranker:
    def rerank(self, query: str, candidates: list[Scored], top_k: int) -> list[Scored]:
        return candidates[:top_k]
