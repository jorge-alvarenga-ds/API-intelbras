"""RerankerPort de produção: bge-reranker-v2-m3 local (multilíngue, soberania do dado)."""

from __future__ import annotations

from rag_confluence.domain.models import Scored


class BgeReranker:
    def __init__(self, model_name: str = "BAAI/bge-reranker-v2-m3", use_fp16: bool = True):
        self._model_name = model_name
        self._use_fp16 = use_fp16
        self._reranker = None

    def _load(self):
        if self._reranker is None:
            from FlagEmbedding import FlagReranker

            self._reranker = FlagReranker(self._model_name, use_fp16=self._use_fp16)
        return self._reranker

    def rerank(self, query: str, candidates: list[Scored], top_k: int) -> list[Scored]:
        if not candidates:
            return []
        model = self._load()
        pairs = [[query, c.chunk.text] for c in candidates]
        scores = model.compute_score(pairs, normalize=True)
        if not isinstance(scores, list):
            scores = [scores]
        rescored = [Scored(chunk=c.chunk, score=float(s)) for c, s in zip(candidates, scores)]
        rescored.sort(key=lambda s: s.score, reverse=True)
        return rescored[:top_k]
