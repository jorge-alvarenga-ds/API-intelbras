"""EmbeddingPort de produção: Vertex AI / Gemini com task_type distinto (lazy import)."""

from __future__ import annotations


class VertexEmbedding:
    def __init__(self, model: str = "text-embedding-004", dim: int = 768, project: str | None = None):
        self.dim = dim
        self._model_name = model
        self._project = project

    def _model(self):
        from vertexai.language_models import TextEmbeddingModel

        return TextEmbeddingModel.from_pretrained(self._model_name)

    async def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return self._embed(texts, "RETRIEVAL_DOCUMENT")

    async def embed_query(self, text: str) -> list[float]:
        return self._embed([text], "RETRIEVAL_QUERY")[0]

    def _embed(self, texts: list[str], task_type: str) -> list[list[float]]:
        from vertexai.language_models import TextEmbeddingInput

        inputs = [TextEmbeddingInput(text=t, task_type=task_type) for t in texts]
        return [e.values for e in self._model().get_embeddings(inputs)]
