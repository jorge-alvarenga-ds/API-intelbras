"""EmbeddingPort de referência: hashing determinístico (numpy, sem rede).

Adaptador v1 runnable para testes e execução local. Determinístico e sem dependência
externa. Em produção, trocar por Vertex/Gemini (task_type distinto) via configuração.
O ``task_type`` é preservado como sal para diferenciar documento de query.
"""

from __future__ import annotations

import hashlib

import numpy as np

from rag_confluence.domain.text import tokenize


class HashingEmbedding:
    def __init__(self, dim: int = 256) -> None:
        self.dim = dim

    async def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return [self._embed(t, "RETRIEVAL_DOCUMENT") for t in texts]

    async def embed_query(self, text: str) -> list[float]:
        return self._embed(text, "RETRIEVAL_QUERY")

    def _embed(self, text: str, task_type: str) -> list[float]:
        vec = np.zeros(self.dim, dtype=np.float32)
        for tok in tokenize(text):
            # task_type não altera o espaço (query e doc precisam ser comparáveis),
            # mas é aplicado como namespace para refletir o contrato do provedor real.
            h = hashlib.blake2b(tok.encode("utf-8"), digest_size=8).digest()
            idx = int.from_bytes(h[:4], "little") % self.dim
            sign = 1.0 if h[4] & 1 else -1.0
            vec[idx] += sign
        norm = np.linalg.norm(vec)
        if norm > 0:
            vec /= norm
        return vec.tolist()
