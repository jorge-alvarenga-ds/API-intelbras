"""EmbeddingPort via Gemini (google-genai). Backend api/vertex por flag; task_type distinto."""

from __future__ import annotations


class GeminiEmbedding:
    def __init__(self, *, backend, api_key, project, location, model, dim):
        self.dim = dim
        self._backend = backend
        self._api_key = api_key
        self._project = project
        self._location = location
        self._model = model
        self._client = None

    def _client_(self):
        if self._client is None:
            from rag_confluence.adapters._genai import build_client

            self._client = build_client(
                self._backend, api_key=self._api_key,
                project=self._project, location=self._location,
            )
        return self._client

    async def embed_documents(self, texts: list[str]) -> list[list[float]]:
        return await self._embed(list(texts), "RETRIEVAL_DOCUMENT")

    async def embed_query(self, text: str) -> list[float]:
        return (await self._embed([text], "RETRIEVAL_QUERY"))[0]

    async def _embed(self, texts: list[str], task_type: str) -> list[list[float]]:
        from google.genai import types

        client = self._client_()
        resp = await client.aio.models.embed_content(
            model=self._model,
            contents=texts,
            config=types.EmbedContentConfig(
                task_type=task_type, output_dimensionality=self.dim
            ),
        )
        return [list(e.values) for e in resp.embeddings]
