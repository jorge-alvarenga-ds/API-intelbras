"""VectorStore de referência: numpy in-memory com PRÉ-FILTRO de principals.

Adaptador v1 runnable (sem chromadb). Implementa o contrato de :class:`VectorStorePort`
e é validado pela suíte de conformidade C1–C8. O pré-filtro é aplicado ANTES do ranking
(interseção de principals), nunca como pós-filtro.
"""

from __future__ import annotations

from collections.abc import Sequence

import numpy as np

from rag_confluence.domain.acl.principals import intersects
from rag_confluence.domain.models import Chunk, Scored


class InMemoryVectorStore:
    def __init__(self) -> None:
        self._chunks: dict[str, Chunk] = {}
        self._vectors: dict[str, np.ndarray] = {}
        self._allowed: dict[str, frozenset[str]] = {}

    # ------------------------------------------------------------------ writes
    def upsert(self, chunks: list[Chunk]) -> None:
        # Idempotente por page_id: remove chunks anteriores das páginas afetadas.
        pages = {c.page_id for c in chunks}
        for pid in pages:
            self.delete_by_page(pid)
        for c in chunks:
            if c.embedding is None:
                raise ValueError(f"chunk {c.chunk_id} sem embedding")
            self._chunks[c.chunk_id] = c
            self._vectors[c.chunk_id] = _normalize(np.asarray(c.embedding, dtype=np.float32))
            self._allowed[c.chunk_id] = frozenset(c.allowed_principals)

    def delete_by_page(self, page_id: str) -> None:
        for cid in [c for c, ch in self._chunks.items() if ch.page_id == page_id]:
            self._chunks.pop(cid, None)
            self._vectors.pop(cid, None)
            self._allowed.pop(cid, None)

    # ------------------------------------------------------------------ reads
    def search_dense(
        self, query_vec: Sequence[float], principals: Sequence[str], k: int
    ) -> list[Scored]:
        principal_set = set(principals)
        if not principal_set:
            return []  # C4: sem principals => nada visível (nunca "tudo")
        q = _normalize(np.asarray(query_vec, dtype=np.float32))

        scored: list[Scored] = []
        for cid, allowed in self._allowed.items():
            # PRÉ-FILTRO antes de qualquer ranking (C1/C2/C8).
            if not intersects(allowed, principal_set):
                continue
            sim = float(np.dot(self._vectors[cid], q))
            scored.append(Scored(chunk=self._chunks[cid], score=sim))
        scored.sort(key=lambda s: s.score, reverse=True)
        return scored[:k]

    def count(self) -> int:
        return len(self._chunks)


def _normalize(v: np.ndarray) -> np.ndarray:
    n = np.linalg.norm(v)
    return v / n if n > 0 else v
