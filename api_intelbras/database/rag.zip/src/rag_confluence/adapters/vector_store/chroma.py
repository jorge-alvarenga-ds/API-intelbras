"""VectorStore de produção: Chroma, com pré-filtro de principals materializado.

Metadados do Chroma são escalares — ``allowed_principals`` como lista não é filtrável
nativamente (o ponto onde a abstração vaza, R1). Este adaptador materializa cada principal
como chave booleana ``acl:{principal}`` e monta um ``$or`` no ``where``. Deve passar a
suíte de conformidade C1–C8 antes de ser considerado apto a produção (FR-028).

Import de chromadb é tardio para não exigir a dependência no caminho runnable padrão.
"""

from __future__ import annotations

from collections.abc import Sequence

from rag_confluence.domain.models import Chunk, Scored


class EmbeddingDimMismatch(RuntimeError):
    """Índice criado com outra dimensão (mudou o modelo de embedding)."""


def _acl_key(principal: str) -> str:
    return f"acl:{principal}"


def _reraise_dim(exc: Exception) -> None:
    if "dimension" in str(exc).lower():
        raise EmbeddingDimMismatch(
            f"{exc} — o modelo de embedding mudou. Pare o servidor, apague a pasta ./data "
            "e rode /sync novamente para reconstruir o índice na nova dimensão."
        ) from exc
    raise exc


class ChromaVectorStore:
    def __init__(self, path: str | None = None, collection: str = "chunks"):
        import chromadb

        self._client = chromadb.PersistentClient(path) if path else chromadb.EphemeralClient()
        self._col = self._client.get_or_create_collection(collection, metadata={"hnsw:space": "cosine"})

    def upsert(self, chunks: list[Chunk]) -> None:
        for page_id in {c.page_id for c in chunks}:
            self.delete_by_page(page_id)
        ids, embeddings, documents, metadatas = [], [], [], []
        for c in chunks:
            if c.embedding is None:
                raise ValueError(f"chunk {c.chunk_id} sem embedding")
            meta = {
                "page_id": c.page_id, "space_key": c.space_key, "url": c.url,
                "breadcrumb": c.breadcrumb, "heading_path": c.heading_path,
                "version": c.version, "title": c.title,
            }
            for p in c.allowed_principals:  # materialização booleana do principal
                meta[_acl_key(p)] = True
            ids.append(c.chunk_id)
            embeddings.append(list(c.embedding))
            documents.append(c.text)
            metadatas.append(meta)
        if ids:
            try:
                self._col.add(
                    ids=ids, embeddings=embeddings, documents=documents, metadatas=metadatas
                )
            except Exception as exc:  # noqa: BLE001
                _reraise_dim(exc)

    def delete_by_page(self, page_id: str) -> None:
        self._col.delete(where={"page_id": page_id})

    def search_dense(self, query_vec: Sequence[float], principals: Sequence[str], k: int) -> list[Scored]:
        principal_list = list(dict.fromkeys(principals))
        if not principal_list:
            return []  # C4
        where = {"$or": [{_acl_key(p): True} for p in principal_list]}
        if len(principal_list) == 1:
            where = {_acl_key(principal_list[0]): True}
        try:
            res = self._col.query(query_embeddings=[list(query_vec)], n_results=k, where=where)
        except Exception as exc:  # noqa: BLE001
            _reraise_dim(exc)
        out: list[Scored] = []
        ids = res.get("ids", [[]])[0]
        docs = res.get("documents", [[]])[0]
        metas = res.get("metadatas", [[]])[0]
        dists = res.get("distances", [[]])[0]
        for cid, doc, meta, dist in zip(ids, docs, metas, dists):
            chunk = Chunk(
                chunk_id=cid, page_id=meta["page_id"], chunk_index=0, space_key=meta["space_key"],
                text=doc, allowed_principals=(), breadcrumb=meta.get("breadcrumb", ""),
                heading_path=meta.get("heading_path", ""), url=meta.get("url", ""),
                version=meta.get("version", 1), title=meta.get("title", ""),
            )
            out.append(Scored(chunk=chunk, score=1.0 - float(dist)))
        return out

    def count(self) -> int:
        return self._col.count()
