"""NoOpAccessVerifier (Fase A): aprova tudo, mas PERMANECE no fluxo.

A segurança da Fase A vem do escopo (só espaços irrestritos são indexados), não deste
adaptador. Retirar a etapa do código obrigaria a redesenhar over-fetch/retry ao
reintroduzi-la — por isso ela nunca é removida, apenas neutralizada por configuração.
"""

from __future__ import annotations


class NoOpAccessVerifier:
    name = "NoOpAccessVerifier"

    async def verify(
        self, account_id: str, page_ids: list[str], user_token: str | None
    ) -> set[str]:
        return set(page_ids)
