"""ConfluenceCqlVerifier (Fase B): verificação final com o TOKEN DO USUÁRIO.

Consulta o Confluence com CQL ``id in (...)`` usando a credencial do próprio usuário.
FAIL-CLOSED: qualquer page_id que não seja explicitamente confirmado como legível NÃO
entra no conjunto autorizado — incluindo timeout, 5xx e erros de rede (FR-007, FR-011).

O token do usuário é obrigatório; a conta de serviço NUNCA é usada aqui (FR-011).
"""

from __future__ import annotations

import logging

log = logging.getLogger("rag_confluence.access_verifier")


class ConfluenceCqlVerifier:
    name = "ConfluenceCqlVerifier"

    def __init__(self, base_url: str, http_client=None, timeout: float = 5.0) -> None:
        self._base_url = base_url.rstrip("/")
        self._client = http_client  # httpx.AsyncClient injetado; criado sob demanda se None
        self._timeout = timeout

    async def verify(
        self, account_id: str, page_ids: list[str], user_token: str | None
    ) -> set[str]:
        if not page_ids:
            return set()
        if not user_token:
            # Sem token do usuário não há como verificar => fail-closed total.
            log.warning("verify sem user_token na Fase B; fail-closed", extra={"account_id": account_id})
            return set()
        try:
            return await self._query_confluence(page_ids, user_token)
        except Exception as exc:  # timeout / rede / 5xx => fail-closed
            log.warning("verify falhou; fail-closed: %s", exc, extra={"account_id": account_id})
            return set()

    async def _query_confluence(self, page_ids: list[str], user_token: str) -> set[str]:
        import httpx  # import tardio: infraestrutura não entra no import-time do núcleo

        ids = ",".join(page_ids)
        cql = f"id in ({ids})"
        headers = {"Authorization": f"Bearer {user_token}", "Accept": "application/json"}
        params = {"cql": cql, "limit": len(page_ids)}
        client = self._client or httpx.AsyncClient(timeout=self._timeout)
        owns_client = self._client is None
        try:
            resp = await client.get(f"{self._base_url}/wiki/rest/api/search", headers=headers, params=params)
            if resp.status_code != 200:
                return set()  # fail-closed em qualquer status não-OK
            data = resp.json()
            approved = {
                str(item.get("content", {}).get("id"))
                for item in data.get("results", [])
                if item.get("content", {}).get("id")
            }
            # Só retorna os que estavam na lista pedida e foram confirmados.
            return {pid for pid in page_ids if pid in approved}
        finally:
            if owns_client:
                await client.aclose()
