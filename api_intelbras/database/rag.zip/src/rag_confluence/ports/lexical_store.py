"""Porta de armazenamento lexical (BM25). Mesmo pré-filtro de principals do vetorial."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Protocol, runtime_checkable

from rag_confluence.domain.models import Chunk, Scored


@runtime_checkable
class LexicalStorePort(Protocol):
    def index(self, chunks: list[Chunk]) -> None: ...

    def delete_by_page(self, page_id: str) -> None: ...

    def search_bm25(
        self, query: str, principals: Sequence[str], k: int
    ) -> list[Scored]:
        """Busca lexical PRÉ-FILTRADA por principals."""
        ...
