"""Porta de origem de ACL. NOTA: restrições vivem na API v1 do Confluence."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from rag_confluence.domain.models import Restrictions, SpacePermissions


@runtime_checkable
class AclSourcePort(Protocol):
    async def get_page_restrictions(self, page_id: str) -> Restrictions: ...

    async def get_space_permissions(self, space_key: str) -> SpacePermissions: ...
