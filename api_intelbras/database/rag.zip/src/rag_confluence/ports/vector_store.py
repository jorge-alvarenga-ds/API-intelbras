"""Porta de armazenamento vetorial. O pré-filtro de principals é OBRIGATÓRIO e interno."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Protocol, runtime_checkable

from rag_confluence.domain.models import Chunk, Scored


@runtime_checkable
class VectorStorePort(Protocol):
    def upsert(self, chunks: list[Chunk]) -> None:
        """Idempotente por page_id."""
        ...

    def delete_by_page(self, page_id: str) -> None: ...

    def search_dense(
        self, query_vec: Sequence[float], principals: Sequence[str], k: int
    ) -> list[Scored]:
        """Busca densa PRÉ-FILTRADA por ``allowed_principals ∩ principals`` (nunca pós-filtro)."""
        ...

    def count(self) -> int: ...
