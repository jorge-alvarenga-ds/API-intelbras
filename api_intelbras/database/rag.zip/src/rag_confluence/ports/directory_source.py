"""Porta de diretório: grupos e membros (consulta invertida, expansão recursiva)."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable


@dataclass(frozen=True)
class Group:
    id: str
    name: str


@runtime_checkable
class DirectorySourcePort(Protocol):
    async def list_groups(self) -> list[Group]: ...

    async def list_group_members(self, group_id: str) -> list[str]:
        """accountIds do grupo, com grupos aninhados expandidos recursivamente."""
        ...
