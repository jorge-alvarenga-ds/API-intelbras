"""Porta de identidade: token do SSO -> accountId do Confluence."""

from __future__ import annotations

from typing import Protocol, runtime_checkable


class IdentityError(RuntimeError):
    """Token inválido ou sem mapeamento para accountId."""


@runtime_checkable
class IdentityPort(Protocol):
    async def resolve_account_id(self, user_token: str) -> str: ...
