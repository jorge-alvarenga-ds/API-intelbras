"""Porta de reranking (reordena candidatos por relevância)."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from rag_confluence.domain.models import Scored


@runtime_checkable
class RerankerPort(Protocol):
    def rerank(self, query: str, candidates: list[Scored], top_k: int) -> list[Scored]: ...
