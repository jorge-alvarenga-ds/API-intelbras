"""Porta de exclusão mútua entre réplicas."""

from __future__ import annotations

from contextlib import AbstractContextManager
from typing import Protocol, runtime_checkable


class LockHeld(RuntimeError):
    """O lock do escopo já está tomado por outro worker/réplica."""


@runtime_checkable
class LockPort(Protocol):
    def acquire(self, scope: str) -> AbstractContextManager[None]:
        """Context manager que detém o lock; levanta :class:`LockHeld` se indisponível."""
        ...
