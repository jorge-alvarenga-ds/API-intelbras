"""Portas de entrada (driving): casos de uso expostos por HTTP e CLI."""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from rag_confluence.domain.models import QueryResult, SyncJob, SyncMode


@runtime_checkable
class QueryServicePort(Protocol):
    async def answer(self, question: str, user_token: str, top_k: int = 5) -> QueryResult: ...


@runtime_checkable
class SyncServicePort(Protocol):
    async def start(self, scope: list[str] | None, mode: SyncMode) -> str: ...
    def status(self, job_id: str) -> SyncJob | None: ...
    def current(self) -> SyncJob | None: ...
    def cancel(self, job_id: str) -> SyncJob | None: ...
