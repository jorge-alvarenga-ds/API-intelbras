"""Porta de verificação final de acesso (fronteira de segurança da Fase B).

Contrato fail-closed: ``verify`` retorna APENAS os page_ids confirmados como autorizados.
Em timeout/erro/indisponibilidade, um page_id não confirmado NÃO entra no conjunto.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class AccessVerifierPort(Protocol):
    name: str

    async def verify(
        self, account_id: str, page_ids: list[str], user_token: str | None
    ) -> set[str]:
        """Retorna o subconjunto de ``page_ids`` autorizados para o usuário."""
        ...
