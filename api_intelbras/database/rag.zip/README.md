# Confluence RAG API

API de RAG sobre a documentação interna no Confluence Cloud, com **enforcement de ACL por usuário**.
Arquitetura **hexagonal**: núcleo de domínio puro por trás de portas; adaptadores descartáveis no v1
(in-memory/SQLite) e alvos de produção (Chroma/pgvector, Vertext/Gemini, bge-reranker) por trás das
mesmas portas.

Especificação viva em [`specs/001-confluence-rag-acl/`](specs/001-confluence-rag-acl/) · governança em
[`.specify/memory/constitution.md`](.specify/memory/constitution.md).

## Estrutura

```
src/rag_confluence/
  domain/     # núcleo puro (ADF→MD, chunking, ACL efetiva, principals, RRF, prompt) — sem infra
  ports/      # Protocols (driven + driving)
  adapters/   # confluence/, vector_store/, lexical_store/, metadata_store/, embedding/, ...
  app/        # config, composição/DI, logging, tracing, services/, http/ (FastAPI), cli/
evaluation/   # golden set + DeepEval (gate de qualidade)
tests/        # unit, conformance (C1–C8), integration, adversarial, contract
```

## Rodar

```bash
pip install -e ".[dev]"
pytest                      # suíte completa (runnable com adaptadores de referência)
python evaluation/run_eval.py   # gate de avaliação (Princípio IV)
uvicorn rag_confluence.main:app # sobe a API (config via env RAG_*)
```

CLI operacional:

```bash
python -m rag_confluence.app.cli.main sync --mode full
python -m rag_confluence.app.cli.main query "como faço a rotação do refresh token?" --token <user-token>
```

## Configuração (env `RAG_*`)

| Var | Default | Descrição |
|---|---|---|
| `RAG_ACL_PHASE` | `A` | Fase de ACL (A: escopo; B: verificação final com token do usuário) |
| `RAG_ALLOWLIST` | `ARQ,ENG` | Allowlist versionada de espaços |
| `RAG_VECTOR_STORE` | `inmemory` | `inmemory` (v1) ou `chroma` (produção) |
| `RAG_OPERATOR_TOKEN` | — | Credencial do papel de operador (`/sync*`) |

Ver adaptadores de produção e o gate de conformidade em [`docs/security.md`](docs/security.md).

## Endpoints

- `POST /query` (Bearer do usuário) → resposta fundamentada + `sources[]` + `trace_id`.
- `POST /sync`, `GET /sync/{id}`, `GET /sync/current`, `POST /sync/{id}/cancel` (papel de operador).
- `GET /health` → `acl_phase` + `verifier_adapter` ativos.

Contrato completo em [`specs/001-confluence-rag-acl/contracts/openapi.yaml`](specs/001-confluence-rag-acl/contracts/openapi.yaml).

> **Gate de segurança**: nenhum espaço com restrição é indexado antes da Fase B concluída e do teste
> adversarial limpo. A stack v1 (SQLite/Chroma) só é apta a produção após passar a suíte de
> conformidade C1–C8.
