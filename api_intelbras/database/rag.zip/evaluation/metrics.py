"""Métricas de avaliação (Princípio IV). DeepEval é opcional; há fallback leve runnable."""

from __future__ import annotations

from statistics import mean

# Limiares (spec Success Criteria)
SOURCE_HIT_THRESHOLD = 0.80        # SC-002
WRONG_NOT_FOUND_THRESHOLD = 0.10   # SC-006


def deepeval_available() -> bool:
    try:
        import deepeval  # noqa: F401

        return True
    except Exception:
        return False


def source_hit(expected_ids: list[str], source_ids: list[str]) -> bool:
    return any(e in source_ids for e in expected_ids)


def summarize(rows: list[dict]) -> dict:
    answerable = [r for r in rows if r["answerable"]]
    unanswerable = [r for r in rows if not r["answerable"]]
    source_hit_rate = mean([r["hit"] for r in answerable]) if answerable else 0.0
    wrong_not_found = (
        mean([0.0 if r["found"] else 1.0 for r in answerable]) if answerable else 0.0
    )
    false_answer_rate = (
        mean([1.0 if r["found"] else 0.0 for r in unanswerable]) if unanswerable else 0.0
    )
    passed = (
        source_hit_rate >= SOURCE_HIT_THRESHOLD
        and wrong_not_found <= WRONG_NOT_FOUND_THRESHOLD
        and false_answer_rate == 0.0
    )
    return {
        "source_hit_rate": round(source_hit_rate, 3),
        "wrong_not_found_rate": round(wrong_not_found, 3),
        "false_answer_rate": round(false_answer_rate, 3),
        "passed": passed,
        "n": len(rows),
    }
