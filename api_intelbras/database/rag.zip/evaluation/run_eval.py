"""Gate de avaliação (Princípio IV). Executar como script: ``python evaluation/run_eval.py``.

Constrói uma base de demonstração, roda o golden set pela pipeline de consulta e produz
métricas + relatório HTML. Em produção, o juiz é Gemini (DeepEval) e o corpus é o índice
real; aqui usamos os adaptadores de referência para manter o gate runnable. Sai com código
!= 0 se os limiares da spec não forem atingidos (uso em CI).
"""

from __future__ import annotations

import asyncio
import json
import pathlib
import sys

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "src"))

from rag_confluence.adapters.fakes.confluence import FakeConfluence  # noqa: E402
from rag_confluence.app.composition import build_container  # noqa: E402
from rag_confluence.app.config import Settings  # noqa: E402
from rag_confluence.domain.models import AclPhase, SyncMode  # noqa: E402

from metrics import deepeval_available, source_hit, summarize  # noqa: E402

HERE = pathlib.Path(__file__).resolve().parent
LONG = " Documentação interna com detalhes suficientes e vocabulário do domínio bancário. " * 3


def _para(t):
    return {"type": "paragraph", "content": [{"type": "text", "text": t}]}


def _seed(fake: FakeConfluence) -> None:
    fake.add_space("ARQ", is_open=True)
    fake.add_page("P1", "ARQ", "Rotação de Refresh Token OAuth",
                  {"content": [_para("Para fazer a rotação do refresh token no OAuth interno." + LONG)]})
    fake.add_page("P2", "ARQ", "Pipeline de Deploy",
                  {"content": [_para("O pipeline de deploy executa build e testes automatizados." + LONG)]})


async def run() -> dict:
    settings = Settings(acl_phase=AclPhase.A, allowlist=["ARQ"], embedding_dim=128)
    fake = FakeConfluence()
    _seed(fake)
    container = build_container(settings, confluence=fake, identity_map={"u": "acc1"})
    await container.sync_service.run_sync(["ARQ"], SyncMode.FULL)

    golden = json.loads((HERE / "golden_set" / "golden.json").read_text(encoding="utf-8"))
    rows = []
    for item in golden:
        res = await container.query_service.answer(item["question"], "u")
        source_ids = [s.page_id for s in res.sources]
        rows.append({
            "question": item["question"],
            "answerable": item.get("answerable", True),
            "found": res.found,
            "sources": source_ids,
            "hit": source_hit(item.get("expected_source_page_ids", []), source_ids),
            "answer": res.answer,
        })
    return {"rows": rows, "summary": summarize(rows)}


def _html(report: dict) -> str:
    s = report["summary"]
    rows_html = "".join(
        f"<tr><td>{r['question']}</td><td>{'sim' if r['answerable'] else 'não'}</td>"
        f"<td>{'sim' if r['found'] else 'não'}</td><td>{', '.join(r['sources']) or '—'}</td>"
        f"<td>{'ok' if r['hit'] else 'x'}</td></tr>"
        for r in report["rows"]
    )
    status = "PASS" if s["passed"] else "FAIL"
    color = "#0a7d33" if s["passed"] else "#b00020"
    return f"""<!doctype html><html lang=pt-BR><meta charset=utf-8>
<title>Avaliação — Confluence RAG API</title>
<style>body{{font-family:system-ui,Arial;margin:2rem;color:#1a1a1a}}
h1{{color:#003a70}} .badge{{color:#fff;background:{color};padding:.3rem .8rem;border-radius:6px}}
table{{border-collapse:collapse;width:100%;margin-top:1rem}} td,th{{border:1px solid #ddd;padding:.5rem;text-align:left}}
th{{background:#f0f4f8}} .kpi{{display:inline-block;margin-right:2rem}}</style>
<h1>Avaliação — Confluence RAG API <span class=badge>{status}</span></h1>
<p class=kpi><b>source_hit_rate</b>: {s['source_hit_rate']} (alvo ≥ 0.80)</p>
<p class=kpi><b>wrong_not_found</b>: {s['wrong_not_found_rate']} (alvo ≤ 0.10)</p>
<p class=kpi><b>false_answer_rate</b>: {s['false_answer_rate']} (alvo 0)</p>
<table><tr><th>Pergunta</th><th>Respondível</th><th>Encontrou</th><th>Fontes</th><th>Hit</th></tr>
{rows_html}</table>
<p style=color:#666>DeepEval disponível: {deepeval_available()} — em produção, juiz Gemini + corpus real.</p>
</html>"""


def main() -> int:
    report = asyncio.run(run())
    reports_dir = HERE / "reports"
    reports_dir.mkdir(exist_ok=True)
    (reports_dir / "report.html").write_text(_html(report), encoding="utf-8")
    s = report["summary"]
    print(json.dumps(s, ensure_ascii=False))
    print(f"relatório: {reports_dir / 'report.html'}")
    return 0 if s["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
