# Implementation Plan: RAG sobre Confluence Cloud com ACL por usuário

**Branch**: `001-confluence-rag-acl` | **Date**: 2026-08-11 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `specs/001-confluence-rag-acl/spec.md`

## Summary

API de RAG sobre a documentação interna do banco no Confluence Cloud, com enforcement de ACL por
usuário. O sistema ingere os espaços de uma allowlist versionada, converte ADF → Markdown, faz
chunking hierárquico com breadcrumb, resolve a ACL efetiva de cada página em `allowed_principals`
(group IDs), e serve respostas fundamentadas e citadas via busca híbrida (BM25 + densa) com
**pré-filtro** por principals, reranking e uma **verificação final fail-closed** de acesso.

A abordagem técnica é **arquitetura hexagonal**: um núcleo de domínio puro (sem I/O) por trás de
portas, com adaptadores descartáveis para o v1 (SQLite + Chroma) e alvos de produção (Postgres +
pgvector). O enforcement de ACL é **faseado**: Fase A (segurança por escopo — só espaços
irrestritos, `NoOpAccessVerifier` no fluxo) → Fase B (verificação final com o token do próprio
usuário). A troca de adaptadores e de fase é **configuração, não código**, protegida por uma suíte
de conformidade de adaptador com casos negativos de ACL como gate de produção.

## Technical Context

**Language/Version**: Python 3.11+ (async I/O; `ProcessPoolExecutor` para parsing CPU-bound)

**Primary Dependencies**: FastAPI + Uvicorn (adaptadores HTTP driving), Pydantic v2 (contratos/DTO
e configuração), httpx (cliente async Confluence v1/v2), Chroma (VectorStorePort v1), SQLite FTS5
(LexicalStorePort v1) e SQLite (MetadataStorePort v1), Typer (CLI operacional), Tenacity (retry/
backoff), structlog (logs estruturados), OpenTelemetry (tracing). Reranker `bge-reranker-v2-m3`
local (FlagEmbedding/sentence-transformers). Embedding e geração por **provedor configurável** (default
Vertex AI / Gemini, com `task_type` distinto para documento vs. query). DeepEval para avaliação.

**Storage**: v1 — SQLite (metadados, jobs, checkpoints, cache de grupos, índice FTS5 lexical) +
Chroma (vetores). Produção — PostgreSQL + pgvector (vetores + FTS + advisory locks), atrás das
mesmas portas. Criptografia em repouso com chave gerenciada pela organização.

**Testing**: pytest (unit do núcleo sem infraestrutura), **suíte de conformidade de adaptador**
(parametrizada por implementação de `VectorStorePort`/`LexicalStorePort`), testes de integração,
teste **adversarial de ACL**, testes de contrato da API (schemathesis sobre a OpenAPI). Avaliação de
qualidade por DeepEval executada como script (`python evaluation/...`), não pytest.

**Target Platform**: Servidor Linux containerizado, exposto apenas em rede interna (sem exposição
pública). Consumido por agentes/BFF internos.

**Project Type**: Web service (API) — projeto backend único, organização hexagonal.

**Performance Goals**: Latência p95 da consulta < 3 s ponta a ponta (inclui rerank + verificação
final); sync incremental < 15 min; lag de conteúdo ≤ 1 h; falha de parsing < 2% das páginas.

**Constraints**: ACL fail-closed; token do usuário nunca na ingestão e conta de serviço nunca na
verificação final; principals por group ID imutável; nenhum `import` de infraestrutura no núcleo
(regra de lint em CI); worker de ingestão em réplica única no v1 (limite do `LockPort` sobre SQLite).

**Scale/Scope**: Corpus da allowlist na casa de milhares de páginas no v1 (alvo de projeto até
dezenas de milhares). Carga de consulta em escala de piloto (dezenas de consultas concorrentes).
Estes números orientam o gatilho de migração para a stack de produção (ver research.md).

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

Avaliação contra a constituição v1.0.0:

| Princípio / Seção | Como o plano satisfaz | Status |
|---|---|---|
| I. Respostas Fundamentadas e Citadas | Prompt montado no núcleo apenas com chunks sobreviventes; resposta sempre com `sources[]`; "não encontrei" quando o contexto é vazio (FR-001/002/010) | ✅ PASS |
| II. Recuperação Consciente de Permissões | Pré-filtro por principals no store + verificação final fail-closed com token do usuário (Fase B); Fase A limitada a espaços irrestritos (FR-006–011) | ✅ PASS |
| III. Contrato de API em Primeiro Lugar | OpenAPI versionada em `contracts/openapi.yaml` antes da implementação; DTOs Pydantic; testes de contrato (FR-005) | ✅ PASS |
| IV. Qualidade Guiada por Avaliação | Golden set + DeepEval (`ContextualPrecisionMetric`, faithfulness, relevância); gate de eval antes de deploy que altere o RAG | ✅ PASS |
| V. Observabilidade e Rastreabilidade | `trace_id` ponta a ponta, logs estruturados de consulta e ingestão, OpenTelemetry, mascaramento (FR-024) | ✅ PASS |
| Segurança, Privacidade e Governança de Dados | Segredos em cofre, criptografia em repouso, rede interna, allowlist versionada, reconciliação de exclusões (FR-014/020/025) | ✅ PASS |
| Fluxo de Desenvolvimento e Portões de Qualidade | Fluxo Spec Kit; testes + suíte de conformidade como gate; núcleo sem import de infra verificado por lint (FR-027/028) | ✅ PASS |

**Resultado**: Nenhuma violação. Não há necessidade de Complexity Tracking. A arquitetura hexagonal
não é complexidade injustificada — é o mecanismo que satisfaz o Princípio II (substituir store sem
reabrir a discussão de segurança) e o Princípio IV.

## Project Structure

### Documentation (this feature)

```text
specs/001-confluence-rag-acl/
├── plan.md              # This file (/speckit-plan command output)
├── research.md          # Phase 0 output
├── data-model.md        # Phase 1 output
├── quickstart.md        # Phase 1 output
├── contracts/           # Phase 1 output
│   ├── openapi.yaml      # Contrato HTTP (query + sync)
│   └── ports.md          # Contratos das portas + suíte de conformidade
├── checklists/
│   └── requirements.md  # Spec quality checklist (/speckit-specify)
└── tasks.md             # Phase 2 output (/speckit-tasks — NOT created here)
```

### Source Code (repository root)

```text
src/rag_confluence/
├── domain/                  # Núcleo puro — SEM import de infraestrutura
│   ├── models.py            # Chunk, Principal, Page, EffectiveAcl, QueryResult...
│   ├── adf/                 # ADF → Markdown (walker próprio, macros, tabelas, código)
│   ├── chunking/            # Chunking hierárquico por heading + breadcrumb
│   ├── acl/                 # ACL efetiva (própria→herança→espaço); interseção de principals
│   ├── retrieval/           # Fusão RRF (BM25 + denso); política de over-fetch/retry
│   └── prompt/              # Montagem de prompt e formatação de fontes
├── ports/                   # Interfaces (Protocols) — driven + driving
│   ├── content_source.py    # ContentSourcePort
│   ├── acl_source.py        # AclSourcePort
│   ├── directory_source.py  # DirectorySourcePort
│   ├── access_verifier.py   # AccessVerifierPort
│   ├── vector_store.py      # VectorStorePort (pré-filtro de principals)
│   ├── lexical_store.py     # LexicalStorePort
│   ├── metadata_store.py    # MetadataStorePort
│   ├── lock.py              # LockPort
│   ├── embedding.py         # EmbeddingPort
│   ├── reranker.py          # RerankerPort
│   ├── generator.py         # GeneratorPort
│   └── identity.py          # IdentityPort
├── adapters/
│   ├── confluence/          # ContentSource, AclSource, Directory, AccessVerifier(CQL)
│   ├── vector_store/        # chroma.py  (+ pgvector.py em produção)
│   ├── lexical_store/       # sqlite_fts5.py (+ postgres_fts.py)
│   ├── metadata_store/      # sqlite.py (+ postgres.py)
│   ├── lock/                # file_lock.py (+ pg_advisory.py)
│   ├── embedding/           # vertex.py / configurável
│   ├── reranker/            # bge_local.py
│   ├── generator/           # vertex.py / configurável
│   ├── identity/            # bff.py
│   └── access_verifier/     # noop.py (Fase A) + confluence_cql.py (Fase B)
├── app/
│   ├── services/            # SyncService, QueryService (casos de uso / driving ports)
│   ├── http/                # Routers FastAPI (query, sync, health)
│   ├── cli/                 # Comandos Typer (sync, query, reconcile, eval)
│   ├── composition.py       # Injeção de dependência; log do adaptador ativo na init
│   └── config.py            # Settings (allowlist, fase de ACL, escolha de adaptadores)
└── main.py                  # ASGI entrypoint

tests/
├── unit/                    # Núcleo de domínio, sem infraestrutura
├── conformance/             # Suíte de conformidade parametrizada por adaptador
├── integration/             # Fluxos com adaptadores reais (SQLite/Chroma)
├── adversarial/             # Vazamento de ACL (principal parcial, restrição alterada)
└── contract/                # Schemathesis sobre contracts/openapi.yaml

evaluation/
├── golden_set/              # Perguntas reais + fonte esperada
├── metrics.py               # Config das métricas DeepEval
└── run_eval.py              # `python evaluation/run_eval.py` → relatório
```

**Structure Decision**: Projeto backend único em `src/rag_confluence/` com organização hexagonal
estrita. A fronteira `domain/` ↔ `adapters/` é a fronteira de segurança e de portabilidade
(Princípios II e a substituibilidade de FR-027/028). A regra de lint de import proíbe qualquer
dependência de infraestrutura dentro de `domain/` e `ports/`. `evaluation/` segue a convenção da
skill de avaliação de agentes do banco (execução por script, não pytest).

## Complexity Tracking

*Sem violações de constituição. Seção não aplicável.*
