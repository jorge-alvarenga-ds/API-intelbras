# Feature Specification: RAG sobre Confluence Cloud com ACL por usuário

**Feature Branch**: `001-confluence-rag-acl`

**Created**: 2026-08-11

**Status**: Draft

**Input**: PRD "RAG sobre Confluence Cloud com ACL por usuário" (v0.1, autor: Jorge) — API de RAG sobre a documentação interna do banco no Confluence Cloud, com enforcement de controle de acesso (ACL) por usuário.

## Clarifications

### Session 2026-08-11

- Q: Na Fase B, quando a verificação final de acesso não consegue confirmar a permissão no
  Confluence (timeout/indisponibilidade), o que fazer com o resultado? → A: Fail-closed — tratar o
  item não confirmado como não autorizado e removê-lo do contexto; se todos caírem, responder "não
  encontrei".
- Q: Como o acesso à API de sincronização/operação (POST /sync, cancel, etc.) deve ser restrito? →
  A: Papel de operador dedicado, autenticado, separado do acesso de consulta.
- Q: A API de consulta v1 deve ser sem estado ou conversacional? → A: Stateless / single-turn — cada
  consulta é independente, sem histórico de conversa no v1.

## User Scenarios & Testing *(mandatory)*

As histórias abaixo estão priorizadas por criticidade para a missão. Dado o contexto bancário
regulado, a não exposição de conteúdo restrito (US2) é tão inegociável quanto o valor central de
Q&A (US1) — ambas são P1. A ingestão (US3) é o habilitador operacional; a governança e auditoria
(US4) sustentam a operação de longo prazo.

### User Story 1 - Perguntar e receber resposta fundamentada e citada (Priority: P1)

Um colaborador faz uma pergunta em linguagem natural sobre processos, padrões e documentação
interna e recebe uma resposta fundamentada exclusivamente no conteúdo indexado do Confluence, com
link para a(s) página(s) de origem. Quando não há base documental suficiente, o sistema responde
explicitamente que não encontrou, em vez de inventar.

**Why this priority**: É o valor central para o usuário final — elimina a necessidade de saber de
antemão em qual espaço e com qual termo exato a informação foi documentada. Sem isso, não há
produto.

**Independent Test**: Com um índice populado sobre espaços da allowlist, submeter perguntas do
golden set e verificar que as respostas são fundamentadas, citam a página correta e que perguntas
sem base documental retornam "não encontrei".

**Acceptance Scenarios**:

1. **Given** uma pergunta cuja resposta está documentada em um espaço indexado, **When** o
   colaborador consulta, **Then** o sistema retorna uma resposta fundamentada no conteúdo e cita a
   página de origem com link.
2. **Given** uma pergunta sem base documental no corpus indexado, **When** o colaborador consulta,
   **Then** o sistema responde explicitamente "não encontrei" e não fabrica conteúdo.
3. **Given** uma resposta gerada, **When** o colaborador a recebe, **Then** cada afirmação
   relevante é rastreável a pelo menos uma fonte citada.

---

### User Story 2 - Nenhum conteúdo não autorizado é exposto (ACL faseado) (Priority: P1)

Um colaborador nunca recebe — nem por resposta, nem por título, nem por snippet ou citação —
conteúdo ao qual não teria acesso no próprio Confluence. O enforcement é faseado: na Fase A a
fronteira de segurança é o escopo (somente espaços sem restrição são indexados); na Fase B a
fronteira passa a ser a verificação final dos resultados contra o Confluence com a credencial do
próprio usuário.

**Why this priority**: Um índice vetorial é uma cópia desnormalizada do conteúdo sem as proteções
da origem. Sem enforcement de ACL, o sistema vira canal de vazamento de informação restrita —
inaceitável e achado de auditoria em ambiente bancário regulado. É o gate mais importante do
documento.

**Independent Test (Fase A)**: Auditar que todo espaço indexado é comprovadamente sem restrição de
página e visível a todos os participantes do piloto; verificar que a etapa de verificação final
está presente no fluxo (mesmo neutralizada) e que o pré-filtro por principals exclui chunks cujos
principals não intersectam os do usuário.

**Independent Test (Fase B)**: Teste adversarial — um usuário sem acesso a uma página restrita
pergunta sobre seu conteúdo e o sistema não revela sua existência.

**Acceptance Scenarios**:

1. **Given** um chunk cujos principals permitidos não intersectam os principals do usuário, **When**
   o usuário consulta, **Then** o pré-filtro exclui o chunk antes da ordenação (nunca depois).
2. **Given** (Fase B) que a restrição de uma página mudou no Confluence após o último sync, **When**
   o usuário consulta, **Then** a verificação final remove o chunk do contexto usando a credencial
   do próprio usuário.
3. **Given** que todos os resultados foram removidos pelo filtro ou pela verificação final, **When**
   a resposta é montada, **Then** o sistema responde "não encontrei", sem revelar que havia
   conteúdo restrito.
4. **Given** um grupo que foi renomeado no diretório, **When** o usuário consulta, **Then** a
   correspondência de acesso continua correta porque os principals são armazenados como
   identificador imutável de grupo, não como nome.

---

### User Story 3 - Sincronizar o conteúdo do Confluence de forma resiliente (Priority: P2)

Um operador de plataforma dispara e acompanha a sincronização do conteúdo via API, sem precisar de
acesso ao cluster. Uma sincronização interrompida retoma de onde parou, e múltiplas réplicas do
serviço não duplicam o trabalho de ingestão.

**Why this priority**: Habilita e mantém o índice atualizado. É pré-requisito operacional para US1 e
US2 e precisa ser resiliente para não desperdiçar horas de trabalho a cada deploy nem sobrecarregar
o Confluence.

**Independent Test**: Disparar um sync via API, interrompê-lo no meio, dispará-lo novamente e
verificar que retoma do último checkpoint sem reprocessar páginas concluídas; iniciar dois syncs
concorrentes e verificar que apenas um executa.

**Acceptance Scenarios**:

1. **Given** um job de sincronização em andamento, **When** o operador consulta o status, **Then**
   recebe progresso (processadas/total) e erros, lido do estado durável e correto a partir de
   qualquer réplica.
2. **Given** um job interrompido no meio, **When** um novo job é disparado, **Then** ele retoma do
   último checkpoint sem reprocessar páginas já concluídas.
3. **Given** um job já ativo, **When** uma segunda réplica tenta iniciar o mesmo job, **Then** a
   exclusão mútua impede a execução concorrente.
4. **Given** uma página excluída ou despublicada no Confluence, **When** a reconciliação executa,
   **Then** o conteúdo correspondente é removido do índice.

---

### User Story 4 - Governança de allowlist e auditabilidade (Priority: P3)

Um dono de espaço decide explicitamente se seu espaço entra no índice, e a Segurança da Informação
dispõe de evidência auditável de quais conteúdos foram recuperados e servidos a cada usuário.

**Why this priority**: Sustenta a operação de longo prazo e a resposta a auditoria. Sem curadoria e
dono nomeado por espaço, a base apodrece; sem trilha de auditoria, não há como comprovar o
enforcement à auditoria.

**Independent Test**: Adicionar/remover um espaço da allowlist versionada e verificar que a
ingestão respeita a mudança; inspecionar o log estruturado de uma consulta e confirmar que registra
identidade do usuário, page_ids recuperados e page_ids servidos com um identificador de rastreio.

**Acceptance Scenarios**:

1. **Given** um espaço fora da allowlist, **When** a ingestão executa, **Then** o espaço não é
   indexado, mesmo que a conta de serviço tenha acesso a ele.
2. **Given** uma consulta atendida, **When** a Segurança inspeciona os logs, **Then** encontra
   registro estruturado com identidade do usuário, page_ids recuperados, page_ids efetivamente
   servidos e um identificador de rastreio (trace_id).

---

### Edge Cases

- **Restrição alterada sem mudança de conteúdo**: mudar a restrição de uma página no Confluence não
  altera seu `lastModified`; o delta sync jamais a reprocessa. Somado ao lag do sync de grupos, isso
  cria uma janela de inconsistência indeterminada — coberta apenas pela verificação final (Fase B).
- **Top-K colapsado após o filtro de ACL**: quando o pré-filtro elimina a maioria dos candidatos, o
  sistema faz over-fetch antes de reordenar e amplia K sob demanda para não devolver resposta vazia
  indevidamente.
- **Cache de resposta entre usuários**: respostas em cache precisam considerar os principals do
  usuário na chave; caso contrário, o cache vira vazamento.
- **Grupo aninhado**: a resolução de grupos do usuário expande grupos aninhados recursivamente antes
  do achatamento.
- **Página trivial**: páginas com pouquíssimo conteúdo útil (~< 200 caracteres) são descartadas na
  ingestão.
- **Rate limit da origem**: o crawl trata respostas de limite de taxa com espera indicada e recuo
  exponencial, sem abortar o job.
- **Encerramento durante ingestão**: um sinal de término encerra de forma cooperativa — conclui a
  página atual, persiste o progresso e sai.
- **Identidade sem mapeamento**: um usuário cujo identificador de SSO não mapeia para uma conta
  válida do Confluence não pode receber conteúdo (comportamento relevante sobretudo na Fase B).
- **Origem indisponível na verificação (Fase B)**: se a verificação final não consegue confirmar a
  permissão de um page_id (timeout/indisponibilidade do Confluence), o item é tratado como não
  autorizado (fail-closed) e removido do contexto; se todos os resultados caem, a resposta é "não
  encontrei", sem revelar que havia conteúdo.

## Requirements *(mandatory)*

### Functional Requirements

#### Consulta e geração

- **FR-001**: O sistema MUST aceitar perguntas em linguagem natural e retornar uma resposta
  fundamentada exclusivamente no conteúdo recuperado do Confluence, acompanhada das fontes (título e
  link da página) usadas.
- **FR-002**: Quando o contexto recuperado for insuficiente, o sistema MUST responder
  explicitamente que não encontrou a informação e MUST NOT fabricar conteúdo.
- **FR-003**: O sistema MUST combinar busca lexical e semântica sobre o corpus indexado e
  reordenar os candidatos por relevância antes de montar a resposta.
- **FR-004**: O sistema MUST fazer over-fetch de candidatos antes da reordenação e ampliar o número
  de candidatos quando o filtro de acesso reduzir demais o conjunto, evitando resposta vazia
  indevida.
- **FR-005**: O sistema MUST expor a consulta como serviço com contrato estável e documentado,
  aceitando a identidade do usuário solicitante e retornando resposta, fontes e um identificador de
  rastreio. A consulta MUST ser sem estado (single-turn): cada requisição é independente e o sistema
  MUST NOT manter histórico de conversa entre requisições no v1.

#### Enforcement de acesso (ACL)

- **FR-006**: O sistema MUST filtrar os resultados pelos principals do usuário solicitante **antes**
  da ordenação (pré-filtro no armazenamento de busca), nunca como pós-filtro. Todo chunk cujos
  principals permitidos não intersectam os principals do usuário MUST ser excluído.
- **FR-007**: O sistema MUST manter no fluxo de consulta uma etapa de verificação final de acesso
  dos page_ids a serem citados. Na Fase A essa etapa é neutralizada por adaptador (aprova tudo) e
  permanece no código; na Fase B ela MUST verificar os page_ids contra o Confluence usando a
  credencial do próprio usuário solicitante. A verificação MUST ser fail-closed: quando não for
  possível confirmar a permissão de um page_id (timeout ou indisponibilidade da origem), o item MUST
  ser tratado como não autorizado e removido do contexto; se todos os resultados forem removidos, a
  resposta MUST ser "não encontrei".
- **FR-008**: Na Fase A, o sistema MUST indexar **apenas** espaços comprovadamente sem restrição de
  página ou de espaço, visíveis a todos os participantes do piloto — o escopo é o controle
  compensatório na ausência de verificação em runtime.
- **FR-009**: A Fase B (verificação final com credencial do usuário) MUST ser pré-requisito para
  indexar o primeiro espaço com qualquer restrição. Não há caminho intermediário.
- **FR-010**: O sistema MUST NOT revelar a existência de conteúdo não autorizado — nenhum título,
  snippet ou citação de página não autorizada pode aparecer na resposta. Quando todos os resultados
  forem removidos pela verificação, a resposta MUST ser "não encontrei".
- **FR-011**: A credencial da conta de serviço MUST NOT ser usada na verificação final, e a
  credencial/token do usuário MUST NOT ser usada na ingestão.
- **FR-012**: O sistema MUST armazenar principals como identificador imutável de grupo (group ID),
  nunca como nome de grupo.
- **FR-013**: O sistema MUST resolver os principals do usuário (grupos + identidade) a partir de uma
  cópia local sincronizada, sem chamadas ao diretório de origem no caminho crítico da consulta, e a
  chave do cache de resposta MUST incluir os principals do usuário.

#### Ingestão e sincronização

- **FR-014**: O sistema MUST indexar somente os espaços presentes em uma allowlist versionada
  (configuração, não hardcoded); espaços fora da allowlist MUST NOT ser indexados mesmo que a conta
  de serviço tenha acesso a eles.
- **FR-015**: A sincronização MUST ser incremental (processar o que mudou desde o último
  checkpoint) e MUST ser resumível — um job interrompido retoma do último checkpoint sem
  reprocessar páginas concluídas.
- **FR-016**: O sistema MUST garantir exclusão mútua entre réplicas de modo que apenas um job de
  sincronização do mesmo escopo execute por vez.
- **FR-017**: O encerramento do processo durante a ingestão MUST ser cooperativo: concluir a página
  atual, persistir o progresso e sair.
- **FR-018**: O sistema MUST tratar limites de taxa da origem com espera indicada e recuo
  exponencial, sem abortar o job.
- **FR-019**: A sincronização MUST ser assíncrona: iniciar retorna imediatamente com um
  identificador de job; o progresso (processadas/total, erros, job ativo) MUST ser consultável e
  correto a partir de qualquer réplica, sem manter conexão HTTP aberta durante o processamento; um
  job MUST poder ser cancelado cooperativamente.
- **FR-019a**: Os endpoints de sincronização/operação (iniciar, cancelar, consultar job) MUST ser
  restritos a identidades com papel de operador dedicado, autenticadas e separadas do acesso de
  consulta do usuário final. Um consumidor de consulta MUST NOT conseguir disparar ou cancelar
  sincronizações.
- **FR-020**: O upsert de conteúdo MUST ser idempotente por página, e o sistema MUST reconciliar
  exclusões periodicamente, removendo do índice conteúdo excluído ou despublicado na origem.
- **FR-021**: O sistema MUST resolver, na ingestão, a ACL efetiva de cada página (restrição própria
  → herança → permissão de espaço) e materializá-la como os principals permitidos do conteúdo.

#### Fidelidade de conteúdo

- **FR-022**: A conversão do conteúdo da origem para texto MUST preservar tabelas com cabeçalho
  (nunca como texto corrido), MUST NOT cortar blocos de código no meio de um chunk, e MUST tratar
  macros conhecidas de forma explícita, sem vazar sua representação interna para o texto.
- **FR-023**: O sistema MUST descartar páginas com conteúdo útil trivial (~< 200 caracteres) e MUST
  prefixar cada chunk com seu breadcrumb (caminho de ancestrais) e caminho de headings.

#### Observabilidade, auditoria e segurança operacional

- **FR-024**: O sistema MUST registrar, para cada consulta, log estruturado com identidade do
  usuário, page_ids recuperados, page_ids aprovados na verificação final e um identificador de
  rastreio; e, para cada página na ingestão, versão e resultado.
- **FR-025**: O índice MUST estar criptografado em repouso com chave gerenciada pela organização,
  sem exposição pública (acesso apenas por rede interna), com credenciais fora do código e política
  de rotação definida, e com trilha de acesso ao índice separada da trilha de consulta.
- **FR-026**: A retenção de logs MUST estar alinhada à política de retenção e classificação de dados
  da organização.

#### Substituibilidade e conformidade

- **FR-027**: As integrações de armazenamento e origem MUST ser substituíveis por trás de
  interfaces estáveis, sem que a troca exija mudança no núcleo de domínio nem reabra a discussão de
  segurança; a escolha do adaptador MUST ser configuração, não código.
- **FR-028**: MUST existir uma suíte de conformidade de adaptador, executada contra qualquer
  implementação de armazenamento de busca, cobrindo obrigatoriamente: pré-filtro de principals,
  ausência de vazamento com principal parcialmente coincidente, remoção por página e comportamento
  com lista vazia de principals. Um adaptador só MUST ser considerado apto para produção após passar
  a suíte completa.
- **FR-029**: A composição do sistema MUST registrar, na inicialização, qual adaptador de
  verificação de acesso está ativo (ex.: neutralizado na Fase A vs. real na Fase B).

### Key Entities *(include if feature involves data)*

- **Chunk indexado**: unidade recuperável de conteúdo. Atributos: identificador da página
  (`page_id`), índice do chunk, chave do espaço, principals permitidos (lista de group IDs +
  `public`), breadcrumb, caminho de headings, URL da origem, versão da página.
- **Principal**: sujeito de autorização — identificador imutável de grupo, identidade do usuário
  (`accountId`) ou `public`.
- **Espaço**: unidade de origem no Confluence com um dono nomeado, um estado de inclusão na
  allowlist e um estado de restrição (com/sem restrição de página ou de espaço).
- **Job de sincronização**: identificador, status, contadores (processadas/total), checkpoint,
  lista de erros, estado de cancelamento.
- **Mapa de grupos do usuário**: correspondência local `accountId → [group IDs]`, resultado do sync
  de grupos com expansão recursiva.
- **Resposta de consulta**: resposta gerada, lista de fontes (páginas aprovadas), identificador de
  rastreio.
- **Golden set**: conjunto curado de perguntas reais com fonte esperada, usado para avaliação de
  qualidade de recuperação e geração.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: Zero vazamentos de ACL. Fase A: auditoria comprova que nenhum espaço indexado possui
  restrição. Fase B: teste adversarial com usuário sem acesso não revela nenhum conteúdo restrito.
- **SC-002**: ≥ 80% das respostas do golden set citam a página de origem correta.
- **SC-003**: Precisão de recuperação NDCG@5 ≥ 0,75 no golden set (~50 perguntas reais).
- **SC-004**: Tempo médio até uma resposta útil < 30 segundos (vs. minutos de navegação manual).
- **SC-005**: Latência ponta a ponta no percentil 95 < 3 segundos.
- **SC-006**: Taxa de "não encontrei" indevido < 10% no golden set.
- **SC-007**: Lag de conteúdo ≤ 1 hora; lag de permissão efetiva zero na Fase B (verificação em
  runtime).
- **SC-008**: Duração do sync incremental < 15 minutos.
- **SC-009**: Falha de parsing de conteúdo < 2% das páginas.
- **SC-010**: Satisfação do usuário (👍 / total) ≥ 70% após estabilização.
- **SC-011**: Pelo menos 2 agentes/consumidores distintos usando a API em até 6 meses.

## Assumptions

- **Escopo v1**: entrega uma API (sem interface de usuário própria), somente leitura, fonte única
  (Confluence Cloud), corpus majoritariamente pt-BR, consulta sem estado (single-turn). Multi-fonte,
  escrita no Confluence, indexação de todos os espaços, normalização multilíngue e contexto
  conversacional (multi-turn) estão fora de escopo.
- **Faseamento do enforcement**: o produto avança em Fase A (sem token do usuário, segurança por
  escopo de indexação) antes da Fase B (verificação final com token do usuário). Nenhum espaço com
  restrição é indexado antes da Fase B concluída e aprovada por teste adversarial.
- **Anexos e comentários**: assumidos fora do escopo v1 (candidatos a P1 posterior); se incluídos,
  herdam a ACL da página.
- **Padrões operacionais**: tratamento de erros com mensagens claras e fallback; retenção conforme
  política interna do banco; autenticação do usuário via SSO corporativo já existente.

## Dependencies

Estas são dependências externas documentadas no PRD (Open Questions). Não bloqueiam a redação da
spec, mas condicionam a entrega das fases:

- **Fase A**: (Q3) provisionamento da conta de serviço com leitura apenas nos espaços da allowlist,
  sem admin global; (Q9) confirmação de quais espaços são comprovadamente sem restrição de página e
  visíveis a todos os participantes do piloto; (Q4) definição de retenção e classificação do índice
  vetorial.
- **Fase B**: (Q1) mapeamento confiável entre a identidade do SSO corporativo e o `accountId` do
  Confluence; (Q2) aprovação do fluxo OAuth 3LO do usuário contra o Confluence — sem ele não há
  verificação final e a Fase B não existe. Estas dependências são de terceiros (IAM, Segurança,
  Atlassian admin) e devem ser abertas em paralelo à Fase A.
- **Não bloqueantes**: (Q5) allowlist v1 e donos nomeados; (Q6) rerank self-hosted vs. gerenciado;
  (Q7) LLM de geração e região; (Q8) inclusão de anexos no escopo.
