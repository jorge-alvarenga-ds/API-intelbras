# Quickstart — Validação end-to-end: Confluence RAG API

Guia para provar que a feature funciona. Referencia [contracts/openapi.yaml](contracts/openapi.yaml),
[contracts/ports.md](contracts/ports.md) e [data-model.md](data-model.md) em vez de duplicar
detalhes. Não contém implementação — os passos de código pertencem a `tasks.md`.

## Pré-requisitos

- Python 3.11+ e o ambiente do projeto instalado (`src/rag_confluence/`).
- **Fase A** (piloto): conta de serviço com leitura **apenas** nos espaços da allowlist (Q3), e
  lista confirmada de espaços **sem restrição** de página (Q9).
- Configuração (`app/config.py` / variáveis de ambiente):
  - `ACL_PHASE=A` (usa `NoOpAccessVerifier`) — Fase B exige OAuth 3LO aprovado (Q2) e mapa SSO↔accountId (Q1).
  - Adaptadores v1: `VECTOR_STORE=chroma`, `LEXICAL_STORE=sqlite_fts5`, `METADATA_STORE=sqlite`, `LOCK=file`.
  - `EMBEDDING_PROVIDER` e `GENERATOR_PROVIDER` (default Vertex/Gemini); `RERANKER=bge-reranker-v2-m3`.
  - `ALLOWLIST=ARQ,ENG` (exemplo — allowlist versionada, não hardcoded).
  - Segredos (token da conta de serviço, credenciais do provedor) via cofre, fora do código.

## Cenário 1 — Ingestão da allowlist (US3)

```bash
# via CLI operacional
python -m rag_confluence.cli sync --mode full
# ou via API (papel de operador):
# curl -X POST https://rag-confluence.internal/v1/sync -H "Authorization: Bearer $OPERATOR_TOKEN"
```

**Esperado**:
- Retorna um `job_id` imediatamente (202); a API **não** fica com conexão aberta durante o processamento.
- `GET /sync/{job_id}` mostra `processed`/`total` crescendo, lido do estado durável.
- Ao final: chunks indexados com `allowed_principals` materializado (para espaços irrestritos, contém `public`).
- Páginas com < ~200 chars úteis aparecem como `skipped`; falha de parsing < 2%.

**Validação de retomada**: interrompa o processo no meio (SIGTERM) e redispare — o novo job retoma do
`checkpoint` sem reprocessar páginas com mesma `version`/`content_hash`.

**Validação de exclusão mútua**: dispare dois `sync` concorrentes — o segundo recebe `409` (lock por escopo).

## Cenário 2 — Consulta fundamentada e citada (US1)

```bash
curl -X POST https://rag-confluence.internal/v1/query \
  -H "Authorization: Bearer $USER_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"question": "Como configuramos refresh token no OAuth interno?"}'
```

**Esperado** (schema `QueryResponse`):
- `answer` fundamentada apenas no conteúdo recuperado; `sources[]` com título + link da(s) página(s).
- Pergunta sem base documental ⇒ `found=false`, `answer` = "não encontrei", `sources=[]`.
- `trace_id` presente e correlacionável com o `AuditRecord` no log estruturado.
- Latência p95 < 3 s.

## Cenário 3 — Enforcement de ACL (US2)

### Fase A (segurança por escopo)
- **Auditoria**: confirmar que todo espaço da allowlist é irrestrito (Q9) — nenhum espaço com
  restrição de página/espaço indexado.
- **Pré-filtro**: `GET /health` mostra `acl_phase=A` e `verifier_adapter=NoOpAccessVerifier` (logado
  também na inicialização). Um chunk cujos `allowed_principals` não intersectam os principals do
  usuário é excluído **antes** do ranking.

### Fase B (teste adversarial — pré-requisito p/ qualquer espaço restrito)
- Usuário **sem** acesso a uma página restrita pergunta sobre seu conteúdo ⇒ resposta não revela
  título, snippet nem citação; se todos os resultados caem, `answer`="não encontrei".
- **Restrição alterada pós-sync**: mude a restrição de uma página no Confluence (sem editar o corpo)
  ⇒ a verificação final remove o chunk (o delta sync não a reprocessaria).
- **Fail-closed**: simule indisponibilidade do verificador ⇒ page_ids não confirmados são tratados
  como não autorizados; consulta nunca vaza (pode retornar `503` se nada seguro puder ser servido).

## Cenário 4 — Suíte de conformidade de adaptador (gate de produção)

```bash
pytest tests/conformance -q          # roda contra chroma + sqlite_fts5 (e pgvector/postgres em prod)
```
**Esperado**: todos os casos C1–C8 de [contracts/ports.md](contracts/ports.md) passam. **C2**
(vazamento com principal parcial) e **C4** (lista vazia ⇒ vazio) são os casos negativos de ACL — se
falharem, o adaptador é reprovado para produção independentemente da qualidade de recuperação.

## Cenário 5 — Gate de avaliação de qualidade (DeepEval)

```bash
python evaluation/run_eval.py       # NÃO é pytest; juiz Gemini sobre o golden set
```
**Esperado**: NDCG@5 ≥ 0,75 (`ContextualPrecisionMetric`), faithfulness/relevância acima do limiar,
taxa de "não encontrei" indevido < 10%. Relatório HTML gerado. Nenhuma alteração de
prompt/chunking/recuperação/embedding/modelo vai a produção sem passar este gate.

## Gates de release (da spec)

- ❌ **Nenhum** espaço com restrição indexado antes da Fase B concluída + teste adversarial limpo.
- ❌ Sem exposição a usuário final na Fase A sem confirmação documentada (Q9).
- ❌ Reconciliação de exclusões implementada antes do rollout amplo.
