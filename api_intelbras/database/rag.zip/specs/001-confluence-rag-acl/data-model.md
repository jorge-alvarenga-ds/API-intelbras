# Phase 1 — Data Model: RAG sobre Confluence Cloud com ACL por usuário

Modelo de domínio (entidades puras, sem infraestrutura) e as tabelas/coleções que os adaptadores
materializam. Tipos são conceituais; a implementação usa dataclasses/Pydantic no núcleo e schemas
nos adaptadores.

## Convenções

- `page_id`, `space_key`, `accountId`, `group_id` são strings opacas do Confluence.
- **Principal** é sempre serializado como string com prefixo: `group:{group_id}`, `user:{accountId}`
  ou `public`. Nunca nome de grupo.
- Todo timestamp em UTC ISO-8601.

---

## Entidades de domínio

### Principal

Sujeito de autorização.

| Campo | Tipo | Regras |
|---|---|---|
| `kind` | enum {`group`, `user`, `public`} | obrigatório |
| `id` | string | group ID (imutável) ou accountId; ausente para `public` |

- Serialização canônica: `group:5f2a...`, `user:abc123`, `public`.
- **Invariante**: `group` sempre por ID, nunca por nome (R5). Renomear grupo não altera o principal.

### EffectiveAcl

ACL resultante da resolução própria → herança → espaço, calculada no núcleo na ingestão.

| Campo | Tipo | Regras |
|---|---|---|
| `allowed_principals` | set<Principal> | resultado da resolução; `public` presente ⇔ sem restrição efetiva |
| `is_restricted` | bool | derivado: `public ∉ allowed_principals` |
| `source` | enum {`page`, `inherited`, `space`} | de onde veio a restrição efetiva (auditoria) |

- **Regra de resolução**: restrição própria da página vence; na ausência, herda do ancestral mais
  próximo com restrição; na ausência, aplica a permissão do espaço.
- **Gate de fase**: se `is_restricted` para qualquer página de um espaço, esse espaço só pode ser
  indexado na **Fase B** (FR-008/009).

### Page

Página do Confluence conforme ingerida.

| Campo | Tipo | Regras |
|---|---|---|
| `page_id` | string | PK natural |
| `space_key` | string | pertence a espaço da allowlist |
| `title` | string | |
| `version` | int | versão do Confluence; usado no upsert idempotente |
| `url` | string | link canônico da página |
| `ancestors` | list<{id,title}> | cadeia para breadcrumb |
| `body_adf` | json | corpo em ADF (transiente; não persistido após conversão) |
| `effective_acl` | EffectiveAcl | resolvido na ingestão |
| `last_modified` | datetime | do Confluence; base do delta sync (CQL) |
| `content_hash` | string | hash do Markdown normalizado; evita re-embedding sem mudança real |

- **Transições de estado**: `discovered → fetched → parsed → chunked → embedded → indexed`; ou
  `skipped` (conteúdo < ~200 chars úteis, FR-023) ou `failed` (parsing). `deleted_at_source →
  removed` via reconciliação (FR-020).

### Chunk

Unidade recuperável indexada. É a entidade servida pela busca.

| Campo | Tipo | Regras |
|---|---|---|
| `chunk_id` | string | `{page_id}:{chunk_index}` |
| `page_id` | string | FK → Page |
| `chunk_index` | int | ordem estável dentro da página |
| `space_key` | string | |
| `text` | string | Markdown do chunk, **prefixado** com breadcrumb + heading path (FR-023) |
| `allowed_principals` | list<string> | materializado de `EffectiveAcl` (group IDs + `public`) |
| `breadcrumb` | string | ex.: `Arquitetura > Padrões > RAG` |
| `heading_path` | string | ex.: `OAuth 2.0 > Refresh token` |
| `url` | string | link da página de origem |
| `version` | int | versão da página no momento da indexação |
| `embedding` | vector | denso; gerado com `task_type=RETRIEVAL_DOCUMENT` |

- **Invariantes**: blocos de código nunca cortados no meio de um chunk; tabelas preservadas com
  cabeçalho (FR-022). Todos os chunks de uma página compartilham `allowed_principals`.
- **Filtro de recuperação**: um chunk é candidato ⇔ `allowed_principals ∩ principals(usuário) ≠ ∅`.

### UserGroupMap

Cache local do sync de grupos (consulta invertida, R5).

| Campo | Tipo | Regras |
|---|---|---|
| `account_id` | string | PK |
| `group_ids` | list<string> | grupos após expansão recursiva de aninhados + achatamento |
| `synced_at` | datetime | frescor do cache de grupos |

- Runtime: `principals(usuário) = {public} ∪ {user:account_id} ∪ {group:g | g ∈ group_ids}`.

### SyncJob

Estado durável de uma sincronização (o banco é a fila, R3).

| Campo | Tipo | Regras |
|---|---|---|
| `job_id` | string | PK |
| `status` | enum {`queued`,`running`,`cancelling`,`completed`,`failed`,`cancelled`} | |
| `scope` | list<space_key> | subconjunto da allowlist |
| `total` | int | páginas a processar |
| `processed` | int | páginas concluídas (base do progresso) |
| `errors` | list<{page_id,message}> | falhas por página |
| `checkpoint` | json | cursor de retomada (ex.: último `lastModified`/cursor CQL) |
| `cancel_requested` | bool | flag cooperativa |
| `started_at` / `updated_at` | datetime | |

- **Transições**: `queued → running → (completed | failed | cancelled)`; `running → cancelling →
  cancelled`. Retomada: novo job lê `checkpoint` e pula páginas com `version`/`content_hash` iguais.
- **Concorrência**: `LockPort` garante um job `running` por `scope` (réplica única no v1).

### QueryResult (saída, não persistida além do log/cache)

| Campo | Tipo | Regras |
|---|---|---|
| `answer` | string | fundamentada nos chunks sobreviventes; ou "não encontrei" |
| `sources` | list<{page_id,title,url}> | **apenas** páginas aprovadas na verificação final (FR-005/010) |
| `trace_id` | string | correlaciona com o log de auditoria |

### AuditRecord (log estruturado, FR-024)

| Campo | Tipo |
|---|---|
| `trace_id` | string |
| `account_id` | string |
| `retrieved_page_ids` | list<string> |
| `approved_page_ids` | list<string> |
| `phase` | enum {`A`,`B`} |
| `verifier_adapter` | string (ex.: `NoOpAccessVerifier`, `ConfluenceCqlVerifier`) |
| `timestamp` | datetime |

### GoldenItem (avaliação, R10)

| Campo | Tipo |
|---|---|
| `question` | string |
| `expected_source_page_ids` | list<string> |
| `notes` | string (opcional) |

---

## Relacionamentos

```text
Space (allowlist) 1───* Page 1───* Chunk
Page 1───1 EffectiveAcl ───* Principal
Chunk *───* Principal            (via allowed_principals materializado)
UserGroupMap (accountId) ───* Principal(group)   → usado no pré-filtro
SyncJob *───* Page               (escopo processado)
QueryResult 1───* Source(Page)   → AuditRecord (via trace_id)
```

## Materialização por adaptador (v1)

| Entidade | Store v1 | Chave/índice | Produção |
|---|---|---|---|
| Chunk (texto + metadados + `acl:{gid}` booleano) | Chroma | filtro `$or` sobre `acl:{gid}` | pgvector + GIN em `allowed_principals` |
| Chunk (BM25) | SQLite FTS5 | FTS sobre `text`, filtro por principals | Postgres FTS |
| Page / SyncJob / checkpoint / UserGroupMap | SQLite | PK `page_id` / `job_id` / `account_id` | Postgres |
| Lock de ingestão | file/process lock | por `scope` | advisory lock do Postgres |

> **Ponto onde a abstração vaza (R1)**: `allowed_principals` é lista; Chroma só filtra escalar. O
> adaptador Chroma materializa cada principal como `acl:{group_id}: true` e monta `$or`. A suíte de
> conformidade (contracts/ports.md) valida que o pré-filtro não vaza com principal parcialmente
> coincidente.
