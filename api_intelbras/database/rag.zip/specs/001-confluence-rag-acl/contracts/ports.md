# Contratos das Portas (Hexagonal) + Suíte de Conformidade

Contratos internos que o núcleo depende. A escolha de adaptador é **configuração, não código**
(FR-027). Nenhum módulo de `domain/`/`ports/` importa biblioteca de infraestrutura (regra de lint em
CI). Assinaturas em pseudo-Python (Protocol); tipos referem-se a [data-model.md](../data-model.md).

## Portas de saída (driven)

### ContentSourcePort
```python
async def list_pages(space_key: str, since: datetime | None, cursor: str | None) -> PageListPage
async def get_page(page_id: str) -> Page              # body ADF + ancestrais + versão
```
- Delta sync por CQL `lastModified >= checkpoint` (com margem). Paginação por cursor.

### AclSourcePort
```python
async def get_page_restrictions(page_id: str) -> Restrictions
async def get_space_permissions(space_key: str) -> SpacePermissions
```
- **Nota v1 vs v2**: restrições vivem na API **v1** do Confluence. Comentar explicitamente no código.

### DirectorySourcePort
```python
async def list_groups() -> list[Group]
async def list_group_members(group_id: str) -> list[AccountId]   # expande aninhados recursivamente
```
- Consulta invertida (grupo → membros); evita `memberof` em runtime (403 não-admin).

### AccessVerifierPort  ⟵ fronteira de segurança da Fase B
```python
async def verify(account_id: str, page_ids: list[str]) -> set[str]   # retorna os page_ids AUTORIZADOS
```
- **NoOpAccessVerifier** (Fase A): retorna todos os `page_ids` (aprova tudo).
- **ConfluenceCqlVerifier** (Fase B): CQL `id in (...)` com o **token do usuário**.
- **Fail-closed**: em timeout/erro/indisponibilidade, um page_id não confirmado **não** entra no
  conjunto autorizado. Nunca lança "aprovar por falha".
- **Invariante de credencial**: usa o token do usuário; **nunca** a conta de serviço.

### VectorStorePort  ⟵ ponto onde a abstração vaza (pré-filtro de ACL)
```python
def upsert(chunks: list[Chunk]) -> None                 # idempotente por page_id
def delete_by_page(page_id: str) -> None
def search_dense(query_vec: Vector, principals: list[str], k: int) -> list[Scored]
```
- `search_dense` **DEVE** pré-filtrar por `allowed_principals ∩ principals` **dentro** do store,
  antes de rankear. Pós-filtro é proibido.

### LexicalStorePort
```python
def index(chunks: list[Chunk]) -> None
def delete_by_page(page_id: str) -> None
def search_bm25(query: str, principals: list[str], k: int) -> list[Scored]
```
- Mesmo pré-filtro de principals que o vetorial.

### MetadataStorePort
```python
def upsert_page(page: Page) -> None
def get_page_version(page_id: str) -> int | None
def all_indexed_page_ids(space_key: str) -> set[str]     # p/ reconciliação de exclusões
def create_job(job: SyncJob) -> None
def update_job(job: SyncJob) -> None
def get_job(job_id: str) -> SyncJob | None
def get_active_job() -> SyncJob | None
def upsert_user_groups(account_id: str, group_ids: list[str]) -> None
def get_user_groups(account_id: str) -> list[str] | None
```

### LockPort
```python
@contextmanager
def acquire(scope: str, blocking: bool=False) -> Lock    # exclusão mútua entre réplicas
```
- v1 file/process lock ⇒ **worker em réplica única**. Produção: advisory lock do Postgres.

### EmbeddingPort
```python
async def embed_documents(texts: list[str]) -> list[Vector]   # task_type=RETRIEVAL_DOCUMENT
async def embed_query(text: str) -> Vector                    # task_type=RETRIEVAL_QUERY
```

### RerankerPort
```python
def rerank(query: str, candidates: list[Scored], top_k: int) -> list[Scored]   # bge-reranker-v2-m3
```

### GeneratorPort
```python
async def generate(prompt: str) -> str
```

### IdentityPort
```python
async def resolve_account_id(user_token: str) -> AccountId    # SSO → accountId (cache de sessão)
```

## Portas de entrada (driving)

### SyncService
```python
async def start(scope: list[str] | None, mode: SyncMode) -> job_id
async def status(job_id: str) -> SyncStatus
async def current() -> SyncStatus | None
async def cancel(job_id: str) -> SyncStatus
```

### QueryService
```python
async def answer(question: str, user_token: str, top_k: int = 5) -> QueryResult
```
Fluxo: `resolve_account_id` → grupos locais → `principals` → híbrido (dense+BM25) com pré-filtro,
over-fetch 50 → RRF → rerank top-5 → `AccessVerifierPort.verify` (fail-closed) → prompt → generate.
Todos removidos ⇒ `QueryResult(found=false)`.

---

## Suíte de conformidade de adaptador (FR-028) — GATE de produção

Executada contra **qualquer** implementação de `VectorStorePort` e `LexicalStorePort`. Um adaptador
só é apto a produção após passar a suíte completa. Casos **obrigatórios**:

| # | Caso | Asserção |
|---|---|---|
| C1 | Pré-filtro por principal | Chunk com `allowed_principals=[g1]` só aparece p/ usuário com `g1` |
| C2 | **Vazamento com principal parcial** | Usuário com `[g2]` **não** vê chunk `[g1,g3]` (interseção vazia) |
| C3 | `public` | Chunk `[public]` aparece p/ qualquer usuário |
| C4 | Lista vazia de principals | Busca com `principals=[]` retorna **conjunto vazio** (nunca "tudo") |
| C5 | Delete por `page_id` | Após `delete_by_page(p)`, nenhum chunk de `p` é recuperável |
| C6 | Upsert idempotente | Reindexar a mesma página não duplica chunks nem altera contagem |
| C7 | Multi-principal do usuário | Usuário com `[g1,g4]` vê chunk se qualquer um intersecta |
| C8 | Determinismo do filtro | O filtro é aplicado **antes** do ranking (não recorta top-K pós-hoc) |

- C2 e C4 são os casos negativos de ACL — a razão de a suíte existir. Falhá-los reprova o adaptador
  independentemente da qualidade de recuperação.
- A mesma suíte roda no CI para `chroma`/`sqlite_fts5` (v1) e `pgvector`/`postgres_fts` (produção).
