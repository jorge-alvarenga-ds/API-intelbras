# Phase 0 — Research: RAG sobre Confluence Cloud com ACL por usuário

Consolida as decisões técnicas e resolve os pontos em aberto do Technical Context. As Open Questions
Q1–Q9 da spec são dependências de terceiros com donos definidos; aqui registramos a **decisão de
engenharia** para cada uma (o default acionável) e a dependência externa que a confirma.

---

## R0. Modelo de enforcement de ACL (pré-filtro + verificação final fail-closed)

- **Decisão**: Duas camadas. (1) **Pré-filtro** por `allowed_principals ∩ principals` dentro do
  store de busca (nunca pós-filtro). (2) **Verificação final** dos page_ids do top-K, **fail-closed**
  (item não confirmado = não autorizado). Fase A usa `NoOpAccessVerifier` e a fronteira é o escopo;
  Fase B usa CQL `id in (...)` com o token do usuário.
- **Rationale**: Mudança de restrição no Confluence não altera `lastModified`; o delta sync por CQL
  nunca reprocessa a página. Só a verificação em runtime fecha a janela de inconsistência. Fail-closed
  é obrigatório em ambiente bancário — indisponibilidade da origem não pode virar vazamento
  (Clarification 2026-08-11).
- **Alternativas rejeitadas**: Pós-filtro (vaza via ranking/score e contagem); confiar só no metadado
  de sync (janela de inconsistência indeterminada); fail-open com aviso (achado de auditoria).

## R1. Filtro de principals no vector store (o ponto onde a abstração vaza)

- **Decisão**: `VectorStorePort` expõe busca densa **com pré-filtro obrigatório** de principals. No
  adaptador Chroma, materializar cada principal como chave booleana de metadado (`acl:{group_id}:
  true`) e montar `$or` sobre os principals do usuário. Em produção (pgvector), o filtro é
  `allowed_principals && :principals` (operador de interseção de array com índice GIN).
- **Rationale**: Metadados de Chroma são escalares, não listas — um array `allowed_principals` não é
  filtrável nativamente. A materialização booleana é a única forma de pré-filtrar no Chroma; degrada
  com muitos grupos, o que é aceitável no v1 e é justamente por isso que pgvector é o alvo.
- **Alternativas rejeitadas**: Pós-filtro na aplicação (viola R0); um índice por grupo (explode);
  guardar nomes de grupo (mutáveis — ver R5).

## R2. Vector store e lexical store — v1 vs. produção

- **Decisão**: v1 = **Chroma** (denso) + **SQLite FTS5** (BM25) + **SQLite** (metadados/jobs/cache).
  Produção = **PostgreSQL + pgvector** (denso, FTS e advisory locks num só motor). Fusão **RRF** no
  núcleo. Gatilho de migração: corpus > ~50k chunks, necessidade de > 1 worker de ingestão, ou p95 de
  consulta sob pressão de latência do RRF montado na aplicação.
- **Rationale**: SQLite/Chroma zeram custo de infraestrutura para o piloto e são descartáveis atrás
  das portas. Postgres unifica os três stores e habilita advisory lock real (multi-réplica).
- **Alternativas rejeitadas**: Começar já em pgvector (custo/atrito no piloto sem retorno); motor de
  busca dedicado (Elastic/OpenSearch) no v1 (operação pesada demais para o estágio).
- **Limite documentado**: a stack v1 **não é apta a produção** até passar a suíte de conformidade;
  marcar explicitamente para não ser promovida "porque já funciona".

## R3. Coordenação de ingestão resumível (LockPort + fila no banco)

- **Decisão**: O banco é a fila (sem broker externo). `MetadataStorePort` guarda páginas, jobs e
  checkpoints; upsert idempotente por `page_id` (DELETE+INSERT em transação). `LockPort`: file/process
  lock no v1 (⇒ **worker em réplica única, obrigatório**), advisory lock do Postgres em produção
  (multi-réplica). SIGTERM cooperativo: conclui a página atual, faz commit e sai.
- **Rationale**: Estado durável no banco dá retomada de checkpoint sem reprocessar; evita a
  complexidade de Celery/Redis num serviço que já tem um banco.
- **Alternativas rejeitadas**: Broker (Celery/RQ) — infra extra; lock em memória — não coordena entre
  processos.

## R4. Parsing ADF fora do event loop

- **Decisão**: Conversão ADF → Markdown roda em `ProcessPoolExecutor`; o loop async faz apenas I/O
  (fetch Confluence, embedding, persistência).
- **Rationale**: Parsing é CPU-bound; rodá-lo no event loop derruba o health check e serializa o
  throughput. Walker próprio para controlar tabelas (com cabeçalho), blocos de código (não cortar) e
  macros (`expand`, `jira`, `include`, `excerpt`) — a lib genérica vaza JSON de macro.
- **Alternativas rejeitadas**: Threads (GIL limita CPU-bound); conversão via HTML storage format
  (perde estrutura de heading para o chunking hierárquico).

## R5. Principals por group ID imutável + sync de grupos invertido

- **Decisão**: `allowed_principals` guarda **group ID** (+ `user:{accountId}`, `public`), nunca nome.
  Sync de grupos diário (batch, consulta invertida: grupo → membros → expansão recursiva de aninhados
  → achatamento) monta tabela local `accountId → [group_ids]`. Runtime resolve grupos do usuário via
  lookup local (zero chamadas ao Confluence no caminho crítico).
- **Rationale**: Nome de grupo é mutável — renomear zera a interseção silenciosamente; recriar com
  nome reaproveitado vira vazamento. `memberof` em runtime retorna 403 com credencial não-admin e
  adiciona latência. A consulta invertida evita ambos.
- **Alternativas rejeitadas**: `memberof` em runtime (403 + latência); guardar nomes de grupo
  (mutável); IdP corporativo direto no v1 (dependência não confirmada — ver Q1).

## R6. Embedding e geração (provedor configurável, default Vertex/Gemini)

- **Decisão**: `EmbeddingPort` e `GeneratorPort` são configuráveis; **default Vertex AI / Gemini**
  (padrão do banco), com `task_type=RETRIEVAL_DOCUMENT` na ingestão e `RETRIEVAL_QUERY` na consulta.
  Reranker = `bge-reranker-v2-m3` **local** (multilíngue, soberania do dado, sem custo por chamada).
- **Rationale**: Alinha com a stack Gemini/Vertex já usada no banco (ver skill de avaliação). Task
  types distintos melhoram a recuperação assimétrica query↔documento. Reranker local resolve o
  resíduo multilíngue sem exportar conteúdo.
- **Dependências (não bloqueantes)**: Q6 (rerank self-hosted vs. gerenciado — decidido self-hosted),
  Q7 (LLM de geração e **região** — confirmar região aprovada com Arquitetura antes do deploy).
- **Alternativas rejeitadas**: Embeddings sem task_type (pior recuperação); reranker via API gerenciada
  (custo + saída de dado).

## R7. Fluxo de consulta stateless + cache por principals

- **Decisão**: `POST /query` é **stateless / single-turn** (Clarification 2026-08-11). Over-fetch
  top-50 → rerank → top-5 → verificação final. Cache de resposta com chave que **inclui os principals
  do usuário** (+ pergunta normalizada + top_k). Over-fetch com retry ampliando K quando o filtro
  colapsa o conjunto.
- **Rationale**: Cache sem principals na chave é vazamento entre usuários. Single-turn mantém contrato
  e cache simples; query rewriting (P1) e agentic RAG (P2) ficam para depois, com o retrieval já
  desenhado como passo isolável.
- **Alternativas rejeitadas**: Multi-turn no v1 (amplia escopo e complica cache); cache só por pergunta
  (vazamento).

## R8. Autorização da API de operação (papel de operador dedicado)

- **Decisão**: Endpoints de sync/operação (`POST /sync`, `/sync/{id}/cancel`, `GET /sync/*`) exigem
  **papel de operador** dedicado, autenticado, **separado** do acesso de consulta do usuário final
  (Clarification 2026-08-11). Consulta usa Bearer token do usuário; operação usa credencial de
  operador/serviço. Trilha de acesso de operação separada da trilha de consulta.
- **Rationale**: Menor privilégio; disparar/cancelar ingestão é operação sensível que não deve ser
  exposta a todo consumidor de consulta. Alinha com FR-025 (trilhas separadas).
- **Alternativas rejeitadas**: Mesma auth da consulta (privilégio excessivo); só perímetro de rede
  (sem defesa em profundidade na aplicação).

## R9. Observabilidade, auditoria e segurança do índice

- **Decisão**: `trace_id` propagado ponta a ponta (OpenTelemetry); log estruturado (structlog) por
  consulta (`accountId`, page_ids recuperados, page_ids aprovados, `trace_id`) e por página na
  ingestão (versão, resultado); dados sensíveis mascarados. Índice criptografado em repouso (chave da
  organização), sem exposição pública, credenciais em cofre com rotação, trilhas separadas.
- **Rationale**: Auditoria bancária exige evidência de que o enforcement roda por consulta. Custo de
  tokens e taxa de "não encontrei" instrumentados para o gate de qualidade.
- **Dependências**: Q4 (classificação/retenção do índice — herda a classificação do conteúdo mais
  restrito indexado; confirmar com Segurança+Compliance antes do rollout).

## R10. Avaliação (DeepEval) e gate de qualidade

- **Decisão**: Golden set de ~50 perguntas reais (construído com os donos da allowlist). Métricas:
  `ContextualPrecisionMetric` (NDCG@5 ≥ 0,75), faithfulness/groundedness, answer relevance, taxa de
  "não encontrei" indevido. Execução por script (`python evaluation/run_eval.py`), juiz Gemini. Gate:
  nenhuma alteração de prompt/chunking/recuperação/embedding/modelo vai a produção sem passar os
  limiares.
- **Rationale**: Princípio IV; regressões em RAG só são gerenciáveis se mensuráveis. Alinha com a
  skill de avaliação de agentes do banco (DeepEval, juiz Gemini, relatório HTML).
- **Alternativas rejeitadas**: Avaliação manual ad-hoc (não reproduzível, não gateável).

---

## Dependências externas → fase bloqueada (resumo)

| Q | Decisão de engenharia registrada | Dono da confirmação | Bloqueia |
|---|---|---|---|
| Q1 | Tabela de correlação `SSO ↔ accountId` se não houver atributo comum | Engenharia + IAM | Fase B |
| Q2 | OAuth 3LO do usuário para a verificação final | Segurança + Atlassian admin | Fase B |
| Q3 | Conta de serviço com leitura só na allowlist, sem admin global | Atlassian admin | Fase A |
| Q4 | Índice herda a classificação do conteúdo mais restrito indexado | Segurança + Compliance | Fase A |
| Q9 | Lista confirmada de espaços sem restrição de página | Donos + Atlassian admin | Fase A |
| Q5 | Allowlist v1 + dono nomeado por espaço | Donos de conteúdo | — |
| Q6 | Reranker self-hosted `bge-reranker-v2-m3` | Engenharia | — |
| Q7 | LLM Gemini/Vertex; **região a confirmar** | Arquitetura | — (pré-deploy) |
| Q8 | Anexos fora do v1 (P1) | Produto + donos | — |

**Todos os NEEDS CLARIFICATION do Technical Context estão resolvidos** com decisão acionável; as
dependências de terceiros restantes são de provisionamento/aprovação, não de design.
