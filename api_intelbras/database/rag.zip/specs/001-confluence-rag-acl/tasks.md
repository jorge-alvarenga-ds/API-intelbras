---
description: "Task list for Confluence RAG API with per-user ACL"
---

# Tasks: RAG sobre Confluence Cloud com ACL por usuário

**Input**: Design documents from `specs/001-confluence-rag-acl/`

**Prerequisites**: [plan.md](plan.md), [spec.md](spec.md), [research.md](research.md),
[data-model.md](data-model.md), [contracts/](contracts/)

**Tests**: Incluídos onde os requisitos os exigem explicitamente — suíte de conformidade de adaptador
(FR-028), testes adversariais de ACL (SC-001), testes de contrato da API (Princípio III) e o gate de
avaliação DeepEval (Princípio IV). Em ambiente bancário regulado, esses testes são gate, não opção.

**Organization**: Tarefas agrupadas por user story para implementação e teste independentes.

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Pode rodar em paralelo (arquivos diferentes, sem dependências pendentes)
- **[Story]**: A qual user story a tarefa pertence (US1–US4)
- Todos os caminhos assumem projeto único em `src/rag_confluence/` (ver plan.md)

## Path Conventions

- Núcleo: `src/rag_confluence/domain/` (sem import de infraestrutura — verificado por lint)
- Portas: `src/rag_confluence/ports/`
- Adaptadores: `src/rag_confluence/adapters/`
- Aplicação (HTTP/CLI/DI): `src/rag_confluence/app/`
- Testes: `tests/{unit,conformance,integration,adversarial,contract}/`
- Avaliação: `evaluation/`

---

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Inicialização do projeto e estrutura base

- [X] T001 Criar a estrutura de diretórios per plan.md (`src/rag_confluence/{domain,ports,adapters,app}`, `tests/{unit,conformance,integration,adversarial,contract}`, `evaluation/`)
- [X] T002 Inicializar projeto Python 3.11 com `pyproject.toml` e dependências (fastapi, uvicorn, pydantic v2, httpx, chromadb, typer, tenacity, structlog, opentelemetry-sdk, FlagEmbedding, deepeval, pytest, schemathesis, import-linter)
- [X] T003 [P] Configurar ruff + black + mypy em `pyproject.toml`
- [X] T004 [P] Configurar contrato do import-linter proibindo imports de infraestrutura em `domain/` e `ports/` em `pyproject.toml`/`.importlinter`
- [X] T005 [P] Preparar configuração do pytest e `conftest.py` base em `tests/conftest.py`
- [X] T006 [P] Criar workflow de CI executando lint, import-linter, unit e conformance em `.github/workflows/ci.yml`

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Infraestrutura central que TODAS as user stories usam

**⚠️ CRITICAL**: Nenhuma user story pode começar antes desta fase concluída

- [X] T007 [P] Definir modelos de domínio (Principal, EffectiveAcl, Page, Chunk, SyncJob, QueryResult, AuditRecord, UserGroupMap, GoldenItem) em `src/rag_confluence/domain/models.py`
- [X] T008 [P] Implementar interseção de principals + invariante group-ID-only (nunca nome) em `src/rag_confluence/domain/acl/principals.py`
- [X] T009 [P] Definir Protocols das portas de origem (ContentSourcePort, AclSourcePort, DirectorySourcePort, AccessVerifierPort) em `src/rag_confluence/ports/`
- [X] T010 [P] Definir Protocols das portas de store (VectorStorePort, LexicalStorePort, MetadataStorePort, LockPort) em `src/rag_confluence/ports/`
- [X] T011 [P] Definir Protocols das portas de capacidade (EmbeddingPort, RerankerPort, GeneratorPort, IdentityPort) em `src/rag_confluence/ports/`
- [X] T012 [P] Definir interfaces das portas de entrada (SyncService, QueryService) em `src/rag_confluence/ports/services.py`
- [X] T013 [P] Implementar Settings/config (allowlist versionada, `ACL_PHASE`, seleção de adaptadores, config de provedores) em `src/rag_confluence/app/config.py`
- [X] T014 [P] Configurar logging estruturado (structlog) com mascaramento de dados sensíveis em `src/rag_confluence/app/logging.py`
- [X] T015 [P] Configurar tracing OpenTelemetry + propagação de `trace_id` em `src/rag_confluence/app/tracing.py`
- [X] T016 [P] Implementar app FastAPI base, handlers de erro e endpoint `/health` (expõe `acl_phase` + `verifier_adapter`) em `src/rag_confluence/app/http/app.py` e `src/rag_confluence/main.py`
- [X] T017 [P] Implementar dependências de auth: `userBearer` + `operatorAuth` com separação de papéis em `src/rag_confluence/app/http/auth.py`
- [X] T018 [P] Implementar adaptador MetadataStore (SQLite) + schema (pages, jobs, checkpoints, user_groups) em `src/rag_confluence/adapters/metadata_store/sqlite.py`
- [X] T019 [P] Implementar adaptador LockPort (file/process lock) em `src/rag_confluence/adapters/lock/file_lock.py`
- [X] T020 [P] Implementar adaptador VectorStore (Chroma) com **pré-filtro de principals** (materialização `acl:{gid}` + `$or`) em `src/rag_confluence/adapters/vector_store/chroma.py`
- [X] T021 [P] Implementar adaptador LexicalStore (SQLite FTS5) com **pré-filtro de principals** em `src/rag_confluence/adapters/lexical_store/sqlite_fts5.py`
- [X] T022 [P] Implementar adaptador Embedding (Vertex/Gemini, `task_type` documento/query) em `src/rag_confluence/adapters/embedding/vertex.py`
- [X] T023 [P] Implementar adaptador Reranker (`bge-reranker-v2-m3` local) em `src/rag_confluence/adapters/reranker/bge_local.py`
- [X] T024 [P] Implementar adaptador Generator (Vertex/Gemini) em `src/rag_confluence/adapters/generator/vertex.py`
- [X] T025 [P] Implementar adaptador Identity (BFF token→accountId, cache de sessão) em `src/rag_confluence/adapters/identity/bff.py`
- [X] T026 Implementar composição/DI wiring + log do adaptador ativo na inicialização em `src/rag_confluence/app/composition.py` (depende de T009–T025)

**Checkpoint**: Fundação pronta — user stories podem começar

---

## Phase 3: User Story 1 - Perguntar e receber resposta fundamentada e citada (Priority: P1) 🎯 MVP

**Goal**: O colaborador pergunta em linguagem natural e recebe resposta fundamentada com citação da
página de origem, ou "não encontrei" explícito quando não há base.

**Independent Test**: Com um índice populado por fixtures, submeter perguntas do golden set e
verificar respostas fundamentadas + fontes corretas; pergunta sem base ⇒ "não encontrei".

### Tests for User Story 1 ⚠️

- [X] T027 [P] [US1] Teste de contrato de `POST /query` contra `contracts/openapi.yaml` em `tests/contract/test_query_contract.py`
- [X] T028 [P] [US1] Teste de integração: índice semeado → resposta fundamentada + citada; vazio → "não encontrei" em `tests/integration/test_query_flow.py`
- [X] T029 [P] [US1] Teste unitário da fusão RRF + política de over-fetch/retry em `tests/unit/test_retrieval_fusion.py`
- [X] T030 [P] [US1] Teste unitário da montagem de prompt + formatação de fontes + "não encontrei" em `tests/unit/test_prompt.py`

### Implementation for User Story 1

- [X] T031 [P] [US1] Implementar fusão híbrida RRF (BM25 + denso) + over-fetch(50)/retry ampliando K em `src/rag_confluence/domain/retrieval/fusion.py`
- [X] T032 [P] [US1] Implementar montagem de prompt + resposta "não encontrei" + formatação de fontes em `src/rag_confluence/domain/prompt/assemble.py`
- [X] T033 [P] [US1] Implementar `NoOpAccessVerifier` (Fase A, aprova tudo, permanece no fluxo) em `src/rag_confluence/adapters/access_verifier/noop.py`
- [X] T034 [US1] Implementar `QueryService` (accountId→grupos→principals → híbrido com pré-filtro → rerank → verify → generate) em `src/rag_confluence/app/services/query_service.py` (depende de T020–T025, T031–T033)
- [X] T035 [US1] Implementar cache de resposta com chave incluindo **principals** + pergunta + top_k em `src/rag_confluence/app/services/query_cache.py`
- [X] T036 [US1] Implementar endpoint `POST /query` + DTOs (QueryRequest/QueryResponse) em `src/rag_confluence/app/http/query_router.py` (depende de T034, T017)

**Checkpoint**: US1 funcional e testável de forma independente (com verifier NoOp / Fase A)

---

## Phase 4: User Story 2 - Nenhum conteúdo não autorizado é exposto (ACL faseado) (Priority: P1)

**Goal**: Garantir que nenhum conteúdo não autorizado seja exposto — pré-filtro correto, verificação
final fail-closed (Fase B) e gate de escopo na Fase A.

**Independent Test**: Suíte de conformidade C1–C8 (com C2/C4 negativos) verde; teste adversarial com
usuário sem acesso não revela conteúdo restrito; indisponibilidade do verificador ⇒ fail-closed.

### Tests for User Story 2 ⚠️

- [X] T037 [P] [US2] Suíte de conformidade de adaptador C1–C8 (parametrizada em Chroma + SQLite FTS5; inclui C2 vazamento parcial e C4 lista vazia) em `tests/conformance/test_store_conformance.py`
- [X] T038 [P] [US2] Teste adversarial: principal parcialmente coincidente não vê chunk; sem vazar título/snippet/citação em `tests/adversarial/test_no_leak.py`
- [X] T039 [P] [US2] Teste fail-closed: verificador indisponível ⇒ chunk descartado ⇒ "não encontrei"/503 em `tests/adversarial/test_fail_closed.py`
- [X] T040 [P] [US2] Teste do gate de escopo da Fase A: recusar indexar espaço com restrição quando `ACL_PHASE=A` em `tests/integration/test_phase_gate.py`

### Implementation for User Story 2

- [X] T041 [P] [US2] Implementar `ConfluenceCqlVerifier` (Fase B, fail-closed, token do usuário, CQL `id in (...)`) em `src/rag_confluence/adapters/access_verifier/confluence_cql.py`
- [X] T042 [US2] Aplicar semântica fail-closed no passo de verify do `QueryService` (não confirmado ⇒ excluído; todos removidos ⇒ found=false; política 503) em `src/rag_confluence/app/services/query_service.py`
- [X] T043 [US2] Implementar gate de fase na ingestão (bloquear indexação de espaço com restrição salvo `ACL_PHASE=B`) em `src/rag_confluence/domain/acl/phase_gate.py`
- [X] T044 [US2] Selecionar o verificador por config (NoOp vs ConfluenceCql) e expor `acl_phase`/`verifier_adapter` no `/health` e no log de inicialização em `src/rag_confluence/app/composition.py`

**Checkpoint**: US1 + US2 funcionais; enforcement de ACL comprovado por conformidade + adversarial

---

## Phase 5: User Story 3 - Sincronizar o conteúdo do Confluence de forma resiliente (Priority: P2)

**Goal**: Operador dispara e acompanha a sincronização via API; jobs interrompidos retomam do
checkpoint; réplicas não duplicam ingestão; exclusões são reconciliadas.

**Independent Test**: Disparar sync, interromper e redisparar (retoma sem reprocessar); dois syncs
concorrentes ⇒ 409; página excluída na origem ⇒ removida do índice.

### Tests for User Story 3 ⚠️

- [X] T045 [P] [US3] Teste de contrato dos endpoints `/sync*` contra `contracts/openapi.yaml` em `tests/contract/test_sync_contract.py`
- [X] T046 [P] [US3] Teste de integração: retomada de checkpoint sem reprocessar em `tests/integration/test_sync_resume.py`
- [X] T047 [P] [US3] Teste de integração: exclusão mútua (segundo sync ⇒ 409) em `tests/integration/test_sync_lock.py`
- [X] T048 [P] [US3] Teste de integração: reconciliação remove páginas excluídas em `tests/integration/test_reconcile.py`
- [X] T049 [P] [US3] Testes unitários ADF→Markdown (tabela com cabeçalho, código não cortado, macros) em `tests/unit/test_adf_markdown.py`
- [X] T050 [P] [US3] Testes unitários de chunking hierárquico + prefixo breadcrumb/heading + skip de página trivial em `tests/unit/test_chunking.py`
- [X] T051 [P] [US3] Testes unitários de resolução de ACL efetiva (própria→herança→espaço) em `tests/unit/test_effective_acl.py`

### Implementation for User Story 3

- [X] T052 [P] [US3] Implementar walker ADF→Markdown (tabelas, blocos de código, macros expand/jira/include/excerpt) em `src/rag_confluence/domain/adf/walker.py`
- [X] T053 [P] [US3] Implementar chunking hierárquico + prefixo breadcrumb/heading + filtro de página trivial + `content_hash` em `src/rag_confluence/domain/chunking/hierarchical.py`
- [X] T054 [P] [US3] Implementar resolução de ACL efetiva → materialização de `allowed_principals` em `src/rag_confluence/domain/acl/effective.py`
- [X] T055 [P] [US3] Implementar adaptador Confluence ContentSource (list/get, ancestrais, versões, delta CQL) em `src/rag_confluence/adapters/confluence/content_source.py`
- [X] T056 [P] [US3] Implementar adaptador Confluence AclSource (restrições de página v1 + permissões de espaço) em `src/rag_confluence/adapters/confluence/acl_source.py`
- [X] T057 [P] [US3] Implementar adaptador Confluence DirectorySource (grupos, membros recursivos) em `src/rag_confluence/adapters/confluence/directory_source.py`
- [X] T058 [US3] Implementar sync de grupos invertido (grupos→membros→recursivo→achatamento→UserGroupMap) em `src/rag_confluence/app/services/group_sync.py` (depende de T057, T018)
- [X] T059 [US3] Implementar pipeline do `SyncService` (discover→fetch→parse em ProcessPool→chunk→ACL→embed→upsert idempotente; checkpoint/retomada; SIGTERM cooperativo; backoff 429) em `src/rag_confluence/app/services/sync_service.py` (depende de T052–T056, T018–T022, T043)
- [X] T060 [US3] Implementar reconciliação (diff índice vs Confluence → delete removidos) em `src/rag_confluence/app/services/reconcile.py`
- [X] T061 [US3] Implementar endpoints `/sync`, `/sync/{id}`, `/sync/current`, `/sync/{id}/cancel` com `operatorAuth` em `src/rag_confluence/app/http/sync_router.py` (depende de T059, T017)
- [X] T062 [US3] Implementar CLI operacional (sync, reconcile, group-sync) em `src/rag_confluence/app/cli/main.py`

**Checkpoint**: US1 + US2 + US3 funcionais; índice populado a partir do Confluence real

---

## Phase 6: User Story 4 - Governança de allowlist e auditabilidade (Priority: P3)

**Goal**: Dono de espaço controla inclusão no índice via allowlist versionada; Segurança dispõe de
evidência auditável do que foi recuperado e servido a cada usuário.

**Independent Test**: Espaço fora da allowlist não é indexado mesmo com acesso da conta de serviço;
log estruturado de consulta contém identidade, page_ids recuperados/servidos e trace_id.

### Tests for User Story 4 ⚠️

- [X] T063 [P] [US4] Teste: espaço fora da allowlist não é indexado (mesmo com acesso da conta de serviço) em `tests/integration/test_allowlist.py`
- [X] T064 [P] [US4] Teste: estrutura do log de auditoria por consulta e por página em `tests/integration/test_audit_log.py`

### Implementation for User Story 4

- [X] T065 [P] [US4] Implementar allowlist versionada + guarda de escopo na ingestão em `src/rag_confluence/app/config.py` e guarda no `SyncService`
- [X] T066 [US4] Emitir `AuditRecord` por consulta (accountId, page_ids recuperados/aprovados, trace_id, phase, verifier) em `src/rag_confluence/app/services/query_service.py`
- [X] T067 [US4] Registrar log de ingestão por página (versão, resultado) em `src/rag_confluence/app/services/sync_service.py`
- [X] T068 [US4] Separar a trilha de acesso de operação/índice da trilha de consulta em `src/rag_confluence/app/logging.py`

**Checkpoint**: Todas as user stories independentemente funcionais

---

## Phase 7: Polish & Cross-Cutting Concerns

**Purpose**: Qualidade, segurança e prontidão de produção que atravessam as stories

- [X] T069 [P] Construir golden set + config de métricas DeepEval em `evaluation/golden_set/` e `evaluation/metrics.py`
- [X] T070 [P] Implementar harness de avaliação `evaluation/run_eval.py` (NDCG@5, faithfulness, relevância, taxa de "não encontrei" indevido; juiz Gemini; relatório HTML)
- [X] T071 Integrar o gate de avaliação ao CI/checklist de release (reprovar abaixo dos limiares) em `.github/workflows/ci.yml`
- [X] T072 [P] Documentar criptografia em repouso + segredos/rotação em `docs/security.md`
- [ ] T073 [P] Adicionar adaptadores de produção (pgvector, postgres FTS, postgres metadata, advisory lock) e rodar a suíte de conformidade contra eles em `src/rag_confluence/adapters/` e `tests/conformance/`
- [ ] T074 [P] Harness de validação de performance (query p95 < 3s; sync incremental < 15 min) em `tests/integration/test_performance.py`
- [ ] T075 Executar os cenários de `quickstart.md` ponta a ponta e registrar resultados
- [X] T076 [P] Documentação: README + runbook operacional em `docs/`

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: Sem dependências
- **Foundational (Phase 2)**: Depende do Setup — BLOQUEIA todas as user stories
- **User Stories (Phase 3–6)**: Dependem da Foundational
  - US1 e US2 (ambas P1) formam o MVP de segurança+valor; US2 endurece o caminho que US1 monta
  - US3 (P2) popula o índice real; US1 é testável antes com fixtures
  - US4 (P3) adiciona governança/auditoria sobre US1–US3
- **Polish (Phase 7)**: Depende das stories desejadas concluídas

### User Story Dependencies

- **US1 (P1)**: Após Foundational. Usa `NoOpAccessVerifier`; testável com índice de fixtures
- **US2 (P1)**: Após Foundational. Estende o passo de verify de US1 (T042) e o gate de fase de US3 (T043) — compartilha `query_service.py`, então T042 sequencia após T034
- **US3 (P2)**: Após Foundational. Independente para teste; T059 consome o gate de fase (T043) de US2 quando `ACL_PHASE=A`
- **US4 (P3)**: Após Foundational. T066/T067 tocam serviços de US1/US3 — sequenciar após T034/T059

### Within Each User Story

- Testes escritos primeiro e falhando antes da implementação
- Núcleo (domain) antes de serviços; serviços antes de endpoints
- Modelos/portas (Foundational) antes de qualquer adaptador que os implemente

### Parallel Opportunities

- Setup: T003–T006 em paralelo
- Foundational: T007–T025 amplamente paralelos (arquivos distintos); T026 (composição) por último
- Cada bloco de testes de story marcado [P] roda junto
- Núcleo de US3 (T052–T054) e adaptadores Confluence (T055–T057) em paralelo
- Com equipe: após Foundational, US1/US2 (mesmo par), US3 e US4 podem ser paralelizadas por pessoas diferentes (atenção aos arquivos compartilhados `query_service.py` e `sync_service.py`)

---

## Parallel Example: User Story 1

```bash
# Testes de US1 juntos:
Task: "T027 Teste de contrato de POST /query em tests/contract/test_query_contract.py"
Task: "T028 Teste de integração do fluxo de query em tests/integration/test_query_flow.py"
Task: "T029 Teste unitário da fusão RRF em tests/unit/test_retrieval_fusion.py"
Task: "T030 Teste unitário do prompt em tests/unit/test_prompt.py"

# Núcleo de US1 em paralelo (arquivos distintos):
Task: "T031 Fusão RRF em src/rag_confluence/domain/retrieval/fusion.py"
Task: "T032 Montagem de prompt em src/rag_confluence/domain/prompt/assemble.py"
Task: "T033 NoOpAccessVerifier em src/rag_confluence/adapters/access_verifier/noop.py"
```

---

## Implementation Strategy

### MVP First (US1 + US2)

Dado o contexto bancário, o MVP não é só o valor de Q&A (US1); inclui a garantia de não vazamento
(US2). Sequência recomendada:

1. Phase 1: Setup
2. Phase 2: Foundational (CRÍTICO — bloqueia tudo)
3. Phase 3: US1 (caminho de resposta com verifier NoOp / Fase A)
4. Phase 4: US2 (conformidade + adversarial + fail-closed + gate de fase)
5. **PARAR e VALIDAR**: US1 responde e US2 comprova não vazamento
6. Gate de release: nenhum espaço restrito indexado antes da Fase B

### Incremental Delivery

1. Setup + Foundational → base pronta
2. + US1 → responde sobre índice de fixtures
3. + US2 → enforcement comprovado (habilita corpus irrestrito real)
4. + US3 → ingestão resiliente do Confluence
5. + US4 → governança e auditoria
6. Polish → gate DeepEval, adaptadores de produção, performance, docs

### Parallel Team Strategy

Após a Foundational: um par cuida de US1+US2 (compartilham `query_service.py`), outra pessoa de US3,
outra de US4, coordenando os arquivos compartilhados (`query_service.py`, `sync_service.py`).

---

## Notes

- [P] = arquivos diferentes, sem dependências pendentes
- Verificar que os testes falham antes de implementar
- Commit após cada tarefa ou grupo lógico
- **Gate absoluto**: nenhum espaço com restrição de página/espaço é indexado antes da Fase B
  concluída + teste adversarial limpo (T038/T039) — o gate mais importante do documento
- A stack v1 (SQLite/Chroma) só é apta a produção após passar a suíte de conformidade completa (T037)
