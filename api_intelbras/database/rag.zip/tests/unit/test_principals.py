import pytest

from rag_confluence.domain.acl.principals import (
    PrincipalError,
    build_user_principals,
    group_principal,
    intersects,
    validate_group_ids,
)
from rag_confluence.domain.models import PUBLIC


def test_group_principal_uses_id():
    assert group_principal("5f2a") == "group:5f2a"


def test_group_principal_rejects_name_with_space():
    # FR-012: group principal deve ser ID imutável, não nome (nomes têm espaços).
    with pytest.raises(PrincipalError):
        group_principal("Arquitetura Team")


def test_build_user_principals_includes_public_user_and_groups():
    p = build_user_principals("acc1", ["g1", "g2"])
    assert p == frozenset({PUBLIC, "user:acc1", "group:g1", "group:g2"})


def test_intersects_true_when_group_overlaps():
    allowed = ["group:g1", "group:g3"]
    user = build_user_principals("acc1", ["g1"])
    assert intersects(allowed, user) is True


def test_intersects_false_on_partial_no_overlap():
    # Caso negativo de ACL: usuário com g2 não vê chunk [g1, g3].
    allowed = ["group:g1", "group:g3"]
    user = build_user_principals("acc1", ["g2"])
    assert intersects(allowed, user) is False


def test_intersects_public_visible_to_all():
    assert intersects([PUBLIC], build_user_principals("x", [])) is True


def test_validate_group_ids_rejects_names():
    with pytest.raises(PrincipalError):
        validate_group_ids(["ok-id", "Nome De Grupo"])
