from rag_confluence.domain.models import Chunk, Scored
from rag_confluence.domain.retrieval.fusion import (
    overfetch_size,
    reciprocal_rank_fusion,
)


def _chunk(cid):
    return Chunk(cid, cid.split(":")[0], 0, "SP", "t", ("public",), "", "", "u", 1)


def _ranked(cids):
    return [Scored(_chunk(c), 1.0) for c in cids]


def test_rrf_merges_and_dedups():
    dense = _ranked(["p1:0", "p2:0", "p3:0"])
    lexical = _ranked(["p2:0", "p1:0", "p4:0"])
    fused = reciprocal_rank_fusion([dense, lexical])
    ids = [s.chunk.chunk_id for s in fused]
    assert set(ids) == {"p1:0", "p2:0", "p3:0", "p4:0"}
    # p1 e p2 aparecem em ambas as listas no topo => rankeiam acima de p3/p4
    assert ids[0] in {"p1:0", "p2:0"}
    assert ids[1] in {"p1:0", "p2:0"}


def test_rrf_scores_descending():
    fused = reciprocal_rank_fusion([_ranked(["a:0", "b:0"]), _ranked(["a:0", "c:0"])])
    scores = [s.score for s in fused]
    assert scores == sorted(scores, reverse=True)


def test_overfetch_grows_with_attempt():
    assert overfetch_size(5, 0) < overfetch_size(5, 1) < overfetch_size(5, 2)
    assert overfetch_size(5, 0) >= 50
