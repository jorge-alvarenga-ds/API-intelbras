from rag_confluence.domain.models import Chunk
from rag_confluence.domain.prompt.assemble import (
    build_prompt,
    is_empty,
    sources_from_chunks,
)


def _chunk(pid, breadcrumb="Arq > Padrões > OAuth"):
    return Chunk(f"{pid}:0", pid, 0, "ARQ", "texto do chunk", ("public",), breadcrumb, "", f"http://x/{pid}", 1)


def test_prompt_contains_context_and_question():
    prompt = build_prompt("como faz X?", [_chunk("p1"), _chunk("p2")])
    assert "[1]" in prompt and "[2]" in prompt
    assert "como faz X?" in prompt
    assert "page_id=p1" in prompt


def test_sources_unique_per_page_with_title_from_breadcrumb():
    srcs = sources_from_chunks([_chunk("p1"), _chunk("p1"), _chunk("p2")])
    assert [s.page_id for s in srcs] == ["p1", "p2"]
    assert srcs[0].title == "OAuth"
    assert srcs[0].url == "http://x/p1"


def test_is_empty():
    assert is_empty([]) is True
    assert is_empty([_chunk("p1")]) is False
