from rag_confluence.domain.chunking.hierarchical import (
    breadcrumb_from_ancestors,
    chunk_markdown,
    content_hash,
    is_trivial,
)

LONG = "conteúdo útil " * 30  # > 200 chars


def test_trivial_page_discarded():
    assert is_trivial("# t\n\nolá") is True
    assert chunk_markdown("# t\n\nolá", "BC") == []


def test_chunk_prefixed_with_breadcrumb_and_heading_path():
    md = f"# Seção A\n\n{LONG}\n\n## Sub\n\n{LONG}"
    chunks = chunk_markdown(md, "Arq > Padrões")
    assert len(chunks) == 2
    assert chunks[0].text.startswith("Arq > Padrões | Seção A")
    assert chunks[1].heading_path == "Seção A > Sub"
    assert "Arq > Padrões | Seção A > Sub" in chunks[1].text


def test_code_block_not_split_across_headings():
    md = f"# H\n\n{LONG}\n\n```python\n# não é heading\ncode\n```\n"
    chunks = chunk_markdown(md, "")
    # o '# não é heading' dentro do fence não deve criar nova seção
    assert len(chunks) == 1
    assert "```python" in chunks[0].text


def test_content_hash_stable_and_sensitive():
    assert content_hash("a") == content_hash(" a ")
    assert content_hash("a") != content_hash("b")


def test_breadcrumb_join():
    assert breadcrumb_from_ancestors(["Home", "Arq", ""]) == "Home > Arq"
