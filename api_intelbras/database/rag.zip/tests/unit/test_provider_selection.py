"""Seleção de provedor de embedding/geração por config (flag api/vertex)."""

import pytest

from rag_confluence.app.composition import build_embedding, build_generator
from rag_confluence.app.config import Settings


def test_defaults_are_reference_adapters():
    s = Settings(_env_file=None)
    assert type(build_embedding(s)).__name__ == "HashingEmbedding"
    assert type(build_generator(s)).__name__ == "ExtractiveGenerator"


def test_gemini_provider_selected():
    s = Settings(_env_file=None, embedding_provider="gemini", generator="gemini",
                 gemini_api_key="fake", embedding_dim=768)
    emb = build_embedding(s)
    gen = build_generator(s)
    assert type(emb).__name__ == "GeminiEmbedding"
    assert type(gen).__name__ == "GeminiGenerator"
    assert emb.dim == 768  # sem chamada de rede (cliente é lazy)


def test_backend_flag_api_requires_key():
    pytest.importorskip("google.genai")
    from rag_confluence.adapters._genai import build_client

    with pytest.raises(ValueError):
        build_client("api", api_key="", project="", location="")
    with pytest.raises(ValueError):
        build_client("invalido", api_key="x", project="", location="")
