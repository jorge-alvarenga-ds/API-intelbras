from rag_confluence.domain.acl.effective import resolve_effective_acl
from rag_confluence.domain.models import PUBLIC, AclOrigin, Restrictions, SpacePermissions

OPEN_SPACE = SpacePermissions(is_open=True)
CLOSED_SPACE = SpacePermissions(is_open=False, group_ids=("gspace",))
NO_RESTR = Restrictions(restricted=False)


def test_open_space_no_restriction_is_public():
    acl = resolve_effective_acl(NO_RESTR, [], OPEN_SPACE)
    assert acl.allowed_principals == frozenset({PUBLIC})
    assert acl.is_restricted is False
    assert acl.origin is AclOrigin.SPACE


def test_page_restriction_wins():
    acl = resolve_effective_acl(Restrictions(True, group_ids=("g1",)), [], OPEN_SPACE)
    assert acl.allowed_principals == frozenset({"group:g1"})
    assert acl.is_restricted is True
    assert acl.origin is AclOrigin.PAGE


def test_inherited_from_nearest_ancestor():
    acl = resolve_effective_acl(
        NO_RESTR,
        [Restrictions(True, group_ids=("gnear",)), Restrictions(True, group_ids=("gfar",))],
        OPEN_SPACE,
    )
    assert acl.allowed_principals == frozenset({"group:gnear"})
    assert acl.origin is AclOrigin.INHERITED


def test_closed_space_restricts_to_space_groups():
    acl = resolve_effective_acl(NO_RESTR, [], CLOSED_SPACE)
    assert acl.allowed_principals == frozenset({"group:gspace"})
    assert acl.is_restricted is True
    assert acl.origin is AclOrigin.SPACE
