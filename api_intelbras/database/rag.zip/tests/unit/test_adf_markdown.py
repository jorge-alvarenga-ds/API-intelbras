from rag_confluence.domain.adf.walker import adf_to_markdown


def _p(text):
    return {"type": "paragraph", "content": [{"type": "text", "text": text}]}


def test_heading_and_paragraph():
    adf = {"content": [{"type": "heading", "attrs": {"level": 2}, "content": [{"type": "text", "text": "Título"}]}, _p("corpo")]}
    md = adf_to_markdown(adf)
    assert "## Título" in md
    assert "corpo" in md


def test_table_serialized_with_header():
    adf = {
        "content": [
            {
                "type": "table",
                "content": [
                    {"type": "tableRow", "content": [
                        {"type": "tableHeader", "content": [_p("A")]},
                        {"type": "tableHeader", "content": [_p("B")]},
                    ]},
                    {"type": "tableRow", "content": [
                        {"type": "tableCell", "content": [_p("1")]},
                        {"type": "tableCell", "content": [_p("2")]},
                    ]},
                ],
            }
        ]
    }
    md = adf_to_markdown(adf)
    assert "| A | B |" in md
    assert "| --- | --- |" in md
    assert "| 1 | 2 |" in md


def test_code_block_preserved():
    adf = {"content": [{"type": "codeBlock", "attrs": {"language": "python"}, "content": [{"type": "text", "text": "x = 1\ny = 2"}]}]}
    md = adf_to_markdown(adf)
    assert "```python" in md
    assert "x = 1\ny = 2" in md


def test_macro_body_not_json():
    adf = {"content": [{"type": "bodiedExtension", "attrs": {"extensionKey": "expand"}, "content": [_p("segredo do corpo")]}]}
    md = adf_to_markdown(adf)
    assert "segredo do corpo" in md
    assert "extensionKey" not in md
    assert "{" not in md


def test_excerpt_macro_inlines_body():
    adf = {"content": [{"type": "bodiedExtension", "attrs": {"extensionKey": "excerpt"}, "content": [_p("resumo")]}]}
    md = adf_to_markdown(adf)
    assert md.strip() == "resumo"
