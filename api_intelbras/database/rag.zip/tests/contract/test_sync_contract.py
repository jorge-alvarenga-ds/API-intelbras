"""Contrato dos endpoints /sync (contracts/openapi.yaml) + authZ de operador (FR-019a)."""

import pytest
from fastapi.testclient import TestClient

from rag_confluence.app.http.app import create_app
from tests._helpers import build_env

OP = {"Authorization": "Bearer operator-secret"}
USER = {"Authorization": "Bearer utoken"}


@pytest.fixture()
def client():
    c, _fake, _s = build_env()
    return TestClient(create_app(c))


def test_sync_requires_operator_role(client):
    # Consumidor de consulta NÃO pode disparar sync (FR-019a): 403.
    r = client.post("/sync", json={"mode": "full"}, headers=USER)
    assert r.status_code == 403


def test_sync_requires_auth(client):
    r = client.post("/sync", json={"mode": "full"})
    assert r.status_code == 401


def test_sync_accepts_and_reports_status(client):
    r = client.post("/sync", json={"mode": "full", "spaces": ["ARQ"]}, headers=OP)
    assert r.status_code == 202
    job_id = r.json()["job_id"]
    assert r.json()["status"] == "queued"

    s = client.get(f"/sync/{job_id}", headers=OP)
    assert s.status_code == 200
    body = s.json()
    assert set(body) >= {"job_id", "status", "processed", "total", "scope"}


def test_sync_scope_outside_allowlist_rejected(client):
    r = client.post("/sync", json={"mode": "full", "spaces": ["HR"]}, headers=OP)
    assert r.status_code == 400


def test_sync_unknown_job_404(client):
    r = client.get("/sync/does-not-exist", headers=OP)
    assert r.status_code == 404
