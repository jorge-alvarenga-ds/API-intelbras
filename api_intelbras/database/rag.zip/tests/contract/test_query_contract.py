"""Contrato de POST /query (contracts/openapi.yaml)."""

import pytest
from fastapi.testclient import TestClient

from rag_confluence.app.http.app import create_app
from rag_confluence.domain.models import SyncMode
from tests._helpers import build_env


@pytest.fixture()
def client():
    c, _fake, _s = build_env()
    import asyncio

    asyncio.get_event_loop_policy().new_event_loop()
    asyncio.run(c.sync_service.run_sync(["ARQ"], SyncMode.FULL))
    return TestClient(create_app(c))


def test_query_requires_auth(client):
    r = client.post("/query", json={"question": "oi"})
    assert r.status_code == 401


def test_query_returns_contract_shape(client):
    r = client.post(
        "/query", json={"question": "rotação do refresh token"},
        headers={"Authorization": "Bearer utoken"},
    )
    assert r.status_code == 200
    body = r.json()
    assert set(body) >= {"answer", "found", "sources", "chunks", "trace_id"}
    assert isinstance(body["sources"], list)
    if body["sources"]:
        assert set(body["sources"][0]) == {"page_id", "title", "url"}
    assert isinstance(body["chunks"], list) and body["chunks"], "esperava trechos em 'chunks'"
    assert set(body["chunks"][0]) == {"page_id", "title", "url", "text", "score"}
    assert body["chunks"][0]["text"]


def test_query_validation_error(client):
    r = client.post(
        "/query", json={"question": ""}, headers={"Authorization": "Bearer utoken"}
    )
    assert r.status_code == 422


def test_whoami_shows_principals(client):
    r = client.get("/whoami", headers={"Authorization": "Bearer utoken"})
    assert r.status_code == 200
    body = r.json()
    assert body["account_id"] == "acc1"
    assert "public" in body["principals"]
    assert "user:acc1" in body["principals"]


def test_whoami_requires_auth(client):
    assert client.get("/whoami").status_code == 401


def test_health_exposes_phase_and_verifier(client):
    r = client.get("/health")
    assert r.status_code == 200
    body = r.json()
    assert body["acl_phase"] == "A"
    assert body["verifier_adapter"] == "NoOpAccessVerifier"
