"""US2: usuário sem acesso não recebe conteúdo restrito (Fase B, teste adversarial)."""

import pytest

from rag_confluence.app.composition import build_container
from rag_confluence.app.config import Settings
from rag_confluence.adapters.fakes.confluence import FakeConfluence
from rag_confluence.domain.models import AclPhase, SyncMode
from tests._helpers import LONG, doc, heading, para


def _restricted_env():
    # Fase B para permitir indexar espaço com página restrita; verificador NoOp trocado
    # por um fake que confia no metadado (aqui a fronteira testada é o pré-filtro).
    settings = Settings(
        acl_phase=AclPhase.B, allowlist=["ARQ"], metadata_db_path=":memory:",
        lexical_db_path=":memory:", embedding_dim=128,
    )
    fake = FakeConfluence()
    fake.add_space("ARQ", is_open=True)
    fake.add_group("g-secret", "Segredos")
    # Página pública e página restrita ao grupo g-secret, ambas sobre o mesmo tema.
    fake.add_page("PUB", "ARQ", "Guia Público",
                  doc(heading(1, "Público"), para("Guia público sobre integração." + LONG)))
    fake.add_page("SEC", "ARQ", "Chaves Secretas de Produção",
                  doc(heading(1, "Segredo"), para("As chaves secretas de produção do OAuth são" + LONG)),
                  restricted=True, restr_groups=["g-secret"])
    return settings, fake


class _TrustMetadataVerifier:
    """Verificador que aprova com base no metadado (equivale ao pré-filtro já aplicado)."""

    name = "TrustMetadataVerifier"

    async def verify(self, account_id, page_ids, user_token):
        return set(page_ids)


@pytest.mark.asyncio
async def test_user_without_group_does_not_see_restricted():
    settings, fake = _restricted_env()
    # Usuário SEM o grupo g-secret.
    container = build_container(settings, confluence=fake, identity_map={"utoken": "acc1"})
    container.query_service._verifier = _TrustMetadataVerifier()
    await container.sync_service.run_sync(["ARQ"], SyncMode.FULL)

    res = await container.query_service.answer("quais são as chaves secretas de produção?", "utoken")
    page_ids = {s.page_id for s in res.sources}
    assert "SEC" not in page_ids
    assert "chaves secretas de produção" not in res.answer.lower() or not res.found


@pytest.mark.asyncio
async def test_user_with_group_sees_restricted():
    settings, fake = _restricted_env()
    container = build_container(settings, confluence=fake, identity_map={"utoken": "acc1"})
    container.query_service._verifier = _TrustMetadataVerifier()
    # Semeia o mapa de grupos: acc1 pertence a g-secret.
    container.metadata_store.upsert_user_groups("acc1", ["g-secret"])
    await container.sync_service.run_sync(["ARQ"], SyncMode.FULL)

    res = await container.query_service.answer("quais são as chaves secretas de produção?", "utoken")
    assert any(s.page_id == "SEC" for s in res.sources)
