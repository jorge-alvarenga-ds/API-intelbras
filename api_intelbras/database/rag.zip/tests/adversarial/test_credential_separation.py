"""US2 / FR-011: token do usuário na verificação; conta de serviço NUNCA na verificação.

Fecha a lacuna G1 do /speckit-analyze (invariante de credencial sem teste).
"""

import pytest

from rag_confluence.adapters.access_verifier.confluence_cql import ConfluenceCqlVerifier
from rag_confluence.domain.models import SyncMode
from tests._helpers import build_env


class _Resp:
    def __init__(self, status, body):
        self.status_code = status
        self._body = body

    def json(self):
        return self._body


class _SpyClient:
    def __init__(self):
        self.captured_auth = None

    async def get(self, url, headers=None, params=None):
        self.captured_auth = headers.get("Authorization")
        return _Resp(200, {"results": [{"content": {"id": "P1"}}]})


@pytest.mark.asyncio
async def test_verifier_uses_user_token_not_service_account():
    spy = _SpyClient()
    verifier = ConfluenceCqlVerifier("https://x", http_client=spy)
    approved = await verifier.verify("acc1", ["P1"], user_token="USER-TOKEN-123")
    assert spy.captured_auth == "Bearer USER-TOKEN-123"  # token do USUÁRIO, não da conta de serviço
    assert approved == {"P1"}


class _CaptureVerifier:
    name = "CaptureVerifier"

    def __init__(self):
        self.seen_token = None

    async def verify(self, account_id, page_ids, user_token):
        self.seen_token = user_token
        return set(page_ids)


@pytest.mark.asyncio
async def test_query_service_forwards_user_token_to_verifier():
    c, _fake, _s = build_env(identity_map={"utoken-xyz": "acc1"})
    capture = _CaptureVerifier()
    c.query_service._verifier = capture
    await c.sync_service.run_sync(["ARQ"], SyncMode.FULL)
    await c.query_service.answer("rotação do refresh token", "utoken-xyz")
    assert capture.seen_token == "utoken-xyz"


def test_sync_service_has_no_access_to_user_token():
    # Estrutural: o SyncService (ingestão) usa content/acl (conta de serviço) e NÃO
    # recebe token de usuário em nenhum método (FR-011). O verificador é outro objeto.
    c, _fake, _s = build_env()
    assert c.sync_service is not c.access_verifier
    assert "user_token" not in c.sync_service.run_sync.__code__.co_varnames
