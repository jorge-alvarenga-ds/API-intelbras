"""US2: verificação final FAIL-CLOSED (FR-007) — indisponibilidade não vaza."""

import pytest

from rag_confluence.adapters.access_verifier.confluence_cql import ConfluenceCqlVerifier
from rag_confluence.domain.models import SyncMode
from tests._helpers import build_env


class _BoomVerifier:
    """Simula verificador que sempre falha (timeout/indisponibilidade)."""

    name = "BoomVerifier"

    async def verify(self, account_id, page_ids, user_token):
        # Fail-closed: em erro, nenhum page_id é aprovado.
        try:
            raise TimeoutError("confluence indisponível")
        except TimeoutError:
            return set()


@pytest.mark.asyncio
async def test_fail_closed_returns_not_found_when_verifier_unavailable():
    c, _fake, _s = build_env()
    c.query_service._verifier = _BoomVerifier()
    await c.sync_service.run_sync(["ARQ"], SyncMode.FULL)
    res = await c.query_service.answer("como faço a rotação do refresh token?", "utoken")
    assert res.found is False
    assert res.sources == ()


@pytest.mark.asyncio
async def test_confluence_verifier_fails_closed_on_exception():
    class _BrokenClient:
        async def get(self, *a, **k):
            raise ConnectionError("rede caiu")

    v = ConfluenceCqlVerifier("https://x", http_client=_BrokenClient())
    approved = await v.verify("acc1", ["P1", "P2"], user_token="tok")
    assert approved == set()  # nada aprovado em falha


@pytest.mark.asyncio
async def test_confluence_verifier_fails_closed_without_user_token():
    v = ConfluenceCqlVerifier("https://x")
    approved = await v.verify("acc1", ["P1"], user_token=None)
    assert approved == set()
