"""Suíte de conformidade de adaptador de store (C1–C8) — GATE de produção (FR-028).

Executada contra QUALQUER implementação de store de busca. C2 (vazamento com principal
parcial) e C4 (lista vazia => vazio) são os casos negativos de ACL: falhá-los reprova o
adaptador para produção independentemente da qualidade de recuperação.
"""

from __future__ import annotations

import asyncio

import pytest

from rag_confluence.adapters.embedding.hashing import HashingEmbedding
from rag_confluence.adapters.lexical_store.sqlite_fts5 import SqliteFts5LexicalStore
from rag_confluence.adapters.vector_store.inmemory import InMemoryVectorStore
from rag_confluence.domain.models import Chunk

_EMB = HashingEmbedding(dim=128)


def _sync(coro):
    return asyncio.get_event_loop().run_until_complete(coro) if False else asyncio.run(coro)


def make_chunk(page_id, idx, text, principals) -> Chunk:
    return Chunk(
        chunk_id=f"{page_id}:{idx}", page_id=page_id, chunk_index=idx, space_key="SP",
        text=text, allowed_principals=tuple(principals), breadcrumb="", heading_path="",
        url=f"http://x/{page_id}", version=1,
    )


class VectorAdapter:
    name = "InMemoryVectorStore"

    def __init__(self):
        self.store = InMemoryVectorStore()

    def add(self, chunks):
        vecs = _sync(_EMB.embed_documents([c.text for c in chunks]))
        for c, v in zip(chunks, vecs):
            c.embedding = tuple(v)
        self.store.upsert(chunks)

    def search(self, query, principals, k):
        vec = _sync(_EMB.embed_query(query))
        return self.store.search_dense(vec, principals, k)

    def delete(self, page_id):
        self.store.delete_by_page(page_id)

    def count(self):
        return self.store.count()


class LexicalAdapter:
    name = "SqliteFts5LexicalStore"

    def __init__(self):
        self.store = SqliteFts5LexicalStore(":memory:")

    def add(self, chunks):
        self.store.index(chunks)

    def search(self, query, principals, k):
        return self.store.search_bm25(query, principals, k)

    def delete(self, page_id):
        self.store.delete_by_page(page_id)

    def count(self):
        return -1  # não aplicável


class ChromaAdapter:
    name = "ChromaVectorStore"

    def __init__(self):
        import uuid

        from rag_confluence.adapters.vector_store.chroma import ChromaVectorStore

        # Coleção única: o EphemeralClient é singleton no processo, então uma coleção
        # fixa vazaria dados entre instâncias de teste.
        self.store = ChromaVectorStore(collection=f"chunks_{uuid.uuid4().hex}")

    def add(self, chunks):
        vecs = _sync(_EMB.embed_documents([c.text for c in chunks]))
        for c, v in zip(chunks, vecs):
            c.embedding = tuple(v)
        self.store.upsert(chunks)

    def search(self, query, principals, k):
        vec = _sync(_EMB.embed_query(query))
        return self.store.search_dense(vec, principals, k)

    def delete(self, page_id):
        self.store.delete_by_page(page_id)

    def count(self):
        return self.store.count()


_ADAPTERS = [VectorAdapter, LexicalAdapter]
try:  # Chroma só entra na suíte se a dependência estiver instalada (.[prod])
    import chromadb  # noqa: F401

    _ADAPTERS.append(ChromaAdapter)
except Exception:  # noqa: BLE001
    pass


@pytest.fixture(params=_ADAPTERS, ids=lambda a: a.name)
def store(request):
    return request.param()


# --------------------------------------------------------------------------- C1
def test_c1_prefilter_by_principal(store):
    store.add([make_chunk("p1", 0, "oauth refresh token rotation", ["group:g1"])])
    assert [s.chunk.page_id for s in store.search("oauth refresh token", ["group:g1"], 5)] == ["p1"]
    assert store.search("oauth refresh token", ["group:g2"], 5) == []


# --------------------------------------------------------------------------- C2
def test_c2_no_leak_partial_principal(store):
    # Usuário com [g2] NÃO pode ver chunk [g1, g3] (interseção vazia).
    store.add([make_chunk("secret", 0, "oauth refresh token secreto", ["group:g1", "group:g3"])])
    results = store.search("oauth refresh token", ["group:g2"], 5)
    assert results == []


# --------------------------------------------------------------------------- C3
def test_c3_public_visible_to_all(store):
    store.add([make_chunk("pub", 0, "oauth refresh token publico", ["public"])])
    got = store.search("oauth refresh token", ["public", "user:anyone"], 5)
    assert [s.chunk.page_id for s in got] == ["pub"]


# --------------------------------------------------------------------------- C4
def test_c4_empty_principals_returns_empty(store):
    store.add([make_chunk("pub", 0, "oauth refresh token", ["public"])])
    assert store.search("oauth refresh token", [], 5) == []


# --------------------------------------------------------------------------- C5
def test_c5_delete_by_page(store):
    store.add([make_chunk("p1", 0, "oauth token", ["public"]),
               make_chunk("p1", 1, "outro trecho oauth", ["public"])])
    store.delete("p1")
    assert store.search("oauth token", ["public"], 5) == []


# --------------------------------------------------------------------------- C6
def test_c6_idempotent_upsert(store):
    ch = make_chunk("p1", 0, "oauth token idempotente", ["public"])
    store.add([ch])
    store.add([make_chunk("p1", 0, "oauth token idempotente", ["public"])])
    got = store.search("oauth token idempotente", ["public"], 10)
    assert len([s for s in got if s.chunk.page_id == "p1"]) == 1


# --------------------------------------------------------------------------- C7
def test_c7_multi_principal_user(store):
    store.add([make_chunk("p1", 0, "oauth token multi", ["group:g4"])])
    got = store.search("oauth token multi", ["group:g1", "group:g4"], 5)
    assert [s.chunk.page_id for s in got] == ["p1"]


# --------------------------------------------------------------------------- C8
def test_c8_filter_before_ranking(store):
    # Chunk restrito é o mais relevante; NÃO pode aparecer para quem não tem acesso,
    # mesmo com over-fetch (o filtro é antes do ranking, não recorte pós-hoc do top-K).
    store.add([
        make_chunk("restrito", 0, "oauth refresh token exato exato exato", ["group:secret"]),
        make_chunk("pub1", 0, "oauth coisa publica", ["public"]),
        make_chunk("pub2", 0, "token publico", ["public"]),
    ])
    got = store.search("oauth refresh token exato", ["public"], 3)
    ids = {s.chunk.page_id for s in got}
    assert "restrito" not in ids
