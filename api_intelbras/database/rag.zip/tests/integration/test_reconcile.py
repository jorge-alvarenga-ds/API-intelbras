"""US3 / T048 / FR-020: reconciliação remove do índice o que sumiu na origem."""

import pytest

from rag_confluence.domain.models import SyncMode
from tests._helpers import build_env


@pytest.mark.asyncio
async def test_reconcile_removes_deleted_page():
    c, fake, _s = build_env()
    await c.sync_service.run_sync(["ARQ"], SyncMode.FULL)
    assert {"P1", "P2"} <= c.metadata_store.all_indexed_page_ids("ARQ")

    fake.delete_page("P2")  # excluída na origem
    await c.sync_service.run_sync(["ARQ"], SyncMode.RECONCILE)

    indexed = c.metadata_store.all_indexed_page_ids("ARQ")
    assert "P2" not in indexed
    assert "P1" in indexed

    res = await c.query_service.answer("pipeline de deploy build e testes", "utoken")
    assert all(s.page_id != "P2" for s in res.sources)
