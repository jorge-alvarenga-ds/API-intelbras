import pytest

from rag_confluence.domain.models import SyncMode
from tests._helpers import build_env


@pytest.mark.asyncio
async def test_grounded_answer_with_source():
    c, _fake, _s = build_env()
    await c.sync_service.run_sync(["ARQ"], SyncMode.FULL)
    res = await c.query_service.answer("como faço a rotação do refresh token?", "utoken")
    assert res.found is True
    assert any(src.page_id == "P1" for src in res.sources)
    assert res.sources[0].url.endswith("/pages/P1") or any(s.page_id == "P1" for s in res.sources)
    assert res.trace_id and res.trace_id != "-"
    # trechos (chunks) recuperados vêm com texto e score, não só o link
    assert res.passages, "esperava trechos recuperados"
    assert any("refresh token" in p.text.lower() for p in res.passages)
    assert all(p.text and isinstance(p.score, float) for p in res.passages)


@pytest.mark.asyncio
async def test_not_found_when_no_base():
    c, _fake, _s = build_env()
    await c.sync_service.run_sync(["ARQ"], SyncMode.FULL)
    res = await c.query_service.answer("qual a cotação do euro no mercado hoje?", "utoken")
    assert res.found is False
    assert "não encontrei" in res.answer.lower()
    assert res.sources == ()


@pytest.mark.asyncio
async def test_cache_keyed_by_principals_returns_same_result():
    c, _fake, _s = build_env()
    await c.sync_service.run_sync(["ARQ"], SyncMode.FULL)
    r1 = await c.query_service.answer("rotação do refresh token", "utoken")
    r2 = await c.query_service.answer("rotação do refresh token", "utoken")
    assert r1.trace_id == r2.trace_id  # segundo veio do cache (mesmo objeto)
