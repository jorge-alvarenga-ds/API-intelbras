"""US4 / T064 / FR-024: log estruturado de auditoria por consulta e por página."""

import logging

import pytest

from rag_confluence.domain.models import SyncMode
from tests._helpers import build_env


@pytest.mark.asyncio
async def test_query_audit_record_fields(caplog):
    c, _fake, _s = build_env()
    await c.sync_service.run_sync(["ARQ"], SyncMode.FULL)
    with caplog.at_level(logging.INFO, logger="rag_confluence.audit.query"):
        await c.query_service.answer("rotação do refresh token", "utoken")
    records = [r for r in caplog.records if r.name == "rag_confluence.audit.query"]
    assert records, "faltou log de auditoria de consulta"
    ctx = records[-1].context
    assert set(ctx) >= {
        "trace_id", "account_id", "retrieved_page_ids", "approved_page_ids",
        "phase", "verifier_adapter",
    }
    assert ctx["account_id"] == "acc1"
    assert ctx["verifier_adapter"] == "NoOpAccessVerifier"


@pytest.mark.asyncio
async def test_ingestion_audit_logged_per_page(caplog):
    c, _fake, _s = build_env()
    with caplog.at_level(logging.INFO, logger="rag_confluence.audit.index"):
        await c.sync_service.run_sync(["ARQ"], SyncMode.FULL)
    index_records = [r for r in caplog.records if r.name == "rag_confluence.audit.index"]
    results = {r.context["page_id"]: r.context["result"] for r in index_records}
    assert results.get("P1") == "indexed"
