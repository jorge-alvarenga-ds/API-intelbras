"""US4 / T063 / FR-014: só espaços da allowlist são indexados."""

import pytest

from rag_confluence.adapters.fakes.confluence import FakeConfluence
from rag_confluence.app.composition import build_container
from rag_confluence.app.config import Settings
from rag_confluence.app.services.sync_service import ScopeNotAllowed
from rag_confluence.domain.models import SyncMode
from tests._helpers import LONG, doc, heading, para


def _env():
    settings = Settings(
        allowlist=["ARQ"], metadata_db_path=":memory:", lexical_db_path=":memory:",
        embedding_dim=128,
    )
    fake = FakeConfluence()
    fake.add_space("ARQ", is_open=True)
    fake.add_space("HR", is_open=True)  # conta de serviço "tem acesso", mas fora da allowlist
    fake.add_page("A1", "ARQ", "Arq", doc(heading(1, "A"), para("doc de arquitetura" + LONG)))
    fake.add_page("H1", "HR", "RH", doc(heading(1, "H"), para("folha de pagamento" + LONG)))
    return build_container(settings, confluence=fake, identity_map={"utoken": "acc1"})


@pytest.mark.asyncio
async def test_space_outside_allowlist_not_indexed():
    c = _env()
    await c.sync_service.run_sync(None, SyncMode.FULL)  # escopo default = allowlist
    assert "A1" in c.metadata_store.all_indexed_page_ids("ARQ")
    assert c.metadata_store.all_indexed_page_ids("HR") == set()


@pytest.mark.asyncio
async def test_explicit_non_allowlisted_scope_rejected():
    c = _env()
    with pytest.raises(ScopeNotAllowed):
        await c.sync_service.run_sync(["HR"], SyncMode.FULL)
