"""US2 / T040 / FR-008: Fase A recusa indexar conteúdo restrito."""

import pytest

from rag_confluence.adapters.fakes.confluence import FakeConfluence
from rag_confluence.app.composition import build_container
from rag_confluence.app.config import Settings
from rag_confluence.domain.models import AclPhase, SyncMode
from tests._helpers import LONG, doc, heading, para


def _env(phase):
    settings = Settings(
        acl_phase=phase, allowlist=["ARQ"], metadata_db_path=":memory:",
        lexical_db_path=":memory:", embedding_dim=128,
    )
    fake = FakeConfluence()
    fake.add_space("ARQ", is_open=True)
    fake.add_page("PUB", "ARQ", "Público", doc(heading(1, "P"), para("conteúdo público" + LONG)))
    fake.add_page("SEC", "ARQ", "Restrito", doc(heading(1, "S"), para("conteúdo restrito" + LONG)),
                  restricted=True, restr_groups=["g-sec"])
    return build_container(settings, confluence=fake, identity_map={"utoken": "acc1"})


@pytest.mark.asyncio
async def test_phase_a_blocks_restricted_page():
    c = _env(AclPhase.A)
    job = await c.sync_service.run_sync(["ARQ"], SyncMode.FULL)
    indexed = c.metadata_store.all_indexed_page_ids("ARQ")
    assert "PUB" in indexed
    assert "SEC" not in indexed  # bloqueado pelo gate de fase
    assert any(e.get("error") == "phase_gate_blocked" for e in job.errors)


@pytest.mark.asyncio
async def test_phase_b_allows_restricted_page():
    c = _env(AclPhase.B)
    await c.sync_service.run_sync(["ARQ"], SyncMode.FULL)
    indexed = c.metadata_store.all_indexed_page_ids("ARQ")
    assert {"PUB", "SEC"} <= indexed
