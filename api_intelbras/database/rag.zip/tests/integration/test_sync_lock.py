"""US3 / T047 / FR-016: exclusão mútua — segundo sync rejeitado; lock exclusivo."""

import tempfile
from datetime import datetime

import pytest

from rag_confluence.adapters.lock.file_lock import FileLock
from rag_confluence.app.services.sync_service import ActiveJobExists
from rag_confluence.domain.models import JobStatus, SyncJob, SyncMode
from rag_confluence.ports.lock import LockHeld
from tests._helpers import build_env


@pytest.mark.asyncio
async def test_second_sync_rejected_when_active_job_exists():
    c, _fake, _s = build_env()
    # Injeta um job ativo (simula outra réplica em execução).
    c.metadata_store.create_job(
        SyncJob("busy", JobStatus.RUNNING, ("ARQ",), started_at=datetime.utcnow())
    )
    with pytest.raises(ActiveJobExists):
        await c.sync_service.run_sync(["ARQ"], SyncMode.FULL)


def test_file_lock_is_exclusive_per_scope():
    lock = FileLock(directory=tempfile.mkdtemp())
    with lock.acquire("sync:ARQ"):
        with pytest.raises(LockHeld):
            with lock.acquire("sync:ARQ"):
                pass
    # Após liberar, pode readquirir.
    with lock.acquire("sync:ARQ"):
        pass
