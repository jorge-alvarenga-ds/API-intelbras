"""US3 / T046 / FR-015: retomada sem reprocessar páginas inalteradas."""

import pytest

from rag_confluence.domain.models import SyncMode
from tests._helpers import build_env


@pytest.mark.asyncio
async def test_second_sync_skips_unchanged_pages():
    c, _fake, _s = build_env()
    await c.sync_service.run_sync(["ARQ"], SyncMode.FULL)  # indexa P1, P2

    calls = {"n": 0}
    original = c.embedding.embed_documents

    async def counting(texts):
        calls["n"] += 1
        return await original(texts)

    c.embedding.embed_documents = counting  # espia re-embeddings
    await c.sync_service.run_sync(["ARQ"], SyncMode.FULL)  # nada mudou
    assert calls["n"] == 0  # nenhuma página reprocessada


@pytest.mark.asyncio
async def test_changed_page_is_reprocessed():
    c, fake, _s = build_env()
    await c.sync_service.run_sync(["ARQ"], SyncMode.FULL)

    # Atualiza P1 (nova versão + novo conteúdo).
    fake.pages["P1"].version = 2
    fake.pages["P1"].adf = {"content": [{"type": "paragraph", "content": [
        {"type": "text", "text": "novo conteúdo bem mais longo sobre refresh token " * 10}]}]}

    calls = {"n": 0}
    original = c.embedding.embed_documents

    async def counting(texts):
        calls["n"] += 1
        return await original(texts)

    c.embedding.embed_documents = counting
    await c.sync_service.run_sync(["ARQ"], SyncMode.FULL)
    assert calls["n"] == 1  # só P1 reprocessada
    assert c.metadata_store.get_page_version("P1") == 2
