"""RAG_ALLOWLIST=* — descobre e indexa todos os espaços acessíveis (com gate de fase)."""

import pytest

from rag_confluence.adapters.fakes.confluence import FakeConfluence
from rag_confluence.app.composition import build_container
from rag_confluence.app.config import Settings
from rag_confluence.domain.models import AclPhase, SyncMode
from tests._helpers import LONG, doc, heading, para


def _env(phase=AclPhase.A):
    settings = Settings(
        _env_file=None, acl_phase=phase, allowlist=["*"], metadata_db_path=":memory:",
        lexical_db_path=":memory:", embedding_dim=64,
    )
    fake = FakeConfluence()
    fake.add_space("DDS", is_open=True)
    fake.add_space("HDP", is_open=True)
    fake.add_space("SEG", is_open=False, group_ids=["g-seg"])  # espaço restrito
    fake.add_space("~pessoal", is_open=True)  # pessoal: deve ser ignorado
    fake.add_page("D1", "DDS", "Dev", doc(heading(1, "D"), para("conteúdo de dev" + LONG)))
    fake.add_page("H1", "HDP", "Hub", doc(heading(1, "H"), para("conteúdo de hub" + LONG)))
    fake.add_page("S1", "SEG", "Segredo", doc(heading(1, "S"), para("conteúdo restrito" + LONG)))
    fake.add_page("X1", "~pessoal", "Pessoal", doc(heading(1, "X"), para("nota pessoal" + LONG)))
    return build_container(settings, confluence=fake, identity_map={"u": "acc1"})


@pytest.mark.asyncio
async def test_wildcard_discovers_and_indexes_all_open_spaces():
    c = _env(AclPhase.A)
    job = await c.sync_service.run_sync(None, SyncMode.FULL)  # sem escopo => descobre tudo
    assert "DDS" in job.scope and "HDP" in job.scope and "SEG" in job.scope
    assert "~pessoal" not in job.scope  # pessoal ignorado

    assert "D1" in c.metadata_store.all_indexed_page_ids("DDS")
    assert "H1" in c.metadata_store.all_indexed_page_ids("HDP")
    # Fase A: espaço restrito é descoberto, mas a página restrita NÃO é indexada (gate).
    assert "S1" not in c.metadata_store.all_indexed_page_ids("SEG")


@pytest.mark.asyncio
async def test_wildcard_allows_explicit_scope():
    c = _env(AclPhase.A)
    job = await c.sync_service.run_sync(["DDS"], SyncMode.FULL)  # escopo explícito é permitido
    assert list(job.scope) == ["DDS"]
    assert "D1" in c.metadata_store.all_indexed_page_ids("DDS")
