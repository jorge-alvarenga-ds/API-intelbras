"""Builders compartilhados de ambiente de teste (não é um módulo de teste)."""

from __future__ import annotations

from rag_confluence.adapters.fakes.confluence import FakeConfluence
from rag_confluence.app.composition import Container, build_container
from rag_confluence.app.config import Settings
from rag_confluence.domain.models import AclPhase

LONG = (
    " Este é um trecho de documentação interna com detalhes suficientes para não ser "
    "considerado trivial, cobrindo o assunto com profundidade adequada e vocabulário do domínio. "
) * 3


def para(text: str) -> dict:
    return {"type": "paragraph", "content": [{"type": "text", "text": text}]}


def heading(level: int, text: str) -> dict:
    return {"type": "heading", "attrs": {"level": level}, "content": [{"type": "text", "text": text}]}


def doc(*nodes: dict) -> dict:
    return {"content": list(nodes)}


def seed_default(fake: FakeConfluence) -> None:
    fake.add_space("ARQ", is_open=True)
    fake.add_page(
        "P1", "ARQ", "Rotação de Refresh Token OAuth",
        doc(heading(1, "OAuth"), para(
            "Para fazer a rotação do refresh token no OAuth interno siga o procedimento." + LONG)),
    )
    fake.add_page(
        "P2", "ARQ", "Pipeline de Deploy",
        doc(heading(1, "Deploy"), para("O pipeline de deploy executa build e testes." + LONG)),
    )


def build_env(
    *, phase: AclPhase = AclPhase.A, allowlist=("ARQ",), identity_map=None, seed=True,
) -> tuple[Container, FakeConfluence, Settings]:
    settings = Settings(
        acl_phase=phase, allowlist=list(allowlist), metadata_db_path=":memory:",
        lexical_db_path=":memory:", embedding_dim=128,
    )
    fake = FakeConfluence()
    if seed:
        seed_default(fake)
    container = build_container(
        settings, confluence=fake, identity_map=identity_map or {"utoken": "acc1"}
    )
    return container, fake, settings
