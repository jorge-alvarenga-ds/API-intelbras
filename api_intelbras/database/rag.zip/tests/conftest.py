"""Isolamento dos testes: a suíte NÃO deve ler o `.env` real nem variáveis RAG_* do ambiente.

Garante que `Settings()` use apenas defaults + kwargs explícitos durante os testes,
independentemente de haver um `.env` na raiz (config de operação local do dev).
"""

from __future__ import annotations

import os

import pytest

from rag_confluence.app.config import Settings

# Desliga o carregamento do .env real para todas as instâncias de Settings nos testes.
Settings.model_config["env_file"] = None


@pytest.fixture(autouse=True)
def _hermetic_env(monkeypatch):
    for key in list(os.environ):
        if key.startswith("RAG_"):
            monkeypatch.delenv(key, raising=False)
    yield
