<!--
Sync Impact Report
- Version change: (template não versionado) → 1.0.0
- Ratification: adoção inicial (constituição preenchida a partir do scaffold)
- Modified principles: N/A (ratificação inicial)
- Added principles:
  - I. Respostas Fundamentadas e Citadas (NÃO-NEGOCIÁVEL)
  - II. Recuperação Consciente de Permissões
  - III. Contrato de API em Primeiro Lugar
  - IV. Qualidade Guiada por Avaliação
  - V. Observabilidade e Rastreabilidade
- Added sections:
  - Segurança, Privacidade e Governança de Dados
  - Fluxo de Desenvolvimento e Portões de Qualidade
- Removed sections: nenhuma
- Templates/consistência: constitution.md preenchido; plan/spec/tasks a jusante lidos em runtime, sem alteração necessária
- Follow-up TODOs: nenhum (RATIFICATION_DATE assumido como a data de adoção de hoje; ajustar se houver data original distinta)
-->

# Confluence RAG API Constitution

## Core Principles

### I. Respostas Fundamentadas e Citadas (NÃO-NEGOCIÁVEL)
Toda resposta gerada pela API MUST ser fundamentada exclusivamente no conteúdo recuperado do
Confluence e MUST citar as fontes usadas (título da página e link/ID). O sistema MUST NOT inventar
fatos: quando o contexto recuperado for insuficiente para responder com confiança, a API MUST
declarar explicitamente que a informação não foi encontrada, em vez de especular.
Racional: a confiança dos usuários na base de conhecimento depende de respostas verificáveis e
rastreáveis até a página de origem.

### II. Recuperação Consciente de Permissões
A recuperação MUST respeitar as permissões de acesso do Confluence do solicitante: nenhum trecho,
resumo ou resposta pode expor conteúdo que o usuário chamador não teria permissão de ler no próprio
Confluence. O índice MUST carregar as ACLs/escopos de espaço e a recuperação MUST filtrar pela
identidade do chamador; remoções e alterações de permissão MUST ser propagadas ao índice.
Racional: um RAG sobre conhecimento interno não pode se tornar um canal de vazamento de informação
restrita.

### III. Contrato de API em Primeiro Lugar
A API MUST ser definida por um contrato explícito e versionado (ex.: OpenAPI) antes da
implementação; entradas e saídas MUST ser JSON estável e documentado. Mudanças incompatíveis no
contrato MUST incrementar a versão maior e seguir uma política de depreciação anunciada.
Racional: consumidores dependem da estabilidade e da previsibilidade do contrato para integrar com
segurança.

### IV. Qualidade Guiada por Avaliação
A qualidade de recuperação e de geração MUST ser medida por um conjunto de avaliação (eval)
reproduzível, cobrindo no mínimo recall/precisão de recuperação, fidelidade ao contexto
(groundedness) e relevância da resposta. Qualquer alteração em prompt, estratégia de chunking,
recuperação, embeddings ou modelo MUST passar pelos limiares de avaliação definidos antes de ir
para produção.
Racional: melhorias e regressões em sistemas RAG só são gerenciáveis quando são mensuráveis.

### V. Observabilidade e Rastreabilidade
Cada requisição MUST ser rastreável ponta a ponta (consulta → trechos recuperados → prompt →
resposta → fontes citadas) por meio de logs estruturados e tracing. Latência, custo de tokens e
taxa de "sem resposta" MUST ser instrumentados. Dados sensíveis MUST ser mascarados nos logs.
Racional: depuração, auditoria e controle de custo exigem visibilidade do pipeline completo.

## Segurança, Privacidade e Governança de Dados

- Credenciais de acesso ao Confluence (tokens/API keys) e chaves de modelos MUST ser armazenadas em
  cofre de segredos e MUST NOT ser versionadas no repositório.
- Conteúdo interno da empresa MUST permanecer em ambientes e provedores aprovados; dados do
  Confluence MUST NOT ser usados para treinar modelos de terceiros.
- A ingestão MUST manter o índice sincronizado com o Confluence: atualizações incrementais,
  propagação de exclusões e uma cadência de sincronização definida e monitorada.
- PII e dados sensíveis MUST ser tratados conforme a LGPD e as políticas internas de classificação
  da informação.
- A comunicação MUST usar TLS; dados em repouso (índice vetorial/embeddings) SHOULD ser
  criptografados.

## Fluxo de Desenvolvimento e Portões de Qualidade

- Todo trabalho MUST seguir o fluxo Spec Kit: especificação → plano → tarefas → implementação.
- Código MUST passar por revisão (PR) antes do merge; nenhuma alteração chega à branch principal sem
  revisão e sem testes verdes.
- Contratos de API e componentes críticos (recuperação, permissões e citação de fontes) MUST ter
  testes automatizados; mudanças de contrato MUST incluir testes de contrato.
- O portão de avaliação (Princípio IV) MUST ser executado antes de qualquer deploy que altere o
  comportamento do RAG.
- Complexidade adicional MUST ser justificada; na ausência de justificativa, prevalece a solução
  mais simples (YAGNI).

## Governance

Esta constituição supersede quaisquer outras práticas e convenções do projeto. Emendas MUST ser
documentadas em PR, aprovadas pelos mantenedores e acompanhadas de um plano de migração quando
introduzirem mudanças incompatíveis.

O versionamento desta constituição segue SemVer: MAJOR para remoção ou redefinição incompatível de
princípios ou de governança; MINOR para adição de princípio/seção ou expansão material de
orientação; PATCH para esclarecimentos, correções de texto e refinamentos não semânticos.

Toda revisão/PR MUST verificar a conformidade com esta constituição; violações MUST ser corrigidas
ou explicitamente justificadas e registradas. A orientação de desenvolvimento em tempo de execução
MUST usar os artefatos gerados em `/speckit-plan` (plan.md e os arquivos de orientação do agente).

**Version**: 1.0.0 | **Ratified**: 2026-08-11 | **Last Amended**: 2026-08-11
