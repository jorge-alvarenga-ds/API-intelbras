"""Porta de origem de conteúdo (Confluence Cloud v1/v2)."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol, runtime_checkable

from rag_confluence.domain.models import Page


@dataclass(frozen=True)
class PageRef:
    page_id: str
    version: int
    last_modified: datetime | None = None


@dataclass(frozen=True)
class PageListing:
    refs: tuple[PageRef, ...]
    next_cursor: str | None = None


@runtime_checkable
class ContentSourcePort(Protocol):
    async def list_pages(
        self, space_key: str, since: datetime | None, cursor: str | None
    ) -> PageListing:
        """Delta sync por CQL ``lastModified >= since``. Paginação por cursor."""
        ...

    async def get_page(self, page_id: str) -> Page:
        """Corpo em ADF + ancestrais + versão (sem effective_acl — resolvido no domínio)."""
        ...
