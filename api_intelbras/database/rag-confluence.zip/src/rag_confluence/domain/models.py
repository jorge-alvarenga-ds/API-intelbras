"""Modelos de domínio puros (dataclasses, sem I/O nem imports de infraestrutura).

Referência: specs/001-confluence-rag-acl/data-model.md
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class AclPhase(str, Enum):
    A = "A"
    B = "B"


class SyncMode(str, Enum):
    INCREMENTAL = "incremental"
    FULL = "full"
    RECONCILE = "reconcile"


class JobStatus(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    CANCELLING = "cancelling"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class AclOrigin(str, Enum):
    PAGE = "page"
    INHERITED = "inherited"
    SPACE = "space"


PUBLIC = "public"  # principal canônico que representa "sem restrição efetiva"


# ---------------------------------------------------------------------------
# ACL
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class EffectiveAcl:
    """ACL efetiva resolvida na ingestão (própria -> herança -> espaço)."""

    allowed_principals: frozenset[str]
    origin: AclOrigin

    @property
    def is_restricted(self) -> bool:
        return PUBLIC not in self.allowed_principals


@dataclass(frozen=True)
class Restrictions:
    """Restrições de leitura de uma página (Confluence API v1)."""

    restricted: bool
    group_ids: tuple[str, ...] = ()
    account_ids: tuple[str, ...] = ()


@dataclass(frozen=True)
class SpacePermissions:
    """Permissões de leitura de um espaço."""

    is_open: bool  # visível a todos os participantes -> public
    group_ids: tuple[str, ...] = ()
    account_ids: tuple[str, ...] = ()


# ---------------------------------------------------------------------------
# Conteúdo
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Ancestor:
    id: str
    title: str


@dataclass
class Page:
    page_id: str
    space_key: str
    title: str
    version: int
    url: str
    ancestors: tuple[Ancestor, ...] = ()
    body_adf: dict | None = None
    effective_acl: EffectiveAcl | None = None
    last_modified: datetime | None = None
    content_hash: str | None = None


@dataclass
class Chunk:
    chunk_id: str
    page_id: str
    chunk_index: int
    space_key: str
    text: str
    allowed_principals: tuple[str, ...]
    breadcrumb: str
    heading_path: str
    url: str
    version: int
    embedding: tuple[float, ...] | None = None
    title: str = ""


@dataclass(frozen=True)
class Scored:
    chunk: Chunk
    score: float


# ---------------------------------------------------------------------------
# Consulta
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class Source:
    page_id: str
    title: str
    url: str


@dataclass(frozen=True)
class QueryResult:
    answer: str
    found: bool
    sources: tuple[Source, ...]
    trace_id: str


# ---------------------------------------------------------------------------
# Sincronização
# ---------------------------------------------------------------------------


@dataclass
class SyncJob:
    job_id: str
    status: JobStatus
    scope: tuple[str, ...]
    total: int = 0
    processed: int = 0
    errors: list[dict] = field(default_factory=list)
    checkpoint: dict = field(default_factory=dict)
    cancel_requested: bool = False
    started_at: datetime | None = None
    updated_at: datetime | None = None


@dataclass(frozen=True)
class UserGroupMap:
    account_id: str
    group_ids: tuple[str, ...]
    synced_at: datetime | None = None


# ---------------------------------------------------------------------------
# Auditoria / avaliação
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class AuditRecord:
    trace_id: str
    account_id: str
    retrieved_page_ids: tuple[str, ...]
    approved_page_ids: tuple[str, ...]
    phase: AclPhase
    verifier_adapter: str
    timestamp: datetime


@dataclass(frozen=True)
class GoldenItem:
    question: str
    expected_source_page_ids: tuple[str, ...]
    notes: str = ""
