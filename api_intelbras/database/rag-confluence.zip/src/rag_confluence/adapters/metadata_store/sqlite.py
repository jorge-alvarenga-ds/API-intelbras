"""MetadataStore em SQLite: páginas, jobs, checkpoints e cache de grupos.

O banco é a fila (sem broker externo): jobs e checkpoints duráveis permitem retomada
e progresso consultável de qualquer réplica (FR-015/FR-019).
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime

from rag_confluence.domain.models import JobStatus, SyncJob


class SqliteMetadataStore:
    def __init__(self, path: str = ":memory:") -> None:
        self._con = sqlite3.connect(path, check_same_thread=False)
        self._con.row_factory = sqlite3.Row
        self._init_schema()

    def _init_schema(self) -> None:
        c = self._con
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS pages(
                page_id TEXT PRIMARY KEY, space_key TEXT, version INTEGER, content_hash TEXT);
            CREATE TABLE IF NOT EXISTS jobs(
                job_id TEXT PRIMARY KEY, status TEXT, scope TEXT, total INTEGER, processed INTEGER,
                errors TEXT, checkpoint TEXT, cancel_requested INTEGER,
                started_at TEXT, updated_at TEXT);
            CREATE TABLE IF NOT EXISTS user_groups(
                account_id TEXT PRIMARY KEY, group_ids TEXT, synced_at TEXT);
            CREATE INDEX IF NOT EXISTS idx_pages_space ON pages(space_key);
            """
        )
        self._con.commit()

    # ------------------------------------------------------------------ pages
    def upsert_page(self, page_id: str, space_key: str, version: int, content_hash: str) -> None:
        self._con.execute(
            "INSERT INTO pages VALUES(?,?,?,?) ON CONFLICT(page_id) DO UPDATE SET "
            "space_key=excluded.space_key, version=excluded.version, "
            "content_hash=excluded.content_hash",
            (page_id, space_key, version, content_hash),
        )
        self._con.commit()

    def get_page_version(self, page_id: str) -> int | None:
        r = self._con.execute("SELECT version FROM pages WHERE page_id=?", (page_id,)).fetchone()
        return r["version"] if r else None

    def get_page_hash(self, page_id: str) -> str | None:
        r = self._con.execute("SELECT content_hash FROM pages WHERE page_id=?", (page_id,)).fetchone()
        return r["content_hash"] if r else None

    def all_indexed_page_ids(self, space_key: str) -> set[str]:
        rows = self._con.execute(
            "SELECT page_id FROM pages WHERE space_key=?", (space_key,)
        ).fetchall()
        return {r["page_id"] for r in rows}

    def delete_page(self, page_id: str) -> None:
        self._con.execute("DELETE FROM pages WHERE page_id=?", (page_id,))
        self._con.commit()

    # ------------------------------------------------------------------ jobs
    def create_job(self, job: SyncJob) -> None:
        self._con.execute("INSERT INTO jobs VALUES(?,?,?,?,?,?,?,?,?,?)", self._job_row(job))
        self._con.commit()

    def update_job(self, job: SyncJob) -> None:
        row = self._job_row(job)
        self._con.execute(
            "UPDATE jobs SET status=?, scope=?, total=?, processed=?, errors=?, checkpoint=?, "
            "cancel_requested=?, started_at=?, updated_at=? WHERE job_id=?",
            (*row[1:], row[0]),
        )
        self._con.commit()

    def get_job(self, job_id: str) -> SyncJob | None:
        r = self._con.execute("SELECT * FROM jobs WHERE job_id=?", (job_id,)).fetchone()
        return self._to_job(r) if r else None

    def get_active_job(self) -> SyncJob | None:
        r = self._con.execute(
            "SELECT * FROM jobs WHERE status IN (?,?,?) ORDER BY started_at DESC LIMIT 1",
            (JobStatus.QUEUED.value, JobStatus.RUNNING.value, JobStatus.CANCELLING.value),
        ).fetchone()
        return self._to_job(r) if r else None

    # ------------------------------------------------------------ user groups
    def upsert_user_groups(self, account_id: str, group_ids: list[str]) -> None:
        self._con.execute(
            "INSERT INTO user_groups VALUES(?,?,?) ON CONFLICT(account_id) DO UPDATE SET "
            "group_ids=excluded.group_ids, synced_at=excluded.synced_at",
            (account_id, json.dumps(group_ids), datetime.utcnow().isoformat()),
        )
        self._con.commit()

    def get_user_groups(self, account_id: str) -> list[str] | None:
        r = self._con.execute(
            "SELECT group_ids FROM user_groups WHERE account_id=?", (account_id,)
        ).fetchone()
        return json.loads(r["group_ids"]) if r else None

    # ------------------------------------------------------------------ utils
    @staticmethod
    def _job_row(job: SyncJob) -> tuple:
        return (
            job.job_id, job.status.value, json.dumps(list(job.scope)), job.total, job.processed,
            json.dumps(job.errors), json.dumps(job.checkpoint), int(job.cancel_requested),
            job.started_at.isoformat() if job.started_at else None,
            job.updated_at.isoformat() if job.updated_at else None,
        )

    @staticmethod
    def _to_job(r: sqlite3.Row) -> SyncJob:
        return SyncJob(
            job_id=r["job_id"], status=JobStatus(r["status"]), scope=tuple(json.loads(r["scope"])),
            total=r["total"], processed=r["processed"], errors=json.loads(r["errors"]),
            checkpoint=json.loads(r["checkpoint"]), cancel_requested=bool(r["cancel_requested"]),
            started_at=datetime.fromisoformat(r["started_at"]) if r["started_at"] else None,
            updated_at=datetime.fromisoformat(r["updated_at"]) if r["updated_at"] else None,
        )
