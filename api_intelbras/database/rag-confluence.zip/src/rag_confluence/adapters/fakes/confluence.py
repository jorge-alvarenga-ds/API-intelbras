"""Fake do Confluence implementando ContentSource + AclSource + Directory (para testes).

Estado em memória, configurável. Uma única instância satisfaz as três portas de origem,
o que simplifica a composição nos testes de integração e adversariais.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from rag_confluence.domain.models import Ancestor, Page, Restrictions, SpacePermissions
from rag_confluence.ports.content_source import PageListing, PageRef
from rag_confluence.ports.directory_source import Group


@dataclass
class _FakePage:
    page_id: str
    space_key: str
    title: str
    adf: dict
    ancestors: list[Ancestor] = field(default_factory=list)
    version: int = 1
    restricted: bool = False
    restr_groups: tuple[str, ...] = ()
    restr_accounts: tuple[str, ...] = ()
    last_modified: datetime = field(default_factory=datetime.utcnow)


@dataclass
class _FakeSpace:
    key: str
    is_open: bool = True
    group_ids: tuple[str, ...] = ()
    account_ids: tuple[str, ...] = ()


class FakeConfluence:
    def __init__(self) -> None:
        self.pages: dict[str, _FakePage] = {}
        self.spaces: dict[str, _FakeSpace] = {}
        self.groups: dict[str, Group] = {}
        self.direct_members: dict[str, list[str]] = {}
        self.nested_groups: dict[str, list[str]] = {}
        self.base_url = "https://example.atlassian.net"

    # ------------------------------------------------------------ configuração
    def add_space(self, key: str, is_open: bool = True, group_ids=(), account_ids=()) -> None:
        self.spaces[key] = _FakeSpace(key, is_open, tuple(group_ids), tuple(account_ids))

    def add_page(self, page_id, space_key, title, adf, *, ancestors=None, version=1,
                 restricted=False, restr_groups=(), restr_accounts=(), last_modified=None) -> None:
        self.pages[page_id] = _FakePage(
            page_id, space_key, title, adf,
            [Ancestor(a[0], a[1]) for a in (ancestors or [])], version,
            restricted, tuple(restr_groups), tuple(restr_accounts),
            last_modified or datetime.utcnow(),
        )

    def add_group(self, group_id, name, members=(), nested=()) -> None:
        self.groups[group_id] = Group(group_id, name)
        self.direct_members[group_id] = list(members)
        self.nested_groups[group_id] = list(nested)

    def delete_page(self, page_id: str) -> None:
        self.pages.pop(page_id, None)

    # -------------------------------------------------------- ContentSourcePort
    async def list_pages(self, space_key, since, cursor) -> PageListing:
        refs = [
            PageRef(p.page_id, p.version, p.last_modified)
            for p in self.pages.values()
            if p.space_key == space_key and (since is None or p.last_modified >= since)
        ]
        return PageListing(refs=tuple(refs), next_cursor=None)

    async def get_page(self, page_id) -> Page:
        p = self.pages[page_id]
        url = f"{self.base_url}/wiki/spaces/{p.space_key}/pages/{p.page_id}"
        return Page(
            page_id=p.page_id, space_key=p.space_key, title=p.title, version=p.version,
            url=url, ancestors=tuple(p.ancestors), body_adf=p.adf, last_modified=p.last_modified,
        )

    # ------------------------------------------------------------ AclSourcePort
    async def get_page_restrictions(self, page_id) -> Restrictions:
        p = self.pages[page_id]
        return Restrictions(p.restricted, p.restr_groups, p.restr_accounts)

    async def get_space_permissions(self, space_key) -> SpacePermissions:
        s = self.spaces[space_key]
        return SpacePermissions(s.is_open, s.group_ids, s.account_ids)

    # ------------------------------------------------------ DirectorySourcePort
    async def list_groups(self) -> list[Group]:
        return list(self.groups.values())

    async def list_group_members(self, group_id) -> list[str]:
        seen: set[str] = set()
        members: set[str] = set()
        self._expand(group_id, seen, members)
        return sorted(members)

    def _expand(self, group_id, seen: set[str], members: set[str]) -> None:
        if group_id in seen:
            return
        seen.add(group_id)
        members.update(self.direct_members.get(group_id, []))
        for nested in self.nested_groups.get(group_id, []):
            self._expand(nested, seen, members)
