"""Router de consulta (POST /query)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException

from rag_confluence.app.http.auth import user_bearer
from rag_confluence.app.http.dto import QueryRequest, QueryResponse
from rag_confluence.app.services.query_service import VerificationUnavailable
from rag_confluence.ports.identity import IdentityError


def build_query_router(container) -> APIRouter:
    router = APIRouter(tags=["query"])

    @router.post("/query", response_model=QueryResponse)
    async def query(body: QueryRequest, token: str = Depends(user_bearer)) -> QueryResponse:
        try:
            result = await container.query_service.answer(body.question, token, body.top_k)
        except IdentityError as exc:
            raise HTTPException(status_code=401, detail=str(exc)) from exc
        except VerificationUnavailable as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc
        return QueryResponse.from_result(result)

    return router
