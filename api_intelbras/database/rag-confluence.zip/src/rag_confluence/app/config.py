"""Configuração (pydantic-settings). Allowlist versionada e seleção de adaptadores por config."""

from __future__ import annotations

from typing import Annotated

from pydantic import field_validator
from pydantic_settings import BaseSettings, NoDecode, SettingsConfigDict

from rag_confluence.domain.models import AclPhase


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="RAG_", env_file=".env", extra="ignore")

    # ACL / fase
    acl_phase: AclPhase = AclPhase.A

    # Allowlist versionada (FR-014). Aceita lista ou string "ARQ,ENG".
    # NoDecode impede o pydantic-settings de tentar json.loads no valor vindo do .env/env.
    allowlist: Annotated[list[str], NoDecode] = ["ARQ", "ENG"]

    # Seleção de adaptadores (FR-027 — configuração, não código)
    vector_store: str = "inmemory"
    # Caminho de persistência do Chroma (vazio => efêmero, some ao reiniciar).
    chroma_path: str = ""
    lexical_store: str = "sqlite_fts5"
    metadata_store: str = "sqlite"
    embedding_provider: str = "hashing"
    reranker: str = "lexical"
    generator: str = "extractive"
    identity: str = "static"

    # Origem (Confluence Cloud)
    confluence_base_url: str = "https://example.atlassian.net"
    # Token da CONTA DE SERVIÇO (nunca do usuário). Não versionar — use env/.env/cofre.
    confluence_token: str = ""
    # E-mail da conta de serviço. Se preenchido, usa Basic auth (email:token) — padrão do
    # Confluence Cloud com API token. Vazio => Bearer (OAuth 2.0 / PAT).
    confluence_email: str = ""
    # "none" = sem origem (índice vazio / demo injeta fake); "real" = liga os adaptadores httpx.
    confluence_source: str = "none"

    # Recuperação
    top_k: int = 5
    overfetch_retries: int = 2
    embedding_dim: int = 256
    # Piso de relevância pós-rerank: candidatos abaixo disso viram "não encontrei" (FR-002).
    # Com o reranker de referência, score=0 significa nenhuma sobreposição real com a query.
    min_relevance: float = 0.0

    # Persistência (v1)
    metadata_db_path: str = ":memory:"
    lexical_db_path: str = ":memory:"

    # AuthZ de operação (papel de operador dedicado — FR-019a)
    operator_token: str = "operator-secret"

    # Identidade de TESTE local (Fase A, sem BFF/Q1). Deixe vazio em produção.
    # Se preenchido, o token informado resolve para dev_account_id na consulta.
    dev_user_token: str = ""
    dev_account_id: str = "dev-user"

    @field_validator("allowlist", mode="before")
    @classmethod
    def _split_csv(cls, v):
        if isinstance(v, str):
            return [s.strip() for s in v.split(",") if s.strip()]
        return v

    def in_allowlist(self, space_key: str) -> bool:
        return space_key in self.allowlist
