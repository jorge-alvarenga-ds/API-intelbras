"""QueryService: caminho de consulta com pré-filtro, rerank, verificação e geração.

Fluxo (FR-001..FR-013):
  token -> accountId -> grupos locais -> principals
  -> híbrido (denso + BM25) PRÉ-FILTRADO, over-fetch com retry
  -> RRF -> rerank -> verificação final FAIL-CLOSED -> prompt -> generate
Todos removidos => "não encontrei" (found=False), sem revelar conteúdo (FR-010).
"""

from __future__ import annotations

from datetime import datetime

from rag_confluence.app.config import Settings
from rag_confluence.app.logging import emit_query_audit
from rag_confluence.app.services.query_cache import QueryCache
from rag_confluence.app.tracing import new_trace_id
from rag_confluence.domain.acl.principals import build_user_principals
from rag_confluence.domain.models import AuditRecord, Chunk, QueryResult, Source
from rag_confluence.domain.prompt.assemble import (
    NOT_FOUND_MESSAGE,
    build_prompt,
    is_empty,
    sources_from_chunks,
)
from rag_confluence.domain.retrieval.fusion import overfetch_size, reciprocal_rank_fusion


class VerificationUnavailable(RuntimeError):
    """Nenhum resultado pôde ser servido com segurança (fail-closed) -> 503."""


class QueryService:
    def __init__(
        self, *, identity, metadata_store, embedding, vector_store, lexical_store,
        reranker, generator, access_verifier, settings: Settings, cache: QueryCache | None = None,
    ) -> None:
        self._identity = identity
        self._meta = metadata_store
        self._embedding = embedding
        self._vector = vector_store
        self._lexical = lexical_store
        self._reranker = reranker
        self._generator = generator
        self._verifier = access_verifier
        self._settings = settings
        self._cache = cache or QueryCache()

    async def answer(self, question: str, user_token: str, top_k: int | None = None) -> QueryResult:
        trace_id = new_trace_id()
        top_k = top_k or self._settings.top_k

        account_id = await self._identity.resolve_account_id(user_token)
        group_ids = self._meta.get_user_groups(account_id) or []
        principals = build_user_principals(account_id, group_ids)

        cache_key = self._cache.make_key(question, principals, top_k)
        if (hit := self._cache.get(cache_key)) is not None:
            return hit

        reranked = await self._retrieve(question, principals, top_k)
        relevant = [s for s in reranked if s.score > self._settings.min_relevance]
        retrieved_page_ids = _unique_order(s.chunk.page_id for s in relevant)

        approved = await self._verifier.verify(account_id, retrieved_page_ids, user_token)
        survivors: list[Chunk] = [s.chunk for s in relevant if s.chunk.page_id in approved]

        emit_query_audit(AuditRecord(
            trace_id=trace_id, account_id=account_id,
            retrieved_page_ids=tuple(retrieved_page_ids),
            approved_page_ids=tuple(pid for pid in retrieved_page_ids if pid in approved),
            phase=self._settings.acl_phase, verifier_adapter=self._verifier.name,
            timestamp=datetime.utcnow(),
        ))

        result = await self._compose(question, survivors, trace_id)
        self._cache.set(cache_key, result)
        return result

    async def _retrieve(self, question, principals, top_k):
        query_vec = await self._embedding.embed_query(question)
        plist = list(principals)
        for attempt in range(self._settings.overfetch_retries + 1):
            of = overfetch_size(top_k, attempt)
            dense = self._vector.search_dense(query_vec, plist, of)
            lexical = self._lexical.search_bm25(question, plist, of)
            fused = reciprocal_rank_fusion([dense, lexical])
            if fused:
                return self._reranker.rerank(question, fused, top_k)
        return []

    async def _compose(self, question, survivors, trace_id) -> QueryResult:
        if is_empty(survivors):
            return QueryResult(NOT_FOUND_MESSAGE, False, (), trace_id)
        prompt = build_prompt(question, survivors)
        answer = await self._generator.generate(prompt)
        sources: tuple[Source, ...] = sources_from_chunks(survivors)
        return QueryResult(answer, True, sources, trace_id)


def _unique_order(items) -> list[str]:
    seen: set[str] = set()
    out: list[str] = []
    for it in items:
        if it not in seen:
            seen.add(it)
            out.append(it)
    return out
