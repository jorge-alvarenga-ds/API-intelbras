"""SyncService: pipeline de ingestão resumível, com lock, gate de fase e reconciliação.

O banco é a fila (FR-015/FR-019). Retomada por checkpoint + upsert idempotente por
page_id. Gate de fase (FR-008): na Fase A, conteúdo restrito NÃO é indexado.
Encerramento cooperativo (FR-017) e exclusão mútua entre réplicas (FR-016).
"""

from __future__ import annotations

import asyncio
import uuid
from datetime import datetime

from rag_confluence.app.config import Settings
from rag_confluence.app.logging import log_page_ingestion
from rag_confluence.app.services.reconcile import Reconciler
from rag_confluence.domain.acl.effective import resolve_effective_acl
from rag_confluence.domain.acl.phase_gate import PhaseGateViolation, assert_indexable
from rag_confluence.domain.adf.walker import adf_to_markdown
from rag_confluence.domain.chunking.hierarchical import (
    breadcrumb_from_ancestors,
    chunk_markdown,
    content_hash,
)
from rag_confluence.domain.models import Chunk, JobStatus, SyncJob, SyncMode
from rag_confluence.ports.lock import LockHeld


class ActiveJobExists(RuntimeError):
    """Já existe um job ativo para o escopo (exclusão mútua -> 409)."""


class ScopeNotAllowed(ValueError):
    """Escopo fora da allowlist versionada (FR-014)."""


class SyncService:
    def __init__(
        self, *, content, acl, metadata_store, vector_store, lexical_store, embedding, lock,
        settings: Settings, parse=adf_to_markdown,
    ) -> None:
        self._content = content
        self._acl = acl
        self._meta = metadata_store
        self._vector = vector_store
        self._lexical = lexical_store
        self._embedding = embedding
        self._lock = lock
        self._settings = settings
        self._parse = parse  # produção: ProcessPoolExecutor (fora do event loop)
        self._shutdown = False
        self._tasks: set[asyncio.Task] = set()
        self._reconciler = Reconciler(
            content=content, metadata_store=metadata_store,
            vector_store=vector_store, lexical_store=lexical_store,
        )

    # ------------------------------------------------------------------ API
    async def start(self, scope: list[str] | None, mode: SyncMode) -> str:
        job = self._new_job(scope)
        task = asyncio.create_task(self._guarded_run(job.job_id, mode))
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)
        return job.job_id

    async def run_sync(self, scope: list[str] | None, mode: SyncMode = SyncMode.FULL) -> SyncJob:
        """Executa até a conclusão (CLI/testes)."""
        job = self._new_job(scope)
        await self._guarded_run(job.job_id, mode)
        return self._meta.get_job(job.job_id)

    def status(self, job_id: str) -> SyncJob | None:
        return self._meta.get_job(job_id)

    def current(self) -> SyncJob | None:
        return self._meta.get_active_job()

    def cancel(self, job_id: str) -> SyncJob | None:
        job = self._meta.get_job(job_id)
        if job and job.status in (JobStatus.QUEUED, JobStatus.RUNNING):
            job.cancel_requested = True
            job.status = JobStatus.CANCELLING
            job.updated_at = datetime.utcnow()
            self._meta.update_job(job)
        return self._meta.get_job(job_id)

    def request_shutdown(self) -> None:
        """SIGTERM cooperativo (FR-017): termina a página atual e sai."""
        self._shutdown = True

    # --------------------------------------------------------------- interno
    def _new_job(self, scope: list[str] | None) -> SyncJob:
        resolved = self._resolve_scope(scope)
        if self._meta.get_active_job() is not None:
            raise ActiveJobExists("já existe um job de sincronização ativo")
        job = SyncJob(
            job_id=uuid.uuid4().hex, status=JobStatus.QUEUED, scope=tuple(resolved),
            started_at=datetime.utcnow(), updated_at=datetime.utcnow(),
        )
        self._meta.create_job(job)
        return job

    def _resolve_scope(self, scope: list[str] | None) -> list[str]:
        if scope is None:
            return list(self._settings.allowlist)
        for space in scope:
            if not self._settings.in_allowlist(space):
                raise ScopeNotAllowed(f"espaço fora da allowlist: {space}")
        return list(scope)

    async def _guarded_run(self, job_id: str, mode: SyncMode) -> None:
        job = self._meta.get_job(job_id)
        try:
            with self._lock.acquire(self._scope_key(job.scope)):
                job.status = JobStatus.RUNNING
                self._save(job)
                await self._run(job, mode)
        except LockHeld:
            job.status = JobStatus.FAILED
            job.errors.append({"error": "lock_held"})
            self._save(job)

    async def _run(self, job: SyncJob, mode: SyncMode) -> None:
        if mode is SyncMode.RECONCILE:
            await self._reconciler.run(list(job.scope))
            self._finish(job)
            return

        since = None if mode is SyncMode.FULL else job.checkpoint.get("since")
        for space in job.scope:
            listing = await self._content.list_pages(space, since, None)
            job.total += len(listing.refs)
            self._save(job)
            for ref in listing.refs:
                if self._should_stop(job):
                    self._finish(job, cancelled=True)
                    return
                await self._process(space, ref.page_id, job)
                job.processed += 1
                job.checkpoint = {"last_page": ref.page_id, "since": datetime.utcnow().isoformat()}
                self._save(job)

        if mode is SyncMode.FULL:
            await self._reconciler.run(list(job.scope))
        self._finish(job)

    async def _process(self, space: str, page_id: str, job: SyncJob) -> None:
        try:
            page = await self._content.get_page(page_id)
            markdown = self._parse(page.body_adf)
            chash = content_hash(markdown)

            # Retomada / idempotência: versão + hash iguais => não reprocessa (FR-015/FR-020).
            if self._meta.get_page_version(page_id) == page.version and \
                    self._meta.get_page_hash(page_id) == chash:
                return

            acl_eff = await self._resolve_acl(space, page)
            assert_indexable(page_id, acl_eff, self._settings.acl_phase)  # gate de fase (FR-008)

            breadcrumb = breadcrumb_from_ancestors([a.title for a in page.ancestors])
            chunk_texts = chunk_markdown(markdown, breadcrumb)
            if not chunk_texts:
                log_page_ingestion(page_id, page.version, "skipped_trivial", space)
                return

            embeddings = await self._embedding.embed_documents([ct.text for ct in chunk_texts])
            principals = tuple(acl_eff.allowed_principals)
            chunks = [
                Chunk(
                    chunk_id=f"{page_id}:{ct.index}", page_id=page_id, chunk_index=ct.index,
                    space_key=space, text=ct.text, allowed_principals=principals,
                    breadcrumb=breadcrumb, heading_path=ct.heading_path, url=page.url,
                    version=page.version, embedding=tuple(emb), title=page.title,
                )
                for ct, emb in zip(chunk_texts, embeddings)
            ]
            self._vector.upsert(chunks)
            self._lexical.index(chunks)
            self._meta.upsert_page(page_id, space, page.version, chash)
            log_page_ingestion(page_id, page.version, "indexed", space)
        except PhaseGateViolation as exc:
            job.errors.append({"page_id": page_id, "error": "phase_gate_blocked", "detail": str(exc)})
            log_page_ingestion(page_id, -1, "blocked_phase_gate", space)
        except Exception as exc:  # falha por página não derruba o job
            job.errors.append({"page_id": page_id, "error": str(exc)})
            log_page_ingestion(page_id, -1, "failed", space)

    async def _resolve_acl(self, space: str, page):
        page_restr = await self._acl.get_page_restrictions(page.page_id)
        # Ancestrais do mais próximo (parent) para o mais distante (root).
        anc_restrs = [await self._acl.get_page_restrictions(a.id) for a in reversed(page.ancestors)]
        space_perm = await self._acl.get_space_permissions(space)
        return resolve_effective_acl(page_restr, anc_restrs, space_perm)

    def _should_stop(self, job: SyncJob) -> bool:
        if self._shutdown:
            return True
        fresh = self._meta.get_job(job.job_id)
        return bool(fresh and fresh.cancel_requested)

    def _finish(self, job: SyncJob, cancelled: bool = False) -> None:
        job.status = JobStatus.CANCELLED if cancelled else JobStatus.COMPLETED
        job.updated_at = datetime.utcnow()
        self._meta.update_job(job)

    def _save(self, job: SyncJob) -> None:
        job.updated_at = datetime.utcnow()
        self._meta.update_job(job)

    @staticmethod
    def _scope_key(scope) -> str:
        return "sync:" + ",".join(sorted(scope))
